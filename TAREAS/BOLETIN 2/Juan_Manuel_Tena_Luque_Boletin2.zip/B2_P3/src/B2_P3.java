import java.io.BufferedReader;
import java.io.InputStreamReader;
 
public class B2_P3 {
 
    public static void main(String[] args) {
 
    	BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
    	
        //Declaracion de variables
    	int iOpcion; 
        float fNum1 = 0, fNum2 = 0, fResultado = 0;
        
        //Pedir numero por teclado
        System.out.println("Introduzca el primer n�mero");
        try {
			fNum1 = Short.parseShort(teclado.readLine());
		} catch (Exception e) {
		}
        System.out.println("Introduzca el segundo n�mero");
        try {
			fNum2 = Short.parseShort(teclado.readLine());
		} catch (Exception e) {
		}
        	//Pedir por teclado que selecciones una de las opciones
            System.out.println("1. Suma");
            System.out.println("2. Resta");
            System.out.println("3. Multiplicacion");
            System.out.println("4. Division");
            System.out.println("5. Resto");
            System.out.println("Elija opcion");
 
            try {
                iOpcion = Integer.parseInt(teclado.readLine());
                
                //Logica de la aplicacion
                switch (iOpcion) {
                    case 1:
                        System.out.println("Has seleccionado la Suma");
                        fResultado = fNum1 + fNum2;
                        //Mostrar por pantalla el mensaje con el resultado de la opcion 1
                        System.out.println(fNum1+ " + " +fNum2+ " = " +fResultado);
                        break;
                    case 2:
                        System.out.println("Has seleccionado la Resta");
                        fResultado = fNum1 - fNum2;
                        //Mostrar por pantalla el mensaje con el resultado de la opcion 2
                        System.out.println(fNum1+ " - " +fNum2+ " = " +fResultado);
                        break;
                    case 3:
                        System.out.println("Has seleccionado la Multiplicacion");
                        fResultado = fNum1 * fNum2;
                        //Mostrar por pantalla el mensaje con el resultado de la opcion 3
                        System.out.println(fNum1+ " * " +fNum2+ " = " +fResultado);
                        break;
                    case 4:
                    	System.out.println("Has seleccionado la Division");
                    	fResultado = fNum1 / fNum2;
                    	//Mostrar por pantalla el mensaje con el resultado de la opcion 4
                    	System.out.println(fNum1+ " / " +fNum2+ " = " +fResultado);
                        break;
                    case 5:
                    	System.out.println("Has seleccionado el Resto");
                    	fResultado = fNum1 % fNum2;
                    	//Mostrar por pantalla el mensaje con el resultado de la opcion 5
                    	System.out.println(fNum1+ " % " +fNum2+ " = " +fResultado);
                        break;
                    default:
                        System.out.println("Error");
                }
            } catch (Exception e) {
                System.out.println("Debes insertar un n�mero");
            }
 
    }
 
}