import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B2_EJ2 {

	public static void main(String[] args) {
		
		//Declaracion de variables
		byte bHora1, bHora2;
		short shMinutos1, shMinutos2, shMinTotales1, shMinTotales2, shDiferencia;
		
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
	
		System.out.println("Introduzca la primera hora.");
		
		do {
			try{
				System.out.print("Hora1 (0...24): ");
				//Introducir Hora y casting
				bHora1 = Byte.parseByte(teclado.readLine());
				System.out.print("Minutos: ");
				//Introducir minutos y casting
				shMinutos1 = Short.parseShort(teclado.readLine());
			} catch (Exception e) {
				bHora1 = -1;
				shMinutos1 = -1;
			}
		} while ((bHora1 < 0 || bHora1 > 24) || (shMinutos1 < 0 || shMinutos1 > 59));
		
		System.out.println("Introduzca la segunda hora.");
	
		do {
			try{
				System.out.print("Hora2 (0...24): ");
				//Introducir Hora y casting
				bHora2 = Byte.parseByte(teclado.readLine());
				System.out.print("Minutos: ");
				//Introducir minutos y casting
				shMinutos2 = Short.parseShort(teclado.readLine());
			} catch (Exception e) {
				bHora2 = -1;
				shMinutos2 = -1;
			}
		} while ((bHora2 < 0 || bHora2 > 24) || (shMinutos2 < 0 || shMinutos2 > 59));

		//Calculo de minutos totales para saber cual es mayor
		shMinTotales1 = (short) ((bHora1*60) + shMinutos1);
		shMinTotales2 = (short) ((bHora2*60) + shMinutos2);
		if (shMinTotales1 == shMinTotales2) {
			System.out.println("Las horas son iguales");
		}else if (shMinTotales1 > shMinTotales2) {
			System.out.println("La primera hora es posterior a la segunda hora.");
			shDiferencia = (short) (shMinTotales1 - shMinTotales2);
			bHora1 = (byte) (shDiferencia/60);
			shMinutos1 = (short) (shDiferencia%60);	
			System.out.println("Han pasado " +bHora1+ " horas y " +shMinutos1+ " minutos");
		} else {
			System.out.println("La primera hora es anterior a la segunda hora.");
			shDiferencia = (short) (shMinTotales2 - shMinTotales1);
			bHora2 = (byte) (shDiferencia/60);
			shMinutos2 = (short) (shDiferencia%60);
			System.out.println("Faltan " +bHora2+ " horas y " +shMinutos2+ " minutos");
		}
					
		}
	
}

		