import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B2_P8 {

	public static void main(String[] args) {

		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));

		// Declaracion de variables
		float fA, fB, fC;

		// Escribir por teclado y castear
		System.out.print("Introduce la longitud del lado A: ");
		try {
			fA = Float.parseFloat(teclado.readLine());
		} catch (Exception e) {
			fA = -1;
			System.out.println("Error");
		}
		// Escribir por teclado y castear
		System.out.print("Introduce la longitud del lado B: ");
		try {
			fB = Float.parseFloat(teclado.readLine());
		} catch (Exception e) {
			fB = -1;
			System.out.println("Error");
		}
		// Escribir por teclado y castear
		System.out.print("Introduce la longitud del lado C: ");
		try {
			fC = Float.parseFloat(teclado.readLine());
		} catch (Exception e) {
			fC = -1;
			System.out.println("Error");
		}
		
		//Logica del programa
		if (fA == (fB + fC)) {
			System.out.println("Es rectangulo.");
		}
		if (fA < (fB + fC)) {
			System.out.println("Es acutangulo.");
		}
		if (fA > (fB + fC)) {
			System.out.println("Es obtusangulo.");
		}
		

	}

}