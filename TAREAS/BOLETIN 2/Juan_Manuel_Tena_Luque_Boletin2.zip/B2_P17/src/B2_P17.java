import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B2_P17 {

	public static void main(String[] args) {
		
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		
		//Declaracion de vatiables
		int iNumero, iNumeroTotal = 0, iNumeroMayor = -1000000, iNumeroMenor = 1000000;
		byte bContador = 0;
		
		//Mensaje para saber cuantos numeros va a introducir
		try {
			System.out.println("�Cuantos numeros va a introducir?");
			//Introducir numeros y casting
			iNumeroTotal = Integer.parseInt(teclado.readLine());
		} catch (Exception e) {
			iNumeroTotal = -1;
		}
		
		//Contador para introducir los 4 numeros que se piden
		for (bContador = 0; bContador < iNumeroTotal ; bContador++) {
			//Pedir por teclado los numeros
			try {
				System.out.print("Introduce numero : ");
				iNumero = Integer.parseInt(teclado.readLine());
				
			} catch (Exception e) {
				iNumero = -1;
				System.out.println("El numero introducio no es valido");	
			}
			
			//Logica de la aplicacion para saber el numero mayor
			if (iNumero > iNumeroMayor){
				iNumeroMayor = iNumero;
			}
			
			//Logica de la aplicacion para saber el numero menor
			if (iNumero < iNumeroMenor) {
				iNumeroMenor = iNumero;
			}
			
		}
		//Mostrar por pantalla el mensaje con el resultado del numero mayor y menor
		System.out.println("El numero mayor es " +iNumeroMayor+ " y el numero menor es " +iNumeroMenor);
	}
}