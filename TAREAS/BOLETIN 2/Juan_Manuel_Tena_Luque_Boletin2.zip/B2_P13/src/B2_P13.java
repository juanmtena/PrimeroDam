import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B2_P13 {

	public static void main(String[] args) {
		
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		
		int iNumero = 0, iUltimoNumero = 0, iNumeroCapicua = 0, iNumeroInverso = 0;
		byte bResto = 0;
		
		do {
			System.out.println("Introduce un numero: ");
			try {
			iNumero=Integer.parseInt(teclado.readLine());
			} catch (Exception e) {
				iNumero = -1;
				System.out.println("Error. Numero no v�lido");
			}
		} while (iNumero < 0);
		
		iUltimoNumero = iNumero;
		
		while (iUltimoNumero != 0) {
			bResto = (byte) (iUltimoNumero % 10);
			iNumeroCapicua = iNumeroCapicua * 10 + bResto;
			iUltimoNumero = iUltimoNumero / 10;
			iNumeroInverso = iNumeroCapicua;
		}		
		System.out.println(iNumeroInverso);
	}

}