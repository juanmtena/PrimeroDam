import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B2_P15 {

	public static void main(String[] args) {

		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		
		//Declaracion de variables y el boolean
		short shNumero1, shNumero2;
		int iNumeroEntero, iNumeroCapicua, iContador;
		byte bResto;
		boolean boolCapicua = false;
		
		//Pedir que introduzca numero
		do {
			System.out.print("Introduce el primer numero: ");
			//Casting e introducir por teclado
			try {
				shNumero1 = Short.parseShort(teclado.readLine());
			} catch (Exception e) {
				shNumero1 = -1;
				System.out.println("Error. Numero no v�lido");
			}

		} while (shNumero1 < 0);
		
		//Pedir que introduzca numero
		do {
			System.out.print("Introduce el segundo numero: ");
			//Casting e introducir por teclado
			try {
				shNumero2 = Short.parseShort(teclado.readLine());
			} catch (Exception e) {
				shNumero2 = -1;
				System.out.println("Error. Numero no v�lido");
			}
		} while (shNumero2 < 0);

		//Contador
		for (iContador = shNumero1; iContador <= shNumero2; iContador++) {
			iNumeroEntero = iContador;
			iNumeroCapicua = 0;
			boolCapicua = false;
			
			//Logica del programa
			while (iNumeroEntero != 0) {
				bResto = (byte) (iNumeroEntero % 10);
				iNumeroCapicua = iNumeroCapicua * 10 + bResto;
				iNumeroEntero /= 10;
				
				if (iNumeroCapicua == iContador) {
					boolCapicua = true;
				}
				
			//Salida y mensaje con los resultados 
			}if (boolCapicua == true) {
			System.out.println(iNumeroCapicua);
			}
		
		}

	}
}