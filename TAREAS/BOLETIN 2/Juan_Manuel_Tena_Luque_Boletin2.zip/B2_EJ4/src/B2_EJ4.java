import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B2_EJ4 {

	public static void main(String[] args) {
		
		//Declaracion de vatiables
		int iNumero, iNumeroMayor = -1000000, iNumeroMenor = 1000000;
		byte bContador = 0;
		
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		
		//Mensaje pidiendo que introduzca los numeros
		System.out.println("Introduce 4 numeros:");
		
		//Contador para introducir los 4 numeros que se piden
		for (bContador = 1; bContador < 5 ; bContador++) {
			//Pedir por teclado los numeros
			try {
				System.out.print(bContador + ". Introduce numero : ");
				iNumero = Integer.parseInt(teclado.readLine());
				
			} catch (Exception e) {
				iNumero = -1;
				System.out.println("El numero introducio no es valido");	
			}
			
			//Logica de la aplicacion para saber el numero mayor
			if (iNumero > iNumeroMayor){
				iNumeroMayor = iNumero;
			}
			
			//Logica de la aplicacion para saber el numero menor
			if (iNumero < iNumeroMenor) {
				iNumeroMenor = iNumero;
			}
			
		}
		//Mostrar por pantalla el mensaje con el resultado del numero mayor y menor
		System.out.println("El numero mayor es " +iNumeroMayor+ " y el numero menor es " +iNumeroMenor);
	}
}