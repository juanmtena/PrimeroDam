import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B2_P14 {

	public static void main(String[] args) {
		
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		
		//Declaracion de variables
		int iNumero = 0, iNumeroEntero = 0, iNumeroCapicua = 0;
		byte bResto = 0;
		
		//Pedir que introduzca numero
		do {
			System.out.println("Introduce un numero: ");
			//Casting e introducir por teclado
			try {
			iNumero=Integer.parseInt(teclado.readLine());
			} catch (Exception e) {
				iNumero = -1;
				System.out.println("Error. Numero no v�lido");
			}
		} while (iNumero < 0);
		
		//Logica de la aplicacion
		iNumeroEntero = iNumero;
		while (iNumeroEntero != 0) {
			bResto = (byte) (iNumeroEntero % 10);
			iNumeroCapicua = iNumeroCapicua * 10 + bResto;
			iNumeroEntero = iNumeroEntero / 10;
		}
		//Salida y mostrar mensaje 
		if (iNumeroCapicua == iNumero)
			System.out.print("El numero introducido es capicua");
		else
			System.out.print("El numero introducido no es capicua");
	}

}