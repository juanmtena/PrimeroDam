import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B2_P6 {

	public static void main(String[] args) {
		
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		
		//Declaracion de variables y valor del boolean
		float fNumero, fSuma = 0;
		int iContador = 0;
		boolean boolSalida = false;
		
		//Casting e introducir por teclado
		do {
			try {
				System.out.print("Introduce un numero que no sea 0: ");
				fNumero = Float.parseFloat(teclado.readLine());
			 
			} catch (Exception e) {
				fNumero = -1;
				System.out.println("El numero introducio no es valido");
				}
			//Logica de la aplicacion
			if (fNumero != 0 && boolSalida == false) {
				fSuma += fNumero;
				iContador++;
			} else 
				boolSalida = true;
			
		} while (boolSalida == false);
		
		//Mostrar por pantalla el mensaje , el resultado de la suma y el total de numeros introducidos
		System.out.println("La suma total de los numeros es " +fSuma);
		System.out.println("Has introducido " +iContador+ " numeros");
		
	}

}