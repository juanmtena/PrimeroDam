public class B2_EJ3 {

	public static void main(String[] args) {

		// Declaracion de variables
		byte bFila;
		// Declaracion constantes
		String sNumeros = "";

		// Logica del programa: Contador e imprimir por pantalla
		//Contador para obtener las 5 filas
		for (bFila = 1; bFila <= 5; bFila++) {		
			//Contador para obtener los numeros
			for (byte bContador = bFila; bContador < 10; bContador+=bFila) {
				sNumeros += bContador;
			}
			//A�adirle un salto de carro al resultado final para formar la piramide
			sNumeros+="\n";
		}
		//Imprimir por pantalla el mensaje final
		System.out.println(sNumeros);
	}
}