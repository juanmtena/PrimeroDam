import java.io.*;

public class B2_EJ5 {

	public static void main(String[] args) {

		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));

		// Declarar las variables
		byte bNumero, bResultado, bMulti;

		// Pedir que introduzcas numero
		do {
			System.out.print("Introduce numero (0......10): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
			} catch (Exception e) {
				bNumero = -1;
				System.out.println("El caracter introducido no es valido");
			}

		} while (bNumero < 0 || bNumero > 10);
		{

			// Logica de la aplicacion
			for (bMulti = 1; bMulti < 11; bMulti++) {
				bResultado = (byte) (bNumero * bMulti);
				//Mostrar por pantalla el mensaje con la multiplicacion
				System.out.println(+bNumero + " x " + bMulti + " = " + bResultado);
			}
		}

	}

}
