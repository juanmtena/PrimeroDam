import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B2_P10 {

	public static void main(String[] args) {

		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		
		//Desclaracion de variables
		byte bNumero, bNumeroPar = 0;
		String sCadena = " ";
		
		//Pedir que introduzca numero
		do {
			System.out.print("Introduce un numero entre 0 y 100: ");
			
			//Casting e introducir por teclado
			try {
				bNumero = Byte.parseByte(teclado.readLine());
			} catch (Exception e) {
				bNumero = -1;
				System.out.println("El numero introducio no es valido");
			} 
			//Logica de la aplicacion
			for (bNumeroPar = 2; bNumeroPar <= bNumero; bNumeroPar+=2) {
				sCadena = sCadena+" "+bNumeroPar;			
			}		
		} while (bNumero < 1 || bNumero >100);
		
		//Mostrar resultado de la logica y el mensaje del numero introducido
		System.out.println(sCadena);
		System.out.println("El numero introducido es " +bNumero);	
	}

}