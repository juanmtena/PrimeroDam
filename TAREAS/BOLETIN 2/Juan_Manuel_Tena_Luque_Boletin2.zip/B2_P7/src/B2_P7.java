import java.io.*;

public class B2_P7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));

		//Declaracion de variable
		short shAno;
		
		//Pedir que introduzca numero
		do {
			System.out.println("Introduce un a�o (1....3000): ");
			
			try {
				shAno = Short.parseShort(teclado.readLine());
			} catch (Exception e) {
				shAno = -1;
				System.out.println("El dato introducido no es valido");
			}
			
			} while (shAno < 1 || shAno >3000);
			
			//Logica de la aplicacion y mensaje final
			if ((shAno % 4==0) && ((shAno % 100!=0) || (shAno % 400==0)))
				System.out.println("El a�o que has introducido es bisiesto.");
			else 
				System.out.println("El a�o introducido no es bisiesto.");						

	}

}
