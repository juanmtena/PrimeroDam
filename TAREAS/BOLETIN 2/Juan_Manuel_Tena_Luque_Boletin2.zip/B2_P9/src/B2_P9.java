import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B2_P9 {

	public static void main(String[] args) {

		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		
		//Declaracion de variables
		byte bDia, bMes;
		short shAno, shAnoBis;
		boolean boolBis;
		
		//Introducir por teclado a�o y castear
		do {
			System.out.println("Introduce a�o: ");
			try {
				shAno = Short.parseShort(teclado.readLine());
			} catch (Exception e) {
				shAno = -1;
				System.out.println("El a�o no es valido");
			}
		} while (shAno < 1 || shAno > 3000);
		
		//Operacion para a�o bisiesto
		if ((shAno % 4 == 0) && ((shAno % 100 != 0) || (shAno % 400 == 0)))
			boolBis = true;
		else
			boolBis = false;

		//Introducir por teclado mes y castear
		do {
			System.out.println("Introduce mes: ");
			try {
				bMes = Byte.parseByte(teclado.readLine());
			} catch (Exception e) {
				bMes = -1;
				System.out.println("El mes no es valido");
			}	
		} while (bMes < 1 || bMes > 12 );
		
		//Introducir por teclado dia y castear
		do { 
			System.out.println("Introduce el dia: ");
			try {
				bDia = Byte.parseByte(teclado.readLine());
			} catch (Exception e) {
				bDia = -1;
				System.out.println("El mes no es valido");
			}
		} while (bDia < 1 || bDia > 31 ); 
			
		//Logica del programa y mensaje final
			if (((boolBis && bMes == 2 && bDia <= 29) || (!boolBis && bMes ==2 && bDia <= 28) || ((bMes == 1 || bMes == 3 || bMes == 5 || bMes == 7 || bMes == 8 || bMes == 10 || bMes == 12) && (bDia <= 31)) || ((bMes == 4 || bMes == 6 || bMes == 9 || bMes == 11) && bDia <= 30))) {
				System.out.println(bDia+ " " +bMes+ " " +shAno+ " es correcta"); 
			} else {
				System.out.println(bDia+ " " +bMes+ " " +shAno+ " no es correcta");
				}
			
			
	}
		
		

}
