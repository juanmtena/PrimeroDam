import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B2_P11 {

	public static void main(String[] args) {

		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		
		//Declarar las variables
		short shHora, shMinutos = -1, shSegundos = -1;

		do {
			System.out.print("Introduzca hora: ");
			try {
				shHora = Short.parseShort(teclado.readLine());
			} catch (Exception e) {
				shHora = -1;
				System.out.println("Error.");
			}
			if (shHora >= 0) {
				System.out.print("Introduzca minutos: ");
				try {
					shMinutos = Short.parseShort(teclado.readLine());
				} catch (Exception e) {
					shMinutos = -1;
					System.out.println("Error. ");
				}
			}
			if (shMinutos >= 0) {
				System.out.print("Introduzca segundos: ");
				try {
					shSegundos = Short.parseShort(teclado.readLine());
				} catch (Exception e) {
					shSegundos = -1;
					System.out.println("Error.");
				}
			}
			
		} while ((shHora < 0) || (shMinutos < 0) || (shSegundos < 0)); 
			if ((shHora >= 0 && shHora <= 24) && (shMinutos >= 0 && shMinutos <= 59)
					&& (shSegundos >= 0 && shSegundos <= 59)) {
				System.out.println("La hora introducida es correcta");
			} else {
				System.out.println("La hora introducida no es correcta");
			}
		
	}

}
