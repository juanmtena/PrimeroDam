import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B2_EJ1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));

		//Declaracion de variables y valor del boolean
		short shDia = 0, shMes = 0;
		int iAno;
		boolean boolAnoBisiesto = false;
		
		//Pido por teclado el a�o
		do {
			System.out.println("Introduce a�o");
			try {
				iAno = Short.parseShort(teclado.readLine());
			} catch (Exception e) {
				iAno = -1;
				System.out.println("El a�o no es valido");
			}
		} while (iAno < 1 || iAno > 3000);
		
		//L�gica para averiguar si el a�o es bisiesto
		if ((iAno % 4 == 0) && ((iAno % 100 != 0) || (iAno % 400 == 0))) {
			boolAnoBisiesto = true;
		}
		
		//Pido por teclado el mes
		do {
			System.out.println("Introduce mes");
			try {
				shMes = Short.parseShort(teclado.readLine());
			} catch (Exception e) {
				shMes = -1;
				System.out.println("El mes no es valido");
			}

		} while (shMes < 1 || shMes > 12);
		
		//Pido por teclado el dia
		do {
			System.out.println("Introduce dia");
			try {
				shDia = Short.parseShort(teclado.readLine());
			} catch (Exception e) {
				shDia = -1;
				System.out.println("El dia no es valido");
			}
			
		} while (shDia < 1 || shDia > 31);
			//Muestra en pantalla el mensaje con los datos introducidos 
			System.out.println("La fecha introducida es: " +shDia+ " del " + shMes+ " de " +iAno); 
			//Logica para conseguir que de el dia siguiente
			if (boolAnoBisiesto && shMes==2 && shDia==29) {
				shMes++;
				shDia=1;
			} else if (boolAnoBisiesto && shMes ==2 && shDia <= 28) {
				shDia++; 
			} else if (!boolAnoBisiesto && shMes ==2 && shDia <= 28) {
				shMes++;
				shDia=1;
			}else if ((shMes == 1 || shMes == 3 || shMes == 5 || shMes == 7 || shMes == 8 || shMes == 10) && shDia == 31) {
				shMes++;
				shDia=1;
			}else if ((shMes == 1 || shMes == 3 || shMes == 5 || shMes == 7 || shMes == 8 || shMes == 10) && shDia < 31) {
				shDia++;
			}else if (shMes == 12 && shDia == 31) {
				shDia = 1;
				shMes = 1;
				iAno++;
			} else if (shMes == 4 || shMes == 6 || shMes == 9 || shMes == 11 && shDia < 30) {
				shDia++;
			} else if (shMes == 4 || shMes == 6 || shMes == 9 || shMes == 11 && shDia == 30) {
				shMes++;
				shDia=1;
			}
			//Muestra en pantalla el dia siguiente a la fecha introducida
			System.out.println("El dia siguiente es " +shDia+ " del " +shMes+ " de " +iAno);
		}
	}