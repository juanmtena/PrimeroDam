import java.io.BufferedReader;
import java.io.InputStreamReader;
 
public class B2_P4 {
 
    public static void main(String[] args) {
 
    	BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
    	
        //Declaracion de variables
    	int iOpcion; 
        float fRadio = 0, fResultado = 0;
        
        //Declaracion de constantes
        final float FPI = 3.14f;
        
        //Leer por pantalla el mensaje para introducir numero
        System.out.println("Introduzca el radio de la circunferencia");
        
        //Escribir por teclado y castear
        try {
			fRadio = Short.parseShort(teclado.readLine());
		} catch (Exception e) {
		}
        	
        	//Leer por pantalla las opciones
            System.out.println("1. Longitud de la circunferencia");
            System.out.println("2. Superficie de la circunferencia");
            System.out.println("3. Volumen de la esfera");
            System.out.println("4. Area de la esfera");
            System.out.println("Elija opcion");
 
            //Escribir por teclado las diferentes opciones a elegir y castear
            try {
                iOpcion = Integer.parseInt(teclado.readLine());
 
                //Logica de la aplicacion y opcion a elegir
                switch (iOpcion) {
                    case 1:
                    	//Operacion para calcular la longitud
                        fResultado = (2*FPI*fRadio); 
                      //Mostrar por pantalla el mensaje con el resultado de la opcion 1
                        System.out.println("La longitud de la circunferencia es " +fResultado);
                        break;
                    case 2:
                    	//Operacion para calcular la superficie
                        fResultado = (FPI*(fRadio*fRadio));
                      //Mostrar por pantalla el mensaje con el resultado de la opcion 2
                        System.out.println("La superficie de la circunferencia es " +fResultado);
                        break;
                    case 3:
                    	//Operacion para calcular el volumen
                        fResultado = (4*(FPI)*(fRadio*fRadio*fRadio)/3);
                      //Mostrar por pantalla el mensaje con el resultado de la opcion 3
                        System.out.println("El volumen de la circunferencia es " +fResultado);
                        break;
                    case 4:
                    	//Operacion para calcular el area
                    	fResultado = ((4*FPI)*(fRadio*fRadio));
                    	//Mostrar por pantalla el mensaje con el resultado de la opcion 4
                    	System.out.println("El area de la circunferencia es " +fResultado);
                        break;
                    default:
                    	//Si no eliges ninguna de las opciones que te aparezca un mensaje de erro
                        System.out.println("Error");
                }
            } catch (Exception e) {
            	System.out.println("Debes insertar un n�mero");
            }
 
    }
 
}