public class B2_P2 {

	public static void main(String[] args) {
		
		//Declaracion de variables
		int iSuma = 0;
		String sPares = " ";
		
		//Logica: bucle para conseguir los numeros pares y haga la operacion de sumarlos
		for (int iNumero1 = 2; iNumero1<1001; iNumero1=iNumero1+2) {
			sPares = sPares+" "+iNumero1;
			iSuma = iSuma+iNumero1;
		}
		
		//Imprimir por pantalla
		System.out.println(sPares);
		System.out.println(iSuma);

	}

}