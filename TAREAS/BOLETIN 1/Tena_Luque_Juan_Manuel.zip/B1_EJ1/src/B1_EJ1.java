public class B1_EJ1 {

	public static void main(String[] args) {
		
		//Declarar constantes
		final float fPI=3.14f;
		final byte bRADIO=3;
		
		//Declarar datos de salida
		float fArea;
		
		fArea=(fPI*(bRADIO*bRADIO));
		
		System.out.println("El Area es de un c�rculo de radio 3 es " +fArea);

	}

}
