public class B1_P8 {

	public static void main(String[] args) {
		
		//1-Cantidad ==0 || ==7
		//2-Precio >=500 && <=1200
		
	}

}
