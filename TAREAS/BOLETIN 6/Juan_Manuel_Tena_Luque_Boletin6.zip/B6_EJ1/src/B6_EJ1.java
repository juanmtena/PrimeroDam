import java.io.BufferedReader;
import java.io.InputStreamReader;


public class B6_EJ1 {

	public static void main(String[] args) {
	
		System.out.println("*****Bienvenido al sistema de gestion de empleados de Medac Developer 2021*****\n�Numero correspondiente al departamento:");
		System.out.println("#1: Desarrollo\n#2: Testing\n#3: Calidad\n#4: Analisis\n#5: Dise�o");
		short[][] aEmpleados = new short[15][3];
		almacenarDatosDepartamento(aEmpleados);
		imprimirMatriz(aEmpleados);
		media(aEmpleados);
		
	}
	
	private static short[][] almacenarDatosDepartamento(short[][] aEmpleados) {
		
		byte bFila, bColumna, bContador = 1;
		
		for(bColumna = 0; bColumna < aEmpleados.length; bColumna++) {
			for(bFila = 0; bFila < aEmpleados[bColumna].length; bFila++) {
				if(bFila == 0) { 
					aEmpleados[bColumna][bFila] = (short) (Math.random()*5+1);
				} else if(bFila == 1) {
					aEmpleados[bColumna][bFila] = (short) (Math.random()*2000+1000);
				} else {
					aEmpleados[bColumna][bFila] = (short) (Math.random()*5+1);
				}
				bContador++;
			}
		}
		
		return aEmpleados;
	}
	
	private static short[][] imprimirMatriz (short[][] aEmpleados) {
		
		byte bNumeroEmpleado = 1;
		
		System.out.println();
		for(byte bContador = 0; bContador < aEmpleados.length; bContador++) {
			for(byte bContador2 = 0; bContador2 < aEmpleados[bContador].length; bContador2++) {
				if(bContador == 0 && bContador2 == 0) {
					System.out.println("Departamento | Sueldo | Satisfaccion\n");
				}
				System.out.print("     |"+aEmpleados[bContador][bContador2]+"|  ");
				if(bContador2 == 2) {
					System.out.print("    Empleado "+bNumeroEmpleado);
				}
			}
	            System.out.println();
	            bNumeroEmpleado++;
		}
		return aEmpleados;
	}
	
	private static short[][] media(short[][] aEmpleados) {
		
		float fSatisfaccion = 0, fSalarioTotal = 0;
		byte bContadorEmpleados = 0;
		
		byte bNumeroDepartamento = (byte)leer("\nIntroduce el numero del departamento: ", 1, 5, -1, -1,(byte)1);
		
		for(byte bContador = 0; bContador < aEmpleados.length; bContador++) {
			if(bNumeroDepartamento == aEmpleados[bContador][0]) {
				fSalarioTotal += aEmpleados[bContador][1];
				fSatisfaccion += aEmpleados[bContador][2];
				bContadorEmpleados++;
			}
		}
		System.out.println("El grado de satisfaccion medio de los empleados del departamento "+bNumeroDepartamento+" es: "+(fSatisfaccion/bContadorEmpleados)+"\nEl sueldo medio de este mismo departamento es: "+(fSalarioTotal/bContadorEmpleados)+" euros");
		
		return aEmpleados;
	}

	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo, byte bEstado) {
		Object oNumero;
		switch(bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje,lMinimo,lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje,lMinimo,lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje,lMinimo,lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje,lMinimo,lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje,dMinimo,dMaximo);
			break;
		case 6:
			oNumero = pideLetrasString(sMensaje);
			break;	
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}
	
	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;
		
		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}
	
	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}
	
	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}
	
	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+dMinimo+" - " +dMaximo+"): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}
	
	private static String pideLetrasString(String sMensaje) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		String sLetras = "";
		boolean bFallo;

		do {
			System.out.print(sMensaje);
			try {
				sLetras = teclado.readLine();
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo);

		return sLetras;
	}
	
}
