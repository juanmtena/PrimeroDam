import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

public class B6_EJ6 {

	public static void main(String[] args) {
		
		String[] aPalabras = new String[3];
		aPalabras[0] = "hipopotamo";
		aPalabras[1] = "cazuela";
		aPalabras[2] = "esternocleidomastoideo";
        Random rnd = new Random();
    	byte bPalabraAleatoria = (byte) rnd.nextInt(3);
        char[] aDesguazada = desguaza(aPalabras[bPalabraAleatoria]);
    	char[] aRespuestas = new char[aDesguazada.length];
        crearGuiones(aRespuestas);
        introduceLetra(aDesguazada, aRespuestas, aPalabras, bPalabraAleatoria);
        
	} 
	
	private static char[] crearGuiones(char[] aRespuestas) {
		
		for(byte bContador = 0; bContador < aRespuestas.length; bContador++){
			aRespuestas[bContador] = '_';
		}
		
        return aRespuestas;
	}
	  
    private static char[] introduceLetra(char[] aDesguazada, char[] aRespuestas, String[] aPalabras, byte bPalabraAleatoria){

        BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
        
        byte bContador = 0;
    	final byte bINTENTOS = 6;
        byte bIntentos = 0;
        byte bAciertos = 0;
        char cRespuesta = 0;
        char[] copia = desguaza(aPalabras[bPalabraAleatoria]);
       
	    do {
	        System.out.println("Adivina la palabra!");
	        while(bIntentos < bINTENTOS && bAciertos != aRespuestas.length){
	        	imprimeOculta(aRespuestas);
	            System.out.println("\nIntroduce una letra: ");
	            try {
					cRespuesta = teclado.readLine().toLowerCase().charAt(0);
				} catch (IOException e) {
					e.printStackTrace();
				}
	            for(bContador = 0; bContador < aDesguazada.length; bContador++){
	            	if(aDesguazada[bContador] == cRespuesta){
	            		aRespuestas[bContador] = aDesguazada[bContador];
	                	aDesguazada[bContador] = ' ';
	                    bAciertos++;
	            	}
	            	if(cRespuesta != aDesguazada[bContador]) {
	            		System.out.println("La palabra no contiende la letra: "+cRespuesta+" .......Le quedan "+(bINTENTOS-(bIntentos+1))+" intentos");
	            		bIntentos++;
	            		break;
	            	}
	            }
            }
	        if(bAciertos == aRespuestas.length) {
	        	System.out.print("\nEnhorabuena!! Has acertado la palabra: ");
	            imprimeOculta(aRespuestas);
	        }else {
	            System.out.print("\nGame Over! La palabra era: ");
	            for(bContador = 0; bContador < copia.length; bContador++){
	            	System.out.print(copia[bContador] + " ");
	            }
	        }
	        bIntentos = 0;
	        bAciertos = 0;
	        System.out.println("\n\nQuieres volver a jugar? (s/n)");
	        try {
				cRespuesta = teclado.readLine().toLowerCase().charAt(0);
			} catch (IOException e) {
				e.printStackTrace();
			}
	        while (cRespuesta != 's' && cRespuesta != 'n') {
	            System.out.println("Error! solo se admite S o N");
	            try {
					cRespuesta = teclado.readLine().toLowerCase().charAt(0);
				} catch (IOException e) {
					e.printStackTrace();
				}
	        }
	    }while(cRespuesta != 'n');
	    
	    return copia;
    }
	        
	private static char[] desguaza(String palAzar) {
		char[] letras;
        letras = new char[palAzar.length()];
        for(byte bContador = 0; bContador < palAzar.length(); bContador++){
            letras[bContador] = palAzar.charAt(bContador);
        }
        return letras;
	} 
	  
	private static void imprimeOculta(char[] aRespuestas){
	        
		for(byte bContador = 0; bContador < aRespuestas.length; bContador++){
			System.out.print(aRespuestas[bContador] + " ");
		}
	}
	
}