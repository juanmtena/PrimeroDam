import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B6_EJ2 {

	public static void main(String[] args) {
		
		byte[][] aMatriz = new byte [4][4];
		byte[][] aMatriz2 = aMatriz;
		crearMatriz(aMatriz);
		imprimirMatriz(aMatriz);
		System.out.println("\nLa matriz ordenada queda de la sieguiente manera");
		ordenarMatriz(aMatriz);
		imprimirMatriz(aMatriz);
		System.out.println("\nLas diagonales ordenadas de la matriz quedan de la sieguiente manera");
		ordenarDiagonales(aMatriz,aMatriz2);
		imprimirMatriz(aMatriz2);
		
	}
	
	private static byte[][] crearMatriz (byte[][] aMatriz) {
		
		byte bContador, bContador2;
		
		for (bContador = 0; bContador < aMatriz.length; bContador++) {
			for (bContador2 = 0; bContador2 < aMatriz[bContador].length; bContador2++) {
				aMatriz[bContador][bContador2] = (byte) (Math.random()*9+1);
			}
		}		
		return aMatriz;
	}
	
	private static byte[][] ordenarMatriz (byte[][] aMatriz) {
		
		byte bTemporal = 0;
		
		for(byte bContador1 = 0; bContador1 < aMatriz.length; bContador1++){//ordena la matriz de abajo hacia arriba
			for(byte bContador2 = 0; bContador2 < aMatriz[bContador1].length; bContador2++){
				for(byte bContador3 = 0; bContador3 < aMatriz.length; bContador3++){
					for(byte bContador4 = 0; bContador4 < aMatriz[bContador1].length; bContador4++){
						if(aMatriz[bContador1][bContador2] < aMatriz[bContador3][bContador4]){
						bTemporal = aMatriz[bContador1][bContador2];
						aMatriz[bContador1][bContador2] = aMatriz[bContador3][bContador4];
						aMatriz[bContador3][bContador4] = bTemporal;
						}
					}
				}
			} 
		}	
		return aMatriz;
	}
	
	private static byte[][] imprimirMatriz (byte[][] aMatriz) {
		
		System.out.println();
		for(byte bContador = 0; bContador < aMatriz.length; bContador++) {
			for(byte bContador2 = 0; bContador2 < aMatriz[bContador].length; bContador2++) {
				System.out.print("|"+aMatriz[bContador][bContador2]+"| ");
			}
	            System.out.println();
		}
		return aMatriz;
	}
	
	private static byte[][] ordenarDiagonales (byte[][] aMatriz, byte[][] aMatriz2) {
		
		byte bTemporal = 0, bFila = 0, bColumna = 0, bFila1 = 0, bColumna1 = 0;
		
		for (bFila = 0; bFila < aMatriz.length; bFila++) {
			for(bColumna = (byte) (aMatriz[0].length-1); bColumna >= 0 ; bColumna++) {
				for (bFila1 = 0; bFila1 < aMatriz.length; bFila1++) {
					for(bColumna1 = (byte) (aMatriz[0].length-1); bColumna1 >= 0 ; bColumna1++) {
						if(aMatriz[bFila][bColumna] > aMatriz[bFila1][bColumna1]) {
							bTemporal = aMatriz[bFila][bColumna];
							aMatriz[bFila][bColumna] = aMatriz[bFila1][bColumna1];
							aMatriz[bFila1][bColumna1] = bTemporal;
							bFila++;
						}
					}
				}
			}
		}
		
		return aMatriz2;
	}
	
	//aMatriz[bFila][bColumna] = (byte) (aMatriz[0].length-1);
	//bFila++;
	
	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo, byte bEstado) {
		Object oNumero;
		switch(bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje,lMinimo,lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje,lMinimo,lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje,lMinimo,lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje,lMinimo,lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje,dMinimo,dMaximo);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}
	
	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;
		
		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}
	
	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}
	
	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}
	
	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+dMinimo+" - " +dMaximo+"): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}
	
}