
public class ReproductorPortatil implements IReproductorPortatil {

	private String sMarca;
	private String sModelo;
	private boolean boolSonido;
	private boolean boolVideo;
	private byte bAutonomia;
	private float fPeso;
	private float fAltura;
	private float fGrosor;
	private byte bTipoDeAlmacenamiento;
	private byte bCapacidadDeAlmacenamiento;
	private byte bPantalla;
	private byte bTipodeBateria;
	
	

	public ReproductorPortatil(String sMarca, String sModelo) {
		
		setsMarca(sMarca);
		setsModelo(sModelo);
	}

	public ReproductorPortatil(String sMarca, String sModelo, byte bTipoDeAlmacenamiento) {

		setsMarca(sMarca);
		setsModelo(sModelo);
		setTipoDeAlmacenamiento(bTipoDeAlmacenamiento);
	}

	public ReproductorPortatil(String sMarca, String sModelo, boolean boolSonido, boolean boolVideo, byte bAutonomia,
			float fPeso, float fAltura, float fGrosor, byte bTipoDeAlmacenamiento, byte bCapacidadDeAlmacenamiento,
			byte bPantalla, byte bTipodeBateria) {

		setsMarca(sMarca);
		setsModelo(sModelo);
		setReproduceSonido(boolSonido);
		setReproduceVideo(boolVideo);
		setAutonomia(bAutonomia);
		setPeso(fPeso);
		setAltura(fAltura);
		setGrosor(fGrosor);
		setTipoDeAlmacenamiento(bTipoDeAlmacenamiento);
		setCapacidadDeAlmacenamiento(bCapacidadDeAlmacenamiento);
		setPantalla(bPantalla);
		setTipodeBateria(bTipodeBateria);
	}

	public String getsMarca() {
		return sMarca;
	}

	public void setsMarca(String sMarca) {
		this.sMarca = sMarca;
	}

	public String getsModelo() {
		return sModelo;
	}

	public void setsModelo(String sModelo) {
		this.sModelo = sModelo;
	}

	public boolean isReproduceSonido() {
		return boolSonido;
	}

	public void setReproduceSonido(boolean boolSonido) {
		this.boolSonido = boolSonido;
	}

	public boolean isReproduceVideo() {
		return boolVideo;
	}

	public void setReproduceVideo(boolean boolVideo) {
		this.boolVideo = boolVideo;
	}

	public byte getTipoDeAlmacenamiento() {
		return bTipoDeAlmacenamiento;
	}

	public void setTipoDeAlmacenamiento(byte bTipoDeAlmacenamiento) {

		if (bTipoDeAlmacenamiento == bCD) {
			this.bTipoDeAlmacenamiento = bTipoDeAlmacenamiento;
		} else if (bTipoDeAlmacenamiento == bDVD) {
			this.bTipoDeAlmacenamiento = bTipoDeAlmacenamiento;
		} else if (bTipoDeAlmacenamiento == bMEMORIAFLASH) {
			this.bTipoDeAlmacenamiento = bTipoDeAlmacenamiento;
		} else if (bTipoDeAlmacenamiento == bMINIDISK) {
			this.bTipoDeAlmacenamiento = bTipoDeAlmacenamiento;
		} else {
			bTipoDeAlmacenamiento = -1;
		}
	}

	public byte getCapacidadDeAlmacenamiento() {
		return bCapacidadDeAlmacenamiento;
	}

	public void setCapacidadDeAlmacenamiento(byte bCapacidadDeAlmacenamiento) {
		this.bCapacidadDeAlmacenamiento = bCapacidadDeAlmacenamiento;
	}

	public byte getPantalla() {
		return bPantalla;
	}

	public void setPantalla(byte bPantalla) {
		if (bPantalla == bNINGUNA) {
			this.bPantalla = bPantalla;
		} else if (bPantalla == bTEXTO) {
			this.bPantalla = bPantalla;
		} else if (bPantalla == bMONOCROMO) {
			this.bPantalla = bPantalla;
		} else if (bPantalla == bCOLOR) {
			this.bPantalla = bPantalla;
		} else {
			bPantalla = -1;
		}
	}

	public byte getTipodeBateria() {
		return bTipodeBateria;
	}

	public void setTipodeBateria(byte bTipodeBateria) {
		if (bTipodeBateria == bPILAS) {
			this.bTipodeBateria = bTipodeBateria;
		} else if (bTipodeBateria == bLILON) {
			this.bTipodeBateria = bTipodeBateria;
		} else {
			bTipodeBateria = -1;
		}
	}

	public byte getAutonomia() {
		return bAutonomia;
	}

	public void setAutonomia(byte bAutonomia) {
		this.bAutonomia = bAutonomia;
	}

	public float getPeso() {
		return fPeso;
	}

	public void setPeso(float fPeso) {
		this.fPeso = fPeso;
	}

	public float getAltura() {
		return fAltura;
	}

	public void setAltura(float fAltura) {
		this.fAltura = fAltura;
	}

	public float getGrosor() {
		return fGrosor;
	}

	public void setGrosor(float fGrosor) {
		this.fGrosor = fGrosor;
	}

	public String toString() {
		String sTipoDeAlmacenamiento = "";
        String sTipoDeBateria = "";
        String sPantalla = "";
        String sReproduceSonido = "";
        String sReproduceVideo = "";
        
        if (getTipoDeAlmacenamiento() == bCD) {
            sTipoDeAlmacenamiento += "CD";
        } else if (getTipoDeAlmacenamiento() == bDVD) {
            sTipoDeAlmacenamiento += "DVD";
        } else if (getTipoDeAlmacenamiento() == bMEMORIAFLASH) {
            sTipoDeAlmacenamiento += "MemoriaFlash";
        } else if (getTipoDeAlmacenamiento() == bMINIDISK) {
            sTipoDeAlmacenamiento += "Minidisk";
        } else {
            sTipoDeAlmacenamiento += "Tipo de almacenamiento no valido";
        }

        if (getPantalla() == bNINGUNA) {
            sPantalla += "Ninguna";
        } else if (getPantalla() == bTEXTO) {
            sPantalla += "texto";
        } else if (getPantalla() == bMONOCROMO) {
            sPantalla += "Monocromo";
        } else if (getPantalla() == bCOLOR) {
            sPantalla += "Color";
        } else {
            sPantalla += "Tipo de pantalla no valido";
        }

        if (getTipodeBateria() == bPILAS) {
            sTipoDeBateria += "Pilas";
        } else if (getTipodeBateria() == bLILON) {
            sTipoDeBateria += "Lilon";
        } else {
            sTipoDeBateria += "Tipo de bateria no valido";
        }
        
		if (isReproduceSonido() == true) {
			sReproduceSonido = "Si";
		}else {
			sReproduceSonido = "No";
		}
		
		if (isReproduceVideo() == true) {
			sReproduceVideo = "Si";
		}else {
			sReproduceVideo = "No";
		}
		
		return "---Reproductor Portatil---\nMarca= " + getsMarca() + "\nModelo= " + getsModelo() + "\nReproduce Sonido= " + sReproduceSonido
				+ "\nReproduce Video= " + sReproduceVideo + "\nAutonomia= " + getAutonomia() + " h\nPeso= " + fPeso + " gramos\nAltura= "
				+ getAltura() + " cm\nGrosor= " + fGrosor + " mm\nTipo De Almacenamiento= " + sTipoDeAlmacenamiento
				+ "\nCapacidad De Almacenamiento= " + getCapacidadDeAlmacenamiento() + " MB\nPantalla= " + sPantalla
				+ "\nTipodeBateria= " + sTipoDeBateria+"\n";
		
		
	}

}
