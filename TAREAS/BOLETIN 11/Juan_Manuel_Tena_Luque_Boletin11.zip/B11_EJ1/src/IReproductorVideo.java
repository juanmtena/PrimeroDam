
public interface IReproductorVideo extends IReproductorPortatil{

	public boolean isReproduceWMV();
	public void setReproduceWMV(boolean boolWMV);
	public boolean isReproduceDIVX();
	public void setReproduceDIVX(boolean boolDIVX);
	public boolean isReproduceMPG();
	public void setReproduceMPG(boolean boolMPG);
	public boolean isReproduceDVD();
	public void setReproduceDVD(boolean boolDVD);
	public boolean isReproduceJPG();
	public void setReproduceJPG(boolean boolJPG);
	public float getTamanyoDeLaPantalla();
	public void setTamanyoDeLaPantalla(float fTamanioPantalla);
	public boolean isTelevision();
	public void setTelevision(boolean boolSintonizar);
		
}
