
public class ReproductorVideo extends ReproductorPortatil implements IReproductorVideo{

	private boolean boolWMV;
	private boolean boolDIVX;
	private boolean boolMPG;
	private boolean boolDVD;
	private boolean boolJPG;
	private float fTamanioPantalla;
	private boolean boolSintonizar;
	
	public ReproductorVideo(String sMarca, String sModelo, float fTamanioPantalla) {
		super(sMarca, sModelo);
		
		setTamanyoDeLaPantalla(fTamanioPantalla);
	}
	
	public ReproductorVideo(String sMarca, String sModelo, boolean boolWMV, boolean boolDIVX, boolean boolMPG,
			boolean boolDVD, boolean boolJPG, float fTamanioPantalla, boolean boolSintonizar) {
		super(sMarca, sModelo);
		setReproduceWMV(boolWMV);
		setReproduceDIVX(boolDIVX);
		setReproduceMPG(boolMPG);
		setReproduceDVD(boolDVD);
		setReproduceJPG(boolJPG);
		setTamanyoDeLaPantalla(fTamanioPantalla);
		setTelevision(boolSintonizar);
	}

	public boolean isReproduceWMV() {
		return boolWMV;
	}

	public void setReproduceWMV(boolean boolWMV) {
		this.boolDIVX = boolWMV;
	}

	public boolean isReproduceDIVX() {
		return boolDIVX;
	}

	public void setReproduceDIVX(boolean boolDIVX) {
		this.boolDIVX = boolDIVX;
	}

	public boolean isReproduceMPG() {
		return boolMPG;
	}

	public void setReproduceMPG(boolean boolMPG) {
		this.boolMPG = boolMPG;
	}

	public boolean isReproduceDVD() {
		return boolDVD;
	}

	public void setReproduceDVD(boolean boolDVD) {
		this.boolDVD = boolDVD;
	}

	public boolean isReproduceJPG() {
		return boolJPG;
	}

	public void setReproduceJPG(boolean boolJPG) {
		this.boolJPG = boolJPG;	
	}

	public float getTamanyoDeLaPantalla() {
		return fTamanioPantalla;
	}

	public void setTamanyoDeLaPantalla(float fTamanioPantalla) {
		this.fTamanioPantalla = fTamanioPantalla;
	}

	public boolean isTelevision() {
		return boolSintonizar;
	}

	public void setTelevision(boolean boolSintonizar) {
		this.boolSintonizar = boolSintonizar;	
	}

	public String toString() {
		
		return "---Reproductor de Video---\nMarca= "+getsMarca()+"\nModelo= "+getsModelo()+"\nTama�o de Pantalla= "
				+getTamanyoDeLaPantalla()+" pulgadas";
	}
	
}
