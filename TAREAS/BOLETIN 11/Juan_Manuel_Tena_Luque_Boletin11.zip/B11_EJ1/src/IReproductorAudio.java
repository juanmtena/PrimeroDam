
public interface IReproductorAudio extends IReproductorPortatil{

	//Metodos traidos de IReproductorPortatil
	public String getsMarca();
	public void setsMarca(String sMarca);
	public String getsModelo();
	public void setsModelo(String sModelo);
	public boolean isReproduceSonido();
	public void setReproduceSonido(boolean boolSonido);
	public boolean isReproduceVideo();
	public void setReproduceVideo(boolean boolVideo);
	public byte getTipoDeAlmacenamiento();
	public void setTipoDeAlmacenamiento(byte bTipoDeAlmacenamiento);
	public byte getCapacidadDeAlmacenamiento();
	public void setCapacidadDeAlmacenamiento(byte bCapacidadDeAlmacenamiento);
	public byte getPantalla();
	public void setPantalla(byte bPantalla);
	public byte getTipodeBateria();
	public void setTipodeBateria(byte bTipoDeBateria);
	public byte getAutonomia();
	public void setAutonomia(byte bAutonomia);
	public float getPeso();
	public void setPeso(float fPeso);
	public float getAltura();
	public void setAltura(float fAltura);
	public float getGrosor();
	public void setGrosor(float fGrosor);
	//Metodos IReproductorAudio
	public boolean isReproduceAudioCDs();
	public void setReproduceAudioCDs(boolean reproduceAudioCDs);
	public boolean isReproduceMP3();
	public void setReproduceMP3(boolean reproduceMP3);
	public boolean isReporduceWMA();
	public void setReporduceWMA(boolean reporduceWMA);
	public boolean isReproduceVorbis();
	public void setReproduceVorbis(boolean reproduceVorbis);
	public boolean isAccesoPorCarpetas();
	public void setAccesoPorCarpetas(boolean accesoPorCarpetas);
	public boolean isRadio();
	public void setRadio(boolean radio);
	public boolean isGrabacionDeVoz();
	public void setGrabacionDeVoz(boolean grabacionDeVoz);
		
}
