
public class ReproductorMultimedia extends ReproductorPortatil implements IReproductorAudio, IReproductorVideo{

	private boolean boolWMV;
	private boolean boolDIVX;
	private boolean boolMPG;
	private boolean boolDVD;
	private boolean boolJPG;
	private float fTamanioPantalla;
	private boolean boolSintonizar;
	
	private boolean boolReproduceAudioCDs;
	private boolean boolReproduceMP3;
	private boolean boolReporduceWMA;
	private boolean boolReproduceVorbis;
	private boolean boolAccesoPorCarpetas;
	private boolean boolRadio;
	private boolean boolGrabacionDeVoz;

	public ReproductorMultimedia(String sMarca, String sModelo, boolean boolSonido,
			boolean boolVideo, byte bAutonomia, float fPeso, float fAltura, float fGrosor, byte bTipoDeAlmacenamiento,
			byte bCapacidadDeAlmacenamiento, byte bPantalla, byte bTipodeBateria, boolean boolWMV, boolean boolDIVX,
			boolean boolMPG, boolean boolDVD, boolean boolJPG, float fTamanioPantalla, boolean boolSintonizar,
			boolean boolReproduceAudioCDs, boolean boolReproduceMP3, boolean boolReporduceWMA,
			boolean boolReproduceVorbis, boolean boolAccesoPorCarpetas, boolean boolRadio, boolean boolGrabacionDeVoz) {
		super(sMarca, sModelo, boolSonido, boolVideo, bAutonomia, fPeso, fAltura, fGrosor, bTipoDeAlmacenamiento,
				bCapacidadDeAlmacenamiento, bPantalla, bTipodeBateria);
		setReproduceWMV(boolWMV);
		setReproduceDIVX(boolDIVX);
		setReproduceMPG(boolMPG);
		setReproduceDVD(boolDVD);
		setReproduceJPG(boolJPG);
		setTamanyoDeLaPantalla(fTamanioPantalla);
		setTelevision(boolSintonizar);
		setReproduceAudioCDs(boolReproduceAudioCDs);
		setReproduceMP3(boolReproduceMP3);
		setReporduceWMA(boolReporduceWMA);
		setReproduceVorbis(boolReproduceVorbis);
		setAccesoPorCarpetas(boolAccesoPorCarpetas);
		setRadio(boolRadio);
		setGrabacionDeVoz(boolGrabacionDeVoz);
	}

	public boolean isReproduceWMV() {
		return boolWMV;
	}

	public void setReproduceWMV(boolean boolWMV) {
		this.boolWMV = boolWMV;
	}

	public boolean isReproduceDIVX() {
		return boolDIVX;
	}

	public void setReproduceDIVX(boolean boolDIVX) {
		this.boolDIVX = boolDIVX;
	}

	public boolean isReproduceMPG() {
		return boolMPG;
	}

	public void setReproduceMPG(boolean boolMPG) {
		this.boolMPG = boolMPG;
	}

	public boolean isReproduceDVD() {
		return boolDVD;
	}

	public void setReproduceDVD(boolean boolDVD) {
		this.boolDVD = boolDVD;
	}

	public boolean isReproduceJPG() {
		return boolJPG;
	}

	public void setReproduceJPG(boolean boolJPG) {
		this.boolJPG = boolJPG;
	}

	public float getTamanyoDeLaPantalla() {
		return fTamanioPantalla;
	}

	public void setTamanyoDeLaPantalla(float fTamanioPantalla) {
		this.fTamanioPantalla = fTamanioPantalla;
	}

	public boolean isTelevision() {
		return boolSintonizar;
	}

	public void setTelevision(boolean boolSintonizar) {
		this.boolSintonizar = boolSintonizar;
	}

	public boolean isReproduceAudioCDs() {
		return boolReproduceAudioCDs;
	}

	public void setReproduceAudioCDs(boolean boolReproduceAudioCDs) {
		this.boolReproduceAudioCDs = boolReproduceAudioCDs;
	}

	public boolean isReproduceMP3() {
		return boolReproduceMP3;
	}

	public void setReproduceMP3(boolean boolReproduceMP3) {
		this.boolReproduceMP3 = boolReproduceMP3;
	}

	public boolean isReporduceWMA() {
		return boolReporduceWMA;
	}

	public void setReporduceWMA(boolean boolReporduceWMA) {
		this.boolReporduceWMA = boolReporduceWMA;
	}

	public boolean isReproduceVorbis() {
		return boolReproduceVorbis;
	}

	public void setReproduceVorbis(boolean boolReproduceVorbis) {
		this.boolReproduceVorbis = boolReproduceVorbis;
	}

	public boolean isAccesoPorCarpetas() {
		return boolAccesoPorCarpetas;
	}

	public void setAccesoPorCarpetas(boolean boolAccesoPorCarpetas) {
		this.boolAccesoPorCarpetas = boolAccesoPorCarpetas;
	}

	public boolean isRadio() {
		return boolRadio;
	}

	public void setRadio(boolean boolRadio) {
		this.boolRadio = boolRadio;
	}

	public boolean isGrabacionDeVoz() {
		return boolGrabacionDeVoz;
	}

	public void setGrabacionDeVoz(boolean boolGrabacionDeVoz) {
		this.boolGrabacionDeVoz = boolGrabacionDeVoz;
	}
	
	public String toString() {
		
		String sTipoDeAlmacenamiento = "";
        String sTipoDeBateria = "";
        String sPantalla = "";
        
        if (getTipoDeAlmacenamiento() == bCD) {
            sTipoDeAlmacenamiento += "CD";
        } else if (getTipoDeAlmacenamiento() == bDVD) {
            sTipoDeAlmacenamiento += "DVD";
        } else if (getTipoDeAlmacenamiento() == bMEMORIAFLASH) {
            sTipoDeAlmacenamiento += "MemoriaFlash";
        } else if (getTipoDeAlmacenamiento() == bMINIDISK) {
            sTipoDeAlmacenamiento += "Minidisk";
        } else {
            sTipoDeAlmacenamiento += "Tipo de almacenamiento no valido";
        }

        if (getPantalla() == bNINGUNA) {
            sPantalla += "Ninguna";
        } else if (getPantalla() == bTEXTO) {
            sPantalla += "texto";
        } else if (getPantalla() == bMONOCROMO) {
            sPantalla += "Monocromo";
        } else if (getPantalla() == bCOLOR) {
            sPantalla += "Color";
        } else {
            sPantalla += "Tipo de pantalla no valido";
        }

        if (getTipodeBateria() == bPILAS) {
            sTipoDeBateria += "Pilas";
        } else if (getTipodeBateria() == bLILON) {
            sTipoDeBateria += "Lilon";
        } else {
            sTipoDeBateria += "Tipo de bateria no valido";
        }
		
		return "\n---Reproductor Multimedia---\nMarca= " + getsMarca() + "\nModelo= " + getsModelo() + "\nReproduce Sonido= " + isReproduceSonido()
				+ "\nReproduce Video= " + isReproduceVideo() + "\nAutonomia= " + getAutonomia() + " h\nPeso= " + getPeso() + " gramos\nAltura= "
				+ getAltura() + " cm\nGrosor= " + getGrosor() + " mm\nTipoDeAlmacenamiento= " + sTipoDeAlmacenamiento
				+ "\nCapacidadDeAlmacenamiento= " + getCapacidadDeAlmacenamiento() + " MB\nPantalla= " + sPantalla
				+ "\nTipodeBateria= " + sTipoDeBateria+"\nReprodcue WMV= "+isReproduceWMV()+"\nReproduce DIVX= "+isReproduceDIVX()
				+"\nReproduce MPG= "+isReproduceMPG()+"\nRproduce DVD= "+isReproduceDVD()+"\nReproduce JPG= "+isReproduceJPG()+"\nTama�o de Pantalla= "
				+getTamanyoDeLaPantalla()+" pulgadas\nSintoniza Television= "+isTelevision()+"\nReproduce CDs= "+isReproduceAudioCDs()+"\nReproduce MP3= "
				+isReproduceMP3()+"\nReproduce WMA= "+isReporduceWMA()+"\nReproduce Vorbis= "+isReproduceVorbis()+"\nTiene acceso por carpetas= "
				+isAccesoPorCarpetas()+"\nSintoniza radio = "+isRadio()+"\nTiene grabadora de voz= "+isGrabacionDeVoz();
	}
	
}
