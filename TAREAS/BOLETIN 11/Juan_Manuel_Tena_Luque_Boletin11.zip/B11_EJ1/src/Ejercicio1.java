
public class Ejercicio1 {

	public static void main(String[] args) {

		IReproductorPortatil rp = new ReproductorPortatil("HP", "Pavilion", false, true, (byte) 1, (float) 125.50, (float) 1,
				(float) 1, (byte) 1, (byte) 1, (byte) 1, (byte) 1);
		System.out.println(rp);
		
		IReproductorAudio ra = new ReproductorDeAudio("Xiaomi", "Beep", (byte)2, true, true, true, true);
		//ra.isReproduceAudioCDs();
		System.out.println(ra.toString());
		
		IReproductorVideo rv = new ReproductorVideo("Samsung","QLED14568K",(float)32.3);
		System.out.println(rv.toString());
		
		//Problema 2
		ReproductorMultimedia rm = new ReproductorMultimedia("Lenovo", "StreamPost", false, false, (byte)3, (float)2.5, (float)10.25, (float)2, (byte)1, (byte)1, (byte)3, (byte)2, false, 
				false, false, false, false, 0, false, false, false, false, false, false, false, false);
		System.out.println(rm.toString());
		
	}

}
