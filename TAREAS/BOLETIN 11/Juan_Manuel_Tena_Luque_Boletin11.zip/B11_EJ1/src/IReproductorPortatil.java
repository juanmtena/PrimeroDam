
public interface IReproductorPortatil {

	public final byte bCD = 1;
	public final byte bDVD = 2;
	public final byte bMEMORIAFLASH = 3;
	public final byte bMINIDISK = 4;
	public final byte bNINGUNA = 1;
	public final byte bTEXTO = 2;
	public final byte bMONOCROMO = 3;
	public final byte bCOLOR = 4;
	public final byte bPILAS = 1;
	public final byte bLILON = 2;
	public String getsMarca();
	public void setsMarca(String sMarca);
	public String getsModelo();
	public void setsModelo(String sModelo);
	public boolean isReproduceSonido();
	public void setReproduceSonido(boolean boolSonido);
	public boolean isReproduceVideo();
	public void setReproduceVideo(boolean boolVideo);
	public byte getTipoDeAlmacenamiento();
	public void setTipoDeAlmacenamiento(byte bTipoDeAlmacenamiento);
	public byte getCapacidadDeAlmacenamiento();
	public void setCapacidadDeAlmacenamiento(byte bCapacidadDeAlmacenamiento);
	public byte getPantalla();
	public void setPantalla(byte bPantalla);
	public byte getTipodeBateria();
	public void setTipodeBateria(byte bTipoDeBateria);
	public byte getAutonomia();
	public void setAutonomia(byte bAutonomia);
	public float getPeso();
	public void setPeso(float fPeso);
	public float getAltura();
	public void setAltura(float fAltura);
	public float getGrosor();
	public void setGrosor(float fGrosor);
	String toString();
	
}
