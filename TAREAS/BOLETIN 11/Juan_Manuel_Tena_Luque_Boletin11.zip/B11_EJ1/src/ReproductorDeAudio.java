
public class ReproductorDeAudio extends ReproductorPortatil implements IReproductorAudio{
	
	private boolean boolReproduceAudioCDs;
	private boolean boolReproduceMP3;
	private boolean boolReporduceWMA;
	private boolean boolReproduceVorbis;
	private boolean boolAccesoPorCarpetas;
	private boolean boolRadio;
	private boolean boolGrabacionDeVoz;

	public ReproductorDeAudio(String sMarca, String sModelo, byte bTipoDeAlmacenamiento, boolean boolReproduceAudioCDs, boolean boolReproduceMP3,
			boolean boolReporduceWMA, boolean boolReproduceVorbis) {
		super(sMarca, sModelo, bTipoDeAlmacenamiento);
		
		setsMarca(sMarca);
		setsModelo(sModelo);
		setTipoDeAlmacenamiento(bTipoDeAlmacenamiento);
		setReproduceAudioCDs(boolReproduceAudioCDs);
		setReproduceMP3(boolReproduceMP3);
		setReporduceWMA(boolReporduceWMA);
		setReproduceVorbis(boolReproduceVorbis);
	}
		
	public boolean isReproduceAudioCDs() {
		return boolReproduceAudioCDs;
	}

	public void setReproduceAudioCDs(boolean boolReproduceAudioCDs) {
		if(getTipoDeAlmacenamiento() != 1) {
			this.boolReproduceAudioCDs = false;
		}else {
			this.boolReproduceAudioCDs = boolReproduceAudioCDs;
		}
	}

	public boolean isReproduceMP3() {
		return boolReproduceMP3;
	}

	
	public void setReproduceMP3(boolean boolReproduceMP3) {
		if (boolReproduceMP3 == true) {
			this.boolReproduceMP3 = boolReproduceMP3;
		}		
	}

	public boolean isReporduceWMA() {
		return boolReporduceWMA;
	}

	public void setReporduceWMA(boolean boolReporduceWMA) {
		if (boolReporduceWMA == true) {
			this.boolReporduceWMA = boolReporduceWMA;
		}
	}

	public boolean isReproduceVorbis() {
		return boolReproduceVorbis;
	}

	public void setReproduceVorbis(boolean boolReproduceVorbis) {
		if (boolReproduceVorbis == true) {
			this.boolReproduceVorbis = boolReproduceVorbis;
		}		
	}

	public boolean isAccesoPorCarpetas() {
		return boolAccesoPorCarpetas;
	}

	public void setAccesoPorCarpetas(boolean boolAccesoPorCarpetas) {
		if (boolAccesoPorCarpetas == true) {
			this.boolAccesoPorCarpetas = boolAccesoPorCarpetas;
		}
	}

	public boolean isRadio() {
		return boolRadio;
	}

	public void setRadio(boolean boolRadio) {
		if (boolRadio == true) {
			this.boolRadio = boolRadio;
		}
	}

	public boolean isGrabacionDeVoz() {
		return boolGrabacionDeVoz;
	}

	public void setGrabacionDeVoz(boolean boolGrabacionDeVoz) {
		if (boolGrabacionDeVoz == true) {
			this.boolGrabacionDeVoz = boolGrabacionDeVoz;
		}
	}
	
	public String toString() {
		
		String sTipoDeAlmacenamiento = "";
		
		if (getTipoDeAlmacenamiento() == bCD) {
            sTipoDeAlmacenamiento += "CD";
        } else if (getTipoDeAlmacenamiento() == bDVD) {
            sTipoDeAlmacenamiento += "DVD";
        } else if (getTipoDeAlmacenamiento() == bMEMORIAFLASH) {
            sTipoDeAlmacenamiento += "MemoriaFlash";
        } else if (getTipoDeAlmacenamiento() == bMINIDISK) {
            sTipoDeAlmacenamiento += "Minidisk";
        } else {
            sTipoDeAlmacenamiento += "Tipo de almacenamiento no valido";
        }
				
		return "---Reproductor de Audio---\nMarca= "+getsMarca()+"\nModelo= "+getsModelo()+"\nTipo De Almacenamiento= "
		+sTipoDeAlmacenamiento+"\nReproduce Cds= "+isReproduceAudioCDs()+"\nReproduce MP3= "+isReproduceMP3()+"\nRproduce WMA= "+isReporduceWMA()+
		"\nReproduce Vorbis= "+isReproduceVorbis()+"\n";
	}
	
}
