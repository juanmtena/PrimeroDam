
public interface IBonoBus {

	public boolean isPicarViaje();
	public void setPicarViaje(byte bLineaBus, byte bDia, byte bMes, short shAnio, byte bHora, byte bMinutos);
	
	
}
