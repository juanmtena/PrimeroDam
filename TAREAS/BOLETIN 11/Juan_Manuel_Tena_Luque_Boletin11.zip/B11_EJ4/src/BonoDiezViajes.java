
public class BonoDiezViajes implements IBonoBus{

	private byte bBonoDiezViajes = 10;
	protected boolean boolPicarBillete;
	
	public byte getbBonoDiezViajes() {
		return bBonoDiezViajes;
	}

	public void setbBonoDiezViajes(byte bBonoDiezViajes) {
		this.bBonoDiezViajes = bBonoDiezViajes;
	}
	
	public boolean isPicarViaje() {
		if (bBonoDiezViajes != 0) {
			bBonoDiezViajes -= 1;
			this.boolPicarBillete = true;
		}else {
			this.boolPicarBillete = false;
		}
		return boolPicarBillete;
	}

	public void setPicarViaje(byte bLineaBus, byte bDia, byte bMes, short shAnio, byte bHora, byte bMinutos) {
		
	}

	
	

}
