
public class BonoDiezViajesConTrasbordo implements IBonoBus extends BonoDiezViajes {

	private byte bLineaBus;
	private byte bDia;
	private byte bMes;
	private short shAnio;
	private byte bHora;
	private byte bMinutos;
	
	public byte getbLineaBus() {
		return bLineaBus;
	}

	public void setbLineaBus(byte bLineaBus) {
		if(bLineaBus < 125) {
			this.bLineaBus = bLineaBus;
		}
	}

	public byte getbDia() {
		return bDia;
	}

	public void setbDia(byte bDia) {
		if (bDia == 32) {
			this.bDia = bDia;
		}
	}

	public byte getbMes() {
		return bMes;
	}

	public void setbMes(byte bMes) {
		if (bMes < 13) {
			this.bMes = bMes;
		}
	}

	public short getShAnio() {
		return shAnio;
	}

	public void setShAnio(short shAnio) {
		if (shAnio == 2021) {
			this.shAnio = shAnio;
		}
	}

	public byte getbHora() {
		return bHora;
	}

	public void setbHora(byte bHora) {
		if (bHora >= 0 && bHora < 24) {
			this.bHora = bHora;
		}
	}

	public byte getbMinutos() {
		return bMinutos;
	}

	public void setbMinutos(byte bMinutos) {
		if (bMinutos >= 0 && bMinutos < 60) {
			this.bMinutos = bMinutos;
		}
	}
	
	public boolean getbViajes() {
		return boolPicarBillete;
	}

	public void setbViajes(byte bLineaBus, byte bDia, byte bMes, short shAnio, byte bHora, byte bMinutos) {
		this.boolPicarBillete = boolPicarBillete;
	}
	
	public byte setBonoDiezViajes() {
		return bBonoDiezViajes;
	} 
	
	public void setBonoDiezViajes(byte bBonoDiezViajes) {
		if (bBonoDiezViajes > 0 && bBonoDiezViajes < 11) {
			bBonoDiezViajes -= 1;
			boolPicarBillete = true;
		}else {
			boolPicarBillete = false;
		}
	}

	
}
