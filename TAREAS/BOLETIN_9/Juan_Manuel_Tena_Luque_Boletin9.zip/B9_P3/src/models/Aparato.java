package models;

public class Aparato {

	private boolean boolIntAparato;
	private boolean boolIntGeneral;
	
	public Aparato(boolean boolIntGeneral, boolean boolIntAparato) {
		
		setBoolIntAparato(boolIntAparato);
		setBoolIntGeneral(boolIntGeneral);
	}

	public boolean isBoolIntAparato() {
		return boolIntAparato;
	}

	public void setBoolIntAparato(boolean boolIntAparato) {
		this.boolIntAparato = boolIntAparato;
	}
	

	public boolean isBoolIntGeneral() {
		return boolIntGeneral;
	}

	public void setBoolIntGeneral(boolean boolIntGeneral) {
		this.boolIntGeneral = boolIntGeneral;
	}	
	
	public boolean cambiarIntAparato() {
		if(isBoolIntGeneral() == true && isBoolIntAparato() == false) {
			boolIntAparato = true;
		}else if(isBoolIntGeneral() == true && isBoolIntAparato() == true) {
			boolIntAparato = false;
		}
		return boolIntAparato;
	}
	
	public boolean cambiarIntGeneral() {
		if(isBoolIntGeneral() == true) {
			boolIntGeneral = false;
		}else if(isBoolIntGeneral() == false) {
			boolIntGeneral = true;
		}
		return boolIntGeneral;
	}
	
	public String encendidoApagado() {
		String sMensaje = "";
		if (isBoolIntGeneral() == true && isBoolIntAparato() == true) {
			sMensaje += "General ON     \nAparato ON\n";
			sMensaje += "El aparato esta encendido\n";
		}else if(isBoolIntGeneral() == true && isBoolIntAparato() == false) {
			sMensaje += "General ON     \nAparato OFF\n";
			sMensaje += "El aparato esta apagado\n";
		}else if(isBoolIntGeneral() == false && isBoolIntAparato() == true) {
			sMensaje += "General OFF     \nAparato ON\n";
			sMensaje += "El aparato esta apagado\n";
		}else {
			sMensaje += "General OFF     \nAparato OFF\n";
			sMensaje += "El aparato esta apagado\n";
		}
		return sMensaje;
	}
	 
	public String cambiarGeneral() {
		String sMensaje = "";
		
		if (isBoolIntGeneral() == false) {
			sMensaje = "General OFF     \nAparato OFF\n";
		}else if(isBoolIntGeneral() == true && isBoolIntAparato() == true){
			sMensaje = "General ON     \nAparato ON\n";
		}else if(isBoolIntGeneral() == true && isBoolIntAparato() == false) {
			sMensaje = "General ON     \nAparato OFF\n";
		}
		return sMensaje;
	}
	
	public String cambiarAparato() {
		String sMensaje = "";
		
		if (isBoolIntGeneral() == true && cambiarIntAparato() == false) {
			sMensaje = "General ON     \nAparato OFF\n";
		}else if (isBoolIntGeneral() == true && cambiarIntAparato() == true) { 
			sMensaje = "General ON     \nAparato ON\n";
		}else if(isBoolIntGeneral() == false) {
			sMensaje = "General OFF     \nAparato OFF\n";
		}
		
		return sMensaje;
	}
	
}