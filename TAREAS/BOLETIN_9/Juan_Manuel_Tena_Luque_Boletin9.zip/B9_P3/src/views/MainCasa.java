package views;

import models.Aparato;

public class MainCasa {

	public static void main(String[] args) {
		
		Aparato ap = new Aparato(false,true);//General, aparato
		System.out.println(ap.encendidoApagado());
		System.out.println(ap.cambiarGeneral());
		System.out.println(ap.cambiarAparato());

	}

}