package view;

public class Reloj {

	private int iHora;
	private int iMinutos;
	private int iSegundos;
	
	public Reloj() {
		
	}

	public Reloj(int iHora, int iMinutos, int iSegundos) {
		
		setiHora(iHora);
		setiMinutos(iMinutos);
		setiSegundos(iSegundos);
	}

	public int getiHora() {
		return iHora;
	}

	public void setiHora(int iHora) {
		if(getiHora() >= 0 && getiHora() < 24) {
			this.iHora = iHora;
		}
	}

	public int getiMinutos() {
		return iMinutos;
	}

	public void setiMinutos(int iMinutos) {
		if (getiMinutos() >= 0 && getiMinutos() <= 59) {
			this.iMinutos = iMinutos;
		}
	}

	public int getiSegundos() {
		return iSegundos;
	}

	public void setiSegundos(int iSegundos) {
		if (getiSegundos() >= 0 && getiSegundos() <= 59) {
			this.iSegundos = iSegundos;
		}
	}
	
	public String mostrarHora() {
		String sMostrar = "";
		
		if (getiHora() >= 0 && getiHora() <= 11 && getiMinutos() <= 59 && getiSegundos() <= 59) {
			sMostrar = getiHora()+":"+getiMinutos()+":"+getiSegundos()+" AM";
		}else {
			sMostrar = getiHora()+":"+getiMinutos()+":"+getiSegundos()+" PM";
		}
		return sMostrar;
	}
	
	//Mostrar solo hora y minutos, los segundos a 0
	public String ponerEnHora(int iHora, int iMinutos) {
		String sMensaje = "";
		
		if (iHora >= 0 && iHora <= 11 && iMinutos <= 59) {
			sMensaje = iHora+":"+iMinutos+":"+getiSegundos()+" AM";
		}else {
			sMensaje = iHora+":"+iMinutos+":"+getiSegundos()+" PM";
		}
		return sMensaje;
	}
	
	//Mostrar horas, miutos y segundos introducidos
	public String ponerEnHoraTodo(int iHora, int iMinutos, int iSegundos) {
		String sMensaje = "";
		
		if (iHora >= 0 && iHora <= 11 && iMinutos <= 59) {
			sMensaje = iHora+":"+iMinutos+":"+iSegundos+" AM";
		}else {
			sMensaje = iHora+":"+iMinutos+":"+iSegundos+" PM";
		}
		return sMensaje;
	}
	
}
