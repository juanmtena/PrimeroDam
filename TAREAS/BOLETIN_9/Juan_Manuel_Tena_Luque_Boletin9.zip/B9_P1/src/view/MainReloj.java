package view;

import models.Reloj;

public class MainReloj {

	public static void main(String[] args) {
		
		Reloj r = new Reloj(); 
		System.out.println(r.mostrarHora24());
		System.out.println(r.mostrarHora24AMoPM());
		System.out.println(r.ponerEnHora(9,32));
		System.out.println(r.ponerEnHoraTodo(12,32,59));
		
		r.especificar("pm", 15,25,10);
		System.out.println(r.mostrarHora24AMoPM());
	}
	
}