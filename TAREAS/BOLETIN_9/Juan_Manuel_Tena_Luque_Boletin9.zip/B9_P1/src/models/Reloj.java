package models;

public class Reloj {

	private int iHora;
	private int iMinutos;
	private int iSegundos;
	
	public Reloj() {
		
	}

	public Reloj(int iHora, int iMinutos, int iSegundos) {
		
		setiHora(iHora);
		setiMinutos(iMinutos);
		setiSegundos(iSegundos);
	}

	public int getiHora() {
		return iHora;
	}

	public void setiHora(int iHora) {
		if(iHora >= 0 && iHora < 24) {
			this.iHora = iHora;
		}
	}

	public int getiMinutos() {
		return iMinutos;
	}

	public void setiMinutos(int iMinutos) {
		if (iMinutos >= 0 && iMinutos <= 59) {
			this.iMinutos = iMinutos;
		}
	}

	public int getiSegundos() {
		return iSegundos;
	}

	public void setiSegundos(int iSegundos) {
		if (iSegundos >= 0 && iSegundos <= 59) {
			this.iSegundos = iSegundos;
		}
	}
	
	//Mostrar hora, minutos y segundos separados con ":"
	public String mostrarHora24() {
		String sMostrar = "";
		
		if (getiHora() >= 0 && getiHora() <= 11 && getiMinutos() <= 59 && getiSegundos() <= 59) {
			sMostrar = getiHora()+":"+getiMinutos()+":"+getiSegundos();
		}else {
			sMostrar = getiHora()+":"+getiMinutos()+":"+getiSegundos();
		}
		return sMostrar;
	}
	
	//Mostrar hora, minutos y segundos separados con ":" y si es AM o PM
	public String mostrarHora24AMoPM() {
		String sMostrar = "";
		
		if (getiHora() >= 0 && getiHora() <= 11 && getiMinutos() <= 59 && getiSegundos() <= 59) {
			sMostrar = getiHora()+":"+getiMinutos()+":"+getiSegundos()+" AM";
		}else {
			sMostrar = getiHora()+":"+getiMinutos()+":"+getiSegundos()+" PM";
		}
		return sMostrar;
	}
	
	//Mostrar solo hora y minutos, los segundos a 0
	public String ponerEnHora(int iHora, int iMinutos) {
		String sMensaje = "";
		
		if (iHora >= 0 && iHora <= 11 && iMinutos <= 59) {
			sMensaje = iHora+":"+iMinutos+":"+getiSegundos()+" AM";
		}else {
			sMensaje = iHora+":"+iMinutos+":"+getiSegundos()+" PM";
		}
		return sMensaje;
	}
	
	//Mostrar horas, miutos y segundos introducidos
	public String ponerEnHoraTodo(int iHora, int iMinutos, int iSegundos) {
		String sMensaje = "";
		
		if (iHora >= 0 && iHora <= 11 && iMinutos <= 59) {
			sMensaje = iHora+":"+iMinutos+":"+iSegundos+" AM";
		}else {
			sMensaje = iHora+":"+iMinutos+":"+iSegundos+" PM";
		}
		return sMensaje;
	}
	
	//Especificar si es AM o PM
	public void especificar(String sHora, int iHora, int iMinutos, int iSegundos) {
		
		if (sHora == "am" && iHora >= 0 && iHora <= 11 && iMinutos <= 59 && getiSegundos() <= 59) {
			this.iHora = iHora;
			this.iMinutos = iMinutos;
			this.iSegundos = iSegundos;
		}else if(sHora == "pm" && iHora >= 11 && iHora <= 23 && iMinutos <= 59 && getiSegundos() <= 59){
			this.iHora = iHora;
			this.iMinutos = iMinutos;
			this.iSegundos = iSegundos;
		}else {
			this.iHora = 0;
			this.iMinutos = 0;
			this.iSegundos = 0;
		}
	}
	
}
