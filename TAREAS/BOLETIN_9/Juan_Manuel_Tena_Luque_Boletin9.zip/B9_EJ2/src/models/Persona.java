package models;

public class Persona {
	
	private final int MAXCARACTERES = 250;
	private String sNombre; //NN
	private String sApellido1; //PK
	private String sApellido2; //NN
	private int iEdad;  //NN
	private double dEstatura; //NN
	private double dPeso; //NN
	private int iEstado; //NN
	
	public Persona(String sNombre, String sApellido1, String sApellido2) {
		
		this.sNombre = sNombre;
		this.sApellido1 = sApellido1;
		this.sApellido2 = sApellido2;
	}

	public Persona(String sNombre, String sApellido1, String sApellido2, int iEdad, double dEstatura, double dPeso,
			int iEstado) {
		
		this.sNombre = sNombre;
		this.sApellido1 = sApellido1;
		this.sApellido2 = sApellido2;
		this.iEdad = iEdad;
		this.dEstatura = dEstatura;
		this.dPeso = dPeso;
		this.iEstado = iEstado;
	}

	public String getsNombre() {
		return sNombre;
	}

	public void setsNombre(String sNombre) {
		if (sNombre != null && sNombre.length() < MAXCARACTERES) {
			this.sNombre = sNombre;
		}
	}

	public String getsApellido1() {
		return sApellido1;
	}

	public void setsApellido1(String sApellido1) {
		if (sApellido1 != null && sNombre.length() < MAXCARACTERES) {
			this.sApellido1 = sApellido1;
		}
	}

	public String getsApellido2() {
		return sApellido2;
	}

	public void setsApellido2(String sApellido2) {
		if (sApellido2 != null && sNombre.length() < MAXCARACTERES) {
			this.sApellido2 = sApellido2;
		}
	}

	public int getiEdad() {
		return iEdad;
	}

	public void setiEdad(int iEdad) {
		if(iEdad > this.iEdad && iEdad > 0 && iEdad <= 150) {
			this.iEdad = iEdad;
		}
	}

	public double getdEstatura() {
		return dEstatura;
	}

	public void setdEstatura(double dEstatura) {
		if(dEstatura > 0 && dEstatura <= 3) {
			this.dEstatura = dEstatura;
		}
	}

	public double getdPeso() {
		return dPeso;
	}

	public void setdPeso(double dPeso) {
		if(dPeso  > 0 && dPeso <= 300) {
			this.dPeso = dPeso;
		}
	}

	public int getiEstado() {
		return iEstado;
	}

	public void setiEstado(int iEstado) {
		if(iEstado == 0 && iEstado <= 5) {
			this.iEstado = iEstado;
		}else if(this.iEstado == 1 && iEstado == 2) {
			this.iEstado = iEstado;
		}else if(this.iEstado == 2 && iEstado != 1) {
			this.iEstado = iEstado;
		}else if(this.iEstado == 3 && iEstado == 4 || iEstado == 5) {
			this.iEstado = iEstado;
		}else if(this.iEstado == 4 && iEstado == 2) {
			this.iEstado = iEstado;
		}else if(this.iEstado == 5 && iEstado == 2) {
			this.iEstado = iEstado;
		}
	}
	
	public String imprimirEstado() {
		String sMensaje = "";

		if(iEstado == 1) {
			sMensaje += "SOLTERO/A";
		}else if(iEstado == 2) {
			sMensaje += "CASADO/A";
		}else if(iEstado == 3) {
			sMensaje += "SEPARADO/A";
		}else if(iEstado == 4) {
			sMensaje += "DIVORCIADO/A";
		}else if(iEstado == 5) {
			sMensaje += "VIUDO/A";
		}else {
			sMensaje += "ERROR. Estado no valido";
		}
		return sMensaje;
	}
		
}
