package view;

import models.Persona;

public class Main {

	public static void main(String[] args) {
		
		Persona p = new Persona("juan","tena","luque",15,1.75,75,5);
		p.setiEstado(2); //Modificar el estado
		System.out.println(p.imprimirEstado());
		p.setiEdad(25); //Modifico la edad
		System.out.println(p.getiEdad());
	}

}
