package views;

import models.Numero;

public class MainNumero {

	public static void main(String[] args) {
		
		Numero n = new Numero(5);
		System.out.println("La suma es: "+n.sumar(12.5));
		System.out.println("La resta es: "+n.restar(3.5));
		System.out.println("La multiplicacion es: "+n.multiplicar(5));
		System.out.println("La division es: "+n.division(2));		

	}

}
