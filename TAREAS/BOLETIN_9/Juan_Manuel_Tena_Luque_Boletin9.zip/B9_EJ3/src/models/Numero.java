package models;

public class Numero {

	private double dNumero;

	public Numero(int iNumero) {
		this.dNumero = iNumero;
	}
	
	public Numero(long lNumero) {
		this.dNumero = lNumero;
	}
	
	public Numero(float fNumero) {
		this.dNumero = fNumero;
	}
	
	public Numero(double dNumero) {
		this.dNumero = dNumero;
	}

	public double getInt() {
		return dNumero;
	}

	public void setInt(int iNumero) {
		this.dNumero = (int) iNumero;
	}
	
	public double getLong() {
		return dNumero;
	}
	
	public void setLong(long lNumero) {
		this.dNumero = (long) lNumero;
	}
	
	public double getFloat() {
		return dNumero;
	}
	
	public void setFloat(float fNumero) {
		this.dNumero = (float) fNumero;
	}
	
	public double getDouble() {
		return dNumero;
	}
	
	public void setDouble(double dNumero) {
		this.dNumero = dNumero;
	}
	
	//Metodos sumar
	public int sumar(int iNumeroNuevo) {
		int iResultado;
		iResultado = (int) (iNumeroNuevo + getInt());
		return iResultado;
	}
	
	public long sumar(long lNumeroNuevo) {
		long lResultado;
		lResultado = (long) (lNumeroNuevo + getLong());
		return lResultado;
	}
	
	public float sumar(float fNumeroNuevo) {
		long fResultado;
		fResultado = (long) (fNumeroNuevo + getFloat());
		return fResultado;
	}
	
	public double sumar(double dNumeroNuevo) {
		double dResultado;
		dResultado = (double) (dNumeroNuevo + getDouble());
		return dResultado;
	}
	
	//Metodo restar
	public int restar(int iNumeroNuevo) {
		int iResultado;
		iResultado = (int) (getInt() - iNumeroNuevo);
		return iResultado;
	}
	
	public long restar(long lNumeroNuevo) {
		long lResultado;
		lResultado = (long) (getLong() - lNumeroNuevo);
		return lResultado;
	}
	
	public float restar(float fNumeroNuevo) {
		long fResultado;
		fResultado = (long) (getFloat() - fNumeroNuevo);
		return fResultado;
	}
	
	public double restar(double dNumeroNuevo) {
		double dResultado;
		dResultado = (double) (getDouble() - dNumeroNuevo);
		return dResultado;
	}
	
	//Metodo multiplicar
	public int multiplicar(int iNumeroNuevo) {
		int iResultado;
		iResultado = (int) (getInt() * iNumeroNuevo);
		return iResultado;
	}
	
	public long multiplicar(long lNumeroNuevo) {
		long lResultado;
		lResultado = (long) (getLong() * lNumeroNuevo);
		return lResultado;
	}
	
	public float multiplicar(float fNumeroNuevo) {
		long fResultado;
		fResultado = (long) (getFloat() * fNumeroNuevo);
		return fResultado;
	}
	
	public double multiplicar(double dNumeroNuevo) {
		double dResultado;
		dResultado = (double) (getDouble() * dNumeroNuevo);
		return dResultado;
	}
	
	//Metodo division
	public int division(int iNumeroNuevo) {
		int iResultado = 0;
		if (iNumeroNuevo != 0) {
			iResultado = iNumeroNuevo;
		}else {
			iResultado = (int) (getInt() / iNumeroNuevo);
		}
		return iResultado;
	}
	
	public long division(long lNumeroNuevo) {
		long lResultado = 0;
		if (lNumeroNuevo != 0) {
			lResultado = lNumeroNuevo;
		}else {
			lResultado = (long) (getLong() / lNumeroNuevo);
		}
		return lResultado;
	}
	
	public float division(float fNumeroNuevo) {
		float fResultado = 0;
		if (fNumeroNuevo != 0) {
			fResultado = fNumeroNuevo;
		}else {
			fResultado = (long) (getFloat() / fNumeroNuevo);
		}
		return fResultado;
	}
	
	public double division(double dNumeroNuevo) {
		double dResultado = 0;
		if (dNumeroNuevo != 0) {
			dResultado = dNumeroNuevo;
		}else {
			dResultado = (double) (getDouble() / dNumeroNuevo);
		}
		return dResultado;
	}
	
}
