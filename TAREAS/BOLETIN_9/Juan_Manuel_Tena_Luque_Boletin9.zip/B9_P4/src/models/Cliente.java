package models;

public class Cliente {
	
	private String sNombre;
	private float fSaldo;
	private String[] aHistorialArticulos = new String[10];
	private String[] aHistorialFechas = new String[10];
	private String[] aCarrito = new String[10];
	private String sTienda;
	private int iTamanioCarrito;
	private int iTamanioHistorial;
	
	

	public void mostrarSaldo() {
		
	}

	public void mostrarHistorial() {
		
	}

	public void mostrarCarrito() {
		
	}

}
