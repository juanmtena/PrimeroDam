package models;
import java.util.*;
import models.Libreria;

public class Tienda {

	private int iNumeArticulos;
	private int iNumClientes;
	private String[] aArticulos = new String[10];
	private int[] aCantidades = new int[10];
	private int[] aCliente = new int[10];
	
	public Tienda(int[] aArticulo) {
		this.aArticulos = aArticulos;
	}

	public Tienda(int iNumeArticulos, int iNumClientes, String[] aArticulo, int[] aCantidades,
			int[] aCliente) {
		this.iNumeArticulos = iNumeArticulos;
		this.iNumClientes = iNumClientes;
		this.aArticulos = aArticulos;
		this.aCantidades = aCantidades;
		this.aCliente = aCliente;
	}

	public int getiNumeArticulos() {
		return iNumeArticulos;
	}

	public void setiNumeArticulos(int iNumeArticulos) {
		if(iNumeArticulos > 0) {
			this.iNumeArticulos = iNumeArticulos;
		}
	}

	public int getiNumClientes() {
		return iNumClientes;
	}

	public void setiNumClientes(int iNumClientes) {
		if (iNumClientes > 0) {
			this.iNumClientes = iNumClientes;
		}
	}

	public String[] getlArticulo() {
		return aArticulos;
	}

	public void setlArticulo(String[] aArticulos) {
		if(aArticulos != null) {
			this.aArticulos = aArticulos;
		}
	}

	public int[] getlCantidades() {
		return aCantidades;
	}

	public void setlCantidades(int[] aCantidades) {
		this.aCantidades = aCantidades;
	}

	public int[] getlCliente() {
		return aCliente;
	}

	public void setlCliente(int[] aCliente) {
		if(aCliente != null) {
			this.aCliente = aCliente;
		}		
	}

	public void llenarAlmacen() {
		for (int i = 0; i < aArticulos.length; i++) {
			aArticulos[i] = this.aArticulos(0,"cero",10); 
		}
    }

	public String mostrarInventario() {
        String sCadena = "";
        
        return sCadena;
    }
	
	public float[] obtenerArticulos() {
		
		return null;
	}
	
	public void aniadirCliente(Cliente c) {
		
	}
	
	public void meterAlCarrito(Articulo articulo, Cliente c) {
		
	}

	public void venderCarrito(Cliente c) {
		
	}
	
	public String vender(Articulo articulo, Cliente c) {
		String sCadena = "";
        sCadena = "Vendiendo articulo "+articulo+" al cliente "+c;
        return sCadena;
	}
	
}
