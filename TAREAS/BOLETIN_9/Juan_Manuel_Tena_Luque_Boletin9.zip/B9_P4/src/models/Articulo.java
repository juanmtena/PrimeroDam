package models;

public class Articulo {

	private int iId_articulo;//PK
	private String sNombre_articulo;//FK
	private double dPrecio;//NN

	public Articulo(int iId_articulo, String sNombre_articulo, double dPrecio) {
		this.iId_articulo = iId_articulo;
		this.sNombre_articulo = sNombre_articulo;
		this.dPrecio = dPrecio;
	}

	public void setiId_articulo(int iId_articulo) {
		if(iId_articulo > 0) {
			this.iId_articulo = iId_articulo;
		}
	}

	public void setsNombre_articulo(String sNombre_articulo) {
		if(sNombre_articulo != null && sNombre_articulo.length() < 50) {
			this.sNombre_articulo = sNombre_articulo;
		}
	}

	public double getdPrecio() {
		return dPrecio;
	}

	public void setdPrecio(double dPrecio) {
		if(dPrecio > 0) {
			this.dPrecio = dPrecio;
		}
	}
	
	public int obtenerArticulos(int iId_articulo) {
		return iId_articulo;
	}
	
}
