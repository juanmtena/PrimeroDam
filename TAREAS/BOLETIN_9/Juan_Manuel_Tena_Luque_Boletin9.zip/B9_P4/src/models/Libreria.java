package models;
import java.io.BufferedReader;
import java.io.InputStreamReader;

	public class Libreria {

		public static void main(String[] args) {
			byte bNumero1 = (byte)leer("Introduce un numero entero positivo ",(long)-50,(long)50,-1,-1,(byte)1);
			byte bNumero2 = (byte)leer("Dame un numero o plomo: ",(long)-20,(long)10,-1,-1,(byte)1);
			short shNumero3 = (short)leer("Dame ahora un short: ",(long)-10,(long)50,-1,-1,(byte)2);
			
			float fNumero4 = (float)leer("Dame ahora un float: ",-1,-1,-10.3,10.1,(byte)5);
			
			System.out.println(bNumero1);
			System.out.println(bNumero2);
			System.out.println(shNumero3);
			System.out.println(fNumero4);
		}
		
		public static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo, byte bEstado) {
			Object oNumero;
			switch(bEstado) {
			case 1:
				oNumero = pideNumeroByte(sMensaje,lMinimo,lMaximo);
				break;
			case 2:
				oNumero = pideNumeroShort(sMensaje,lMinimo,lMaximo);
				break;
			case 3:
				oNumero = pideNumeroInt(sMensaje,lMinimo,lMaximo);
				break;
			case 4:
				oNumero = pideNumeroLong(sMensaje,lMinimo,lMaximo);
				break;
			case 5:
				oNumero = pideNumeroFloat(sMensaje,dMinimo,dMaximo);
				break;
			case 6:
				oNumero = pideNumeroDouble(sMensaje,dMinimo,dMaximo);
				break;
			case 7:
				oNumero = pideLetra(sMensaje);
				break;
			case 8:
				oNumero = pideNombre(sMensaje);
				break;
			default:
				oNumero = -1;
			}
			return oNumero;
		}

		public static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
			BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
			byte bNumero = 0;
			boolean bFallo;

			do {
				System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
				try {
					bNumero = Byte.parseByte(teclado.readLine());
					bFallo = false;
				} catch (Exception e) {
					bFallo = true;
				}
			} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

			return bNumero;
		}
		
		public static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
			BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
			short sNumero = 0;
			boolean bFallo;
			
			do {
				System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
				try {
					sNumero = Short.parseShort(teclado.readLine());
					bFallo = false;
				} catch (Exception e) {
					bFallo = true;
				}
			} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

			return sNumero;
		}
		
		public static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
			BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
			int iNumero = 0;
			boolean bFallo;

			do {
				System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
				try {
					iNumero = Integer.parseInt(teclado.readLine());
					bFallo = false;
				} catch (Exception e) {
					bFallo = true;
				}
			} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

			return iNumero;
		}
		
		public static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
			BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
			long lNumero = 0;
			boolean bFallo;

			do {
				System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
				try {
					lNumero = Long.parseLong(teclado.readLine());
					bFallo = false;
				} catch (Exception e) {
					bFallo = true;
				}
			} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

			return lNumero;
		}
		
		public static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
			BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
			float fNumero = 0;
			boolean bFallo;

			do {
				System.out.print(sMensaje + "("+dMinimo+" - " +dMaximo+"): ");
				try {
					fNumero = Float.parseFloat(teclado.readLine());
					bFallo = false;
				} catch (Exception e) {
					bFallo = true;
				}
			} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

			return fNumero;
		}
		
		public static double pideNumeroDouble(String sMensaje, double dMinimo, double dMaximo) {
			BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
			Double dNumero = (double) 0;
			boolean bFallo;

			do {
				System.out.print(sMensaje + "("+dMinimo+" - " +dMaximo+"): ");
				try {
					dNumero = Double.parseDouble(teclado.readLine());
					bFallo = false;
				} catch (Exception e) {
					bFallo = true;
				}
			} while (bFallo || (dNumero < dMinimo || dNumero > dMaximo));

			return dNumero;
		}
		
		public static char pideLetra(String sMensaje) {
			BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
			char cLetra = 0;
			boolean bFallo;

			do {
				System.out.print(sMensaje);
				try {
					cLetra = teclado.readLine().toLowerCase().charAt(0);
					bFallo = false;
				} catch (Exception e) {
					bFallo = true;
				}
			} while (bFallo);

			return cLetra;
		}
		
		public static String pideNombre(String sMensaje) {
			BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
			String sNombre = "";
			boolean bFallo;

			do {
				System.out.print(sMensaje);
				try {
					sNombre = teclado.readLine();
					bFallo = false;
				} catch (Exception e) {
					bFallo = true;
				}
			} while (bFallo);

			return sNombre;
		}

		
		
		//*********** Crear una ventanita para escribir *************
		
			/*String sCadena;
			sCadena = JOptionPane.showInputDialog("Introduce un email");*/
		
		
		
		
		//**************** Tama o matriz ********************
		
			/*private static byte[][] tamanoMatriz () {
				
				byte bFila = 0, bColumna = 0;
				
				bFila = (byte)leer(" Introduzca cuantas filas va a tener la matriz ", 1, 5, -1, -1, (byte)1);
				bColumna = (byte)leer(" Introduzca cuantas columnas va a tener la matriz ", 1, 5, -1, -1, (byte)1);	
				byte[][] aMatriz = new byte [bFila][bColumna];
				
				return aMatriz;
			}*/
			
			
			
			
			//**************** Crear matriz ********************
			//Para relleanar las columnas, simplemente tenemos que cambiar en el for anidado, 
			// las Filas por las Columnas.
			
			/*
			private static float[][] crearMatriz (float[][] aMatriz) {
				
				byte bFila, bColumnas;
				
				for (bFila = 0; bFila < aMatriz.length; bFila++) {
					for (bColumnas = 0; bColumnas < aMatriz[bFila].length; bColumnas++) {
						aMatriz[bFila][bColumnas] = (float)leer("Introduzca el valor de la posicion " + "["+bFila+"]"+"["+bColumnas+"] - ", -1, -1, 0.0, 100.0, (byte)5);
					}
				}		
				return aMatriz;
			}
			*/
			
			

			
			//************** Imprimir valores de la matriz *************
			
			/*private static float[][] imprimirMatriz (float[][] aMatriz) {
				
				System.out.println();
				for(byte bContador = 0; bContador < aMatriz.length; bContador++) {
					for(byte bContador2 = 0; bContador2 < aMatriz[bContador].length; bContador2++) {
						System.out.print("|"+aMatriz[bContador][bContador2]+"| ");
					}
			            System.out.println();
				}
				return aMatriz;
			}*/
			
			
			
			
			//************ Generar numeros aleatorios en una matriz 0 y 1 *************
			
			/*private static byte[][] generarAleatorio (byte[][] aAsientos) {
				
				byte bPosicion1, bPosicion2;
				Random rand=new Random();
				
				for(bPosicion1 = 0; bPosicion1 < aAsientos.length; bPosicion1++) {
					for(bPosicion2 = 0; bPosicion2 < aAsientos[bPosicion1].length; bPosicion2++) {
						aAsientos[bPosicion1][bPosicion2] = (byte) (rand.nextInt(2));//Le da un valor aleatorio entre 0 y 1 a cada posicion de la matriz
						System.out.print(aAsientos[bPosicion1][bPosicion2]+" ");//Imprimir valores de la matriz
					}
					System.out.println();
				}
				
				return aAsientos;
			}*/
			
			
			
			
			//************ Generar numeros aleatorios en un Vector entre 0 y 100 ************
			
			/*public static String generarNumerosAleatorios(byte[] aVector) {
				Random rand=new Random();
			
				String sResultado = "";
				for(int iContador = 0; iContador < aVector.length; iContador++) {
					aVector[iContador] = (byte) (rand.nextInt(100)+1);
					sResultado += aVector[iContador];
					if(iContador < aVector.length - 1) {
						sResultado += " - ";
					}
				}
				return sResultado;
			}*/
		
		
		
			//*********** Generar numeros aleatorios entre 0 y 10 con decimales ******//
		
			/*Random rand=new Random();
			 for (bContador = 0; bContador < aVector.length; bContador++) {
				aVector[bContador] = (float)rand.nextInt(100)/10;
			}*/
			
			
			
			//***************** Ordenar VECTOR (de menor a mayor) *****************
			
			/*public static float[] ordenacion (float [] aPeso) {
				
				byte bContador, bContador2 = 0;
				float fTemporal = 0;
				
				for (bContador = 1; bContador < aPeso.length; bContador++) {
					for (bContador2 = 0; bContador2 < aPeso.length-1; bContador2++) {
						if (aPeso[bContador2] > aPeso[bContador2+1]) {
							fTemporal = aPeso [bContador2];
							aPeso[bContador2] = aPeso[bContador2+1];
							aPeso[bContador2+1] = fTemporal;
						}	
					}	
				}		
				return aPeso;
			}*/
		
		
		
		
			//*********** Desplazar VECTOR hacia la izquierda **************
		
			/*private static byte[] desplazarVector(byte[] aNumeros) {
				byte bContador, bPrimerNumero = aNumeros[0];
					for(bContador = 0; bContador < aNumeros.length-1; bContador++) {
						bPrimerNumero = aNumeros[bContador];
						aNumeros[bContador] = aNumeros[bContador+1];
					}
					aNumeros[bContador] = bPrimerNumero;
				return aNumeros;
			}*/
		
		
		
			//*********** Desplazar VECTOR hacia la derecha **************
			
			/*private static byte[] desplazarVector(byte[] aNumeros) {
				//Primero hay que llenar el vector con el for()
				
				byte bUltimo;
				
				bUltimo = (byte) aNumeros.length-1;//Si esto no funciona ponerlo asi aNumeros[9], donde 9 ser a el ultimo numero del vector
				for(byte bContador = 8; bContador >= 0; bContador--) { //Tenemos que llegar hasta una posicion menos que la ultima pq la ultima ya la hemos guardado
					aVector[bContador+1] = aVector[bContador];
				}
				
				aNumero[0] = bUltimo;
				
			return aNumeros;
			}
			
			
			
			
			
		
			//************ Incluir un numero en un VECTOR en una determinada posicion *******
		
			/*private static String incluirNumeroEnElVector (float[] aVector, byte bPosicion, float fNumero) {
				
				String sResultado = "";
				
				for (byte bContador = 5; bContador >= bPosicion; bContador--) {
					aVector[bContador+1] = aVector[bContador];
				}
				aVector[bPosicion] = fNumero;//pedir posicion y numero anteriormente
				
				sResultado = "\nLos numeros quedar an as : \n";
				for(byte bContador = 0; bContador < aVector.length; bContador++) {
					sResultado += aVector[bContador];
					if(bContador < aVector.length -1) {
						sResultado += " - ";
					}
				}
				
				return sResultado;
			}*/
		
		
		
			
			//********************* Ordenar MATRIZ (de abajo a arriba) ************************
			
			/*private static byte[][] ordenarMatriz (byte[][] aMatriz) {
				
				byte bTemporal = 0;
				
				for(byte bContador1 = 0; bContador1 < aMatriz.length; bContador1++){//ordena la matriz de abajo hacia arriba
					for(byte bContador2 = 0; bContador2 < aMatriz[bContador1].length; bContador2++){
						for(byte bContador3 = 0; bContador3 < aMatriz.length; bContador3++){
							for(byte bContador4 = 0; bContador4 < aMatriz[bContador1].length; bContador4++){
								if(aMatriz[bContador1][bContador2] < aMatriz[bContador3][bContador4]){
								bTemporal = aMatriz[bContador1][bContador2];
								aMatriz[bContador1][bContador2] = aMatriz[bContador3][bContador4];
								aMatriz[bContador3][bContador4] = bTemporal;
								}
							}
						}
					} 
				}	
				return aMatriz;
			}*/
		
		
		
			//********** Recorrer matriz verticalmente ************//
		
			/*private static short[][] recorrerMatrizVertical (short[][] aMatriz) {
			  
			  	byte bTemporal = 0;
			 
				for(byte bContador = 0; bContador < aMatriz.length; bContador++) {
					for(byte bContador2 = (byte) (aMatriz[0].length-1); bContador >= bContador; bContador2--) {
						aMatriz[bContador][bContador2] = bTemporal;
						bTemporal--;
					}
				}
			}*/
		
		
		
			//******** Ordenar diagonales de una matriz ***********//
		
			/*private static byte[][] ordenarDiagonales (byte[][] aMatriz2) {
				
				byte bFila = 0, bColumna = 0;
				byte[] aDiagoPrincipal = new byte[aMatriz2.length];
				byte[] aDiagoSecundaria = new byte[aMatriz2.length];
				
				for(bFila=0;bFila<aMatriz2.length;bFila++){
		            for(bColumna=0;bColumna<aMatriz2[bFila].length;bColumna--){
		                if(bFila==bColumna){
		                	aDiagoPrincipal[bFila] = aMatriz2[bFila][bColumna];
		                }
		 
		                if(bFila+bColumna == aMatriz2.length-1){
		                	aDiagoSecundaria[bFila] = aMatriz2[bFila][bColumna];
		                }
		            }
		        }
				
				return aMatriz2;
			}*/
		
		
		
		
			//******* Pedir letra y Rotar palabra **************//
		
			/*private static String pedirLetrasyRotarPalabra() {
				String sPalabra = "";
				char cLetra;
				byte bLetras = (byte)leer(" Cuantas letras va a introducir? ", 1, 10, -1, -1,(byte)1);
				for(byte bContador = 0; bContador < bLetras; bContador++) {
					cLetra = (char)leer("Introduce caracter: ",-1,-1,-1,-1,(byte)7);
					sPalabra += cLetra;
				}
				System.out.println(sPalabra);
				
				for(byte bContador2 = 0; bContador2 <= sPalabra.length()-1; bContador2++){
					sPalabra = sPalabra.charAt(sPalabra.length()-1) + sPalabra.substring(0,sPalabra.length()-1);
					System.out.println(sPalabra);
				}
				return sPalabra;
			}*/
		
		

	
	
}
