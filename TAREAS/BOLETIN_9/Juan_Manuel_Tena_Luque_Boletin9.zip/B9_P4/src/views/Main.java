package views;

import models.Articulo;
import models.Cliente;
import models.Tienda;

public class Main {

	public static void main(String[] args) {
		
		//AURELIO JURO QUE LO HE INTENTADO PERO NO HE SIDO CAPAZ :(
		
		
		
		// Creamos tienda, llenamos el almacen y mostramos el inventario:
		 Tienda t = new Tienda(null) ;
		 t.llenarAlmacen();
		 t.mostrarInventario();

		 // Creamos cliente, lo registramos en la tienda y mostramos su saldo:
		 Cliente c = new Cliente();
		 t.aniadirCliente(c);
		 c.mostrarSaldo();
		 // Obtenemos array de articulos en la tienda:
		 Articulo[] articulos = t.obtenerArticulos();
		 // Ejemplo de venta directa:
		 t.vender(articulos[0],c);
		 // Mostramos el estado del inventario, el saldo y el historial del
		 // cliente despues de la compra:
		 t.mostrarInventario();
		 c.mostrarSaldo();
		 c.mostrarHistorial();
		 // Ejemplo de venta mediante el carrito:
		 t.meterAlCarrito(articulos[1],c);
		 t.meterAlCarrito(articulos[3],c);
		 c.mostrarCarrito();
		 t.venderCarrito(c);
		 // Mostramos el estado del inventario, el saldo y el historial del
		 // cliente despues de la compra:
		 t.mostrarInventario();
		 c.mostrarSaldo();
		 c.mostrarHistorial();

	}

}
