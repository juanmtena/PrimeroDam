package view;

import models.Semaforo;

public class MainSemaforo {

	public static void main(String[] args) {
		
		Semaforo sem = new Semaforo(1,true);
		System.out.println(sem.cadenaColor());
		

	}

}
