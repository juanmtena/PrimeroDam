package models;

public class Semaforo {

	private int iColor;
	boolean boolParapdeando;
	
	public Semaforo(int iColor, boolean boolParapdeando) {
		
		this.iColor = iColor;
		this.boolParapdeando = boolParapdeando;
	}

	public Semaforo(int iColor) {
		this.iColor = iColor;
	}
	
	public Semaforo() {
		
	}

	public int getiColor() {
		return iColor;
	}

	public void setiColor(int iColor) {
		if(iColor >= 0 && iColor <= 3) {
			this.iColor = iColor;
		}
		if(iColor == 1) {
			boolParapdeando = true;
		}
	}

	public boolean isBoolParapdeando() {
		return boolParapdeando;
	}

	public void setBoolParapdeando(boolean boolParapdeando) {
		this.boolParapdeando = boolParapdeando;
	}
	
	public String cadenaColor() {
		String sColor = "";
		
		if(getiColor() == 0) {
			sColor = "ROJO";
		}else if(getiColor() == 1 && this.boolParapdeando == true) {
			sColor = "AMBAR parpadeando";
		}else if(getiColor() == 2) {
			sColor = "VERDE";
		}else if(getiColor() == 3) {
			sColor = "AMBAR";
		}else if(getiColor() == 1 || getiColor() == 3) {
			sColor = "parpadeando";
		}
		return sColor;
	}
	
	public int cambio(int iColor) {
		
		if (iColor == 1 || iColor == 3) {
			this.iColor =  3;
		}
		return iColor;
	}
}
