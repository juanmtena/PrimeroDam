package models;

public class Aparatos {
	
	private boolean bombilla;
	private boolean radiador;
	private boolean plancha;
	
	public Aparatos(boolean boolEncendido) {
		this.boolEncendido = boolEncendido;
	}

	public int getBombilla() {
		return bombilla;
	}

	public void setBombilla(int bombilla, boolean boolEncendido) {
		
		this.bombilla = bombilla;
	}

	public int getRadiador() {
		return radiador;
	}

	public void setRadiador(int radiador) {
		this.radiador = radiador;
	}

	public int getPlancha() {
		return plancha;
	}

	public void setPlancha(int plancha) {
		this.plancha = plancha;
	}

	public boolean isBoolEncendido() {
		return boolEncendido;
	}

	public void setBoolEncendido(boolean boolEncendido) {
		this.boolEncendido = boolEncendido;
	}
	
	
		
}
