package models;

public class Consumo {

	private int iBombilla;
	private int iRadiador;
	private int iPlancha;

	public Consumo(int iBombilla, int iRadiador, int iPlancha) {
		
		this.iBombilla = iBombilla;
		this.iRadiador = iRadiador;
		this.iPlancha = iPlancha;
	}
	
	public int getiBombilla() {
		return iBombilla;
	}

	public void setiBombilla(int iBombilla) {
		if (iBombilla >= 0 && iBombilla <= 1) {
			this.iBombilla = iBombilla;
		}else {
			this.iBombilla = -1;
		}
	}

	public int getiRadiador() {
		return iRadiador;
	}

	public void setiRadiador(int iRadiador) {
		if (iRadiador >= 0 && iRadiador <= 1) {
			this.iRadiador = iRadiador;
		}else {
			this.iRadiador = -1;
		}
	}

	public int getiPlancha() {
		return iPlancha;
	}

	public void setiPlancha(int iPlancha) {
		if (iPlancha >= 0 && iPlancha <= 1) {
			this.iPlancha = iPlancha;
		}else {
			this.iPlancha = -1;
		}
	}

	public int encenderiBombilla(int iBombilla) {
		if (iBombilla == 0) {
			this.iBombilla = 0;
		}else {
			this.iBombilla = 1;
		}
		return getiBombilla();
	}
	
	public int encenderiRadiador(int iRadiador) {
		if (iRadiador == 0) {
			this.iRadiador = 0;
		}else {
			this.iRadiador = 1;
		}
		return getiRadiador();
	}
	
	public int encenderiPlancha(int iPlancha) {
		if (iPlancha == 0) {
			this.iPlancha = 0;
		}else {
			this.iPlancha = 1;
		}
		return getiPlancha();
	}
	
	public String imprimirConsumo() {
		String sMensaje = "";
		int iConsumoBombilla = 0, iConsumoRadiador = 0, iConsumoPlancha = 0;
		
		if (getiBombilla() == 0 && getiRadiador() == 0 && getiPlancha() == 0) {
			return sMensaje = "Todos los aparatos estan apagados\n";
		}
		
		if (getiBombilla() == 1) {
			iConsumoBombilla = 100;
			sMensaje += "Bombilla encendida\n";
		}else {
			iConsumoBombilla = 0;
			sMensaje += "Bombilla apagada\n";
		}
		
		if (getiRadiador() == 1) {
			iConsumoRadiador = 2000;
			sMensaje += "Radiador encendido\n";
		}else {
			iConsumoRadiador = 0;
			sMensaje += "Radiador apagado\n";
		}
		
		if (getiPlancha() == 1) {
			iConsumoPlancha = 1200;
			sMensaje += "Plancha encendida\n";
		}else {
			iConsumoPlancha = 0;
			sMensaje += "Plancha apagada\n";
		}
		sMensaje += "Est� consumiendo "+(iConsumoBombilla+iConsumoRadiador+iConsumoPlancha)+" watios";
		return sMensaje;
	}
		
		/*if (isiBombilla() == false && isiRadiador() == false && isiPlancha() == false) {
			sMensaje = "Estan todos los aparatos apagados";
		}else if (isiBombilla() == true && isiRadiador() == false && isiPlancha() == true) {
			
		}
			
			iConsumo = 100;
			sMensaje = "Consumo de la iBombilla: "+iConsumo;
		}
		if (isiRadiador() == true) {
			iConsumo = 1200;
			sMensaje += "\nConsumo del iRadiador: "+iConsumo; 
		}
		if (isiPlancha() == true) {
			iConsumo = 2000;
			sMensaje += "\nConsumo de la iPlancha: "+iConsumo;
		}
		
		return sMensaje;
	}*/

}
