package views;

import models.Consumo;

public class MainAparatos {

	public static void main(String[] args) {
		
		Consumo cons = new Consumo(0,0,0);
		System.out.println(cons.imprimirConsumo());
		cons.encenderiBombilla(0);
		cons.encenderiRadiador(1);
		cons.encenderiPlancha(0);
		System.out.println(cons.imprimirConsumo());
		
	}

}
