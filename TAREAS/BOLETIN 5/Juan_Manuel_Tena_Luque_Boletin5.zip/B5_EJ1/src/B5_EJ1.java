import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B5_EJ1 {

	public static void main(String[] args) {
	
	byte[] aTiempos = pideTimepo();
	System.out.println(diferenciaTiempos(aTiempos));
		
	}
	
		public static byte[] pideTimepo () {
			
			byte bNumeroTiempos = (byte) leer("Introduce el numero de tiempos que desea comparar: ", (long) 1, (long) 100, -1, -1, (byte) 1);
			byte[] aVector = new byte[bNumeroTiempos];
			byte bContador, bTemporal = 0;
			boolean boolContinuar = false;
			
			for(bContador = 0; bContador < aVector.length; bContador++) {
				aVector[bContador] = (byte) leer("La " +(bContador+1)+ "� bola tarda en caer: ", (long) 1, (long) 100, -1, -1, (byte) 1); 
				if (aVector[bContador] < bTemporal) {
					bContador--;
					boolContinuar = false;
					System.out.println("Por favor, introduzca el tiempo en orden descendente");
				} else {
					bTemporal = aVector[bContador];
				}				
			}
			
			return aVector;	
		}
		
		public static String diferenciaTiempos (byte[] aVector) {
			String sResultado = "";
			byte bTiempos = (byte) aVector.length;
			byte bDiferenciaTiempo = 0;
			
			for (byte bContador = 0; bContador < bTiempos; bContador++) {
				bDiferenciaTiempo = (byte) (aVector[bContador] - aVector[0]);
				System.out.println("La diefencia de tiempos entre la 1� bola y la " +(bContador+1)+ "� bola es: " +bDiferenciaTiempo);
			}
					
			return sResultado;
		}
	
		private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo,
				byte bEstado) {
			Object oNumero;
			switch (bEstado) {
			case 1:
				oNumero = pideNumeroByte(sMensaje, lMinimo, lMaximo);
				break;
			case 2:
				oNumero = pideNumeroShort(sMensaje, lMinimo, lMaximo);
				break;
			case 3:
				oNumero = pideNumeroInt(sMensaje, lMinimo, lMaximo);
				break;
			case 4:
				oNumero = pideNumeroLong(sMensaje, lMinimo, lMaximo);
				break;
			case 5:
				oNumero = pideNumeroFloat(sMensaje, dMinimo, dMaximo);
				break;
			default:
				oNumero = -1;
			}
			return oNumero;
		}

		private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
			BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
			byte bNumero = 0;
			boolean bFallo;

			do {
				System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
				try {
					bNumero = Byte.parseByte(teclado.readLine());
					bFallo = false;
				} catch (Exception e) {
					bFallo = true;
				}
			} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

			return bNumero;
		}

		private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
			BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
			short sNumero = 0;
			boolean bFallo;

			do {
				System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
				try {
					sNumero = Short.parseShort(teclado.readLine());
					bFallo = false;
				} catch (Exception e) {
					bFallo = true;
				}
			} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

			return sNumero;
		}

		private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
			BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
			int iNumero = 0;
			boolean bFallo;

			do {
				System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
				try {
					iNumero = Integer.parseInt(teclado.readLine());
					bFallo = false;
				} catch (Exception e) {
					bFallo = true;
				}
			} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

			return iNumero;
		}

		private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
			BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
			long lNumero = 0;
			boolean bFallo;

			do {
				System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
				try {
					lNumero = Long.parseLong(teclado.readLine());
					bFallo = false;
				} catch (Exception e) {
					bFallo = true;
				}
			} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

			return lNumero;
		}

		private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
			BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
			float fNumero = 0;
			boolean bFallo;

			do {
				System.out.print(sMensaje + "(" + dMinimo + " - " + dMaximo + "): ");
				try {
					fNumero = Float.parseFloat(teclado.readLine());
					bFallo = false;
				} catch (Exception e) {
					bFallo = true;
				}
			} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

			return fNumero;
		}
		

}