import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

public class B5_EJ3 {

	public static void main(String[] args) {
		
		byte [] aVector = combinacionGanadora();
		byte[] aVector2 = boletoParticipante();	 
		comprobacion(aVector, aVector2);
	}
	
	private static byte[] combinacionGanadora () {
		
		Random aleatorio = new Random();
		byte[] aVector = new byte[6];
		byte bContador;
		
		for(bContador = 0; bContador < aVector.length; bContador++) {		
			aVector[bContador] = (byte) (aleatorio.nextDouble()*99);		
			System.out.println(aVector[bContador]);
		}	
													
	return aVector;
		
	}	
	
	private static byte[] boletoParticipante () {
		
		byte[] aVector2 = new byte[6];
		byte bContador;
		
		System.out.println("\nIntroduzca los numeros de su boleto:\nQue tenga mucha Suerte!!\n");
			
		for(bContador = 0; bContador < aVector2.length; bContador++) 		
			aVector2[bContador] = (byte)leer("El "+(bContador+1)+"  de los numeros es: ", (long) 1, (long) 99, -1, -1, (byte) 1); {																
		}
		
		return aVector2;	
	}
	
	private static byte comprobacion (byte aVector[], byte aVector2[]) {

		byte bAciertos = 0, bContador;
		
		for (bContador = 0; bContador < aVector.length; bContador++) {
			if (aVector [bContador] == aVector2[bContador]) {
				bAciertos++;
			}
		}
		
		if (bAciertos  == aVector2.length) {
			System.out.println("\n  Enhorabuena!! Boleto premiado!! Tienes todos los numeros iguales");
		} else {
			System.out.println("\nTienes " +bAciertos+ " aciertos. Suerte para la proxima");
		}
		return bAciertos;
	} 
	
	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo,
			byte bEstado) {
		Object oNumero;
		switch (bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje, lMinimo, lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje, lMinimo, lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje, lMinimo, lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje, lMinimo, lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje, dMinimo, dMaximo);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}

	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}

	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}

	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}

	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + dMinimo + " - " + dMaximo + "): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}

}