import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B5_EJ6 {

	public static void main(String[] args) {
		
		float[][] aMatriz = new float[3][3];
		float[][] aSumaMatriz = new float [3][3];
		meterNumeros(aMatriz);
		imprimirMatriz(aMatriz);
		sumaFilas(aMatriz);
		sumaColumnas(aMatriz);
		sumarMatriz(aMatriz);
	}
		
	private static float[][] meterNumeros (float[][] aMatriz) {
		
		byte bContador, bContador2;
		
		for (bContador = 0; bContador < aMatriz.length; bContador++) {
			for (bContador2 = 0; bContador2 < aMatriz[bContador].length; bContador2++) {
				aMatriz[bContador][bContador2] = (float)leer("Introduzca el valor de la posicion " + "["+bContador+"]"+"["+bContador2+"] - ", -1, -1, 0.0, 100.0, (byte)5);
			}
		}		
		return aMatriz;
	}
	
	private static float[][] sumaFilas (float[][] aMatriz) {
		
		byte bContador, bContador2 = 0;
		float fSuma = 0;
		
		System.out.println("-------------");
		for (bContador = 0; bContador < aMatriz.length; bContador++) {
			fSuma = 0;
			for (bContador2 = 0; bContador2 < aMatriz.length; bContador2++) 
				fSuma += aMatriz[bContador][bContador2];
				System.out.println("La suma de la fila "+bContador+" es: "+fSuma);
		}	
		
		return aMatriz;
	}
	
	private static float[][] sumaColumnas (float[][] aMatriz) {
		
		byte bContador, bContador2 = 0;
		float fSuma = 0;
		
		for (bContador = 0; bContador < aMatriz.length; bContador++) {
			fSuma = 0;
			for (bContador2 = 0; bContador2 < aMatriz.length; bContador2++) 
				fSuma += aMatriz[bContador2][bContador];
				System.out.println("La suma de la columna "+bContador+" es: "+fSuma);
		}	
		
		return aMatriz;
	}
	
	public static float[][] imprimirMatriz (float[][] aMatriz) {
		
		byte bContador, bContador2 = 0;
		
		System.out.println("\nLa matriz creada a partir de los n meros que ha introducido es la siguiente: \n-------------");
		
		for (bContador = 0; bContador < aMatriz.length; bContador++) {
			for (bContador2 = 0; bContador2 < aMatriz.length; bContador2++) {
				System.out.print(aMatriz[bContador][bContador2]+" ");
			}
			System.out.println("");
		}
		
		return aMatriz;
	}
	
	public static float sumarMatriz (float[][] aMatriz) {
		
		byte bContador, bContador2 = 0;
		float fSuma = 0, fNumeroActual;
		
		for (bContador = 0; bContador < aMatriz.length; bContador++) {
			  for (bContador2 = 0; bContador2 < aMatriz[bContador].length; bContador2++) {				
			    fNumeroActual = aMatriz [bContador][bContador2];	
			    fSuma += fNumeroActual;
			  }
			  
		}
		System.out.print("\nLa suma de los elementos de la matriz es: "+fSuma);
		
		return fSuma;
	}
	
	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo,
			byte bEstado) {
		Object oNumero;
		switch (bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje, lMinimo, lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje, lMinimo, lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje, lMinimo, lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje, lMinimo, lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje, dMinimo, dMaximo);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}

	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}

	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}

	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}

	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + dMinimo + " - " + dMaximo + "): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}

}