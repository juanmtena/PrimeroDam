import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;

public class B5_EJ11 {

	public static void main(String[] args) {
		
		short[][] aMatriz1 = new short [3][2];
		short[][] aMatriz2 = new short [2][3];
		int[][] aMatriz3 = new int[aMatriz1.length][aMatriz2[0].length];
		pedirNumeros(aMatriz1, aMatriz2);
		System.out.print("\nEl producto de las dos matrices es: \n");imprimirMatriz(productoMatriz(aMatriz1, aMatriz2, aMatriz3));
		
	}
	
	private static short[][] pedirNumeros (short[][] aMatriz1, short[][] aMatriz2) {
		
		byte bContador, bContador2;
		
		System.out.println("Introduzca los valores de la primera matriz\n");
		for (bContador = 0; bContador < aMatriz1.length; bContador++) {
			for (bContador2 = 0; bContador2 < aMatriz1[bContador].length; bContador2++) {
				aMatriz1[bContador][bContador2] = (short)leer("Valor de la posici�n " + "["+bContador+"]"+"["+bContador2+"] - ", -10, 20, -1, -1, (byte)2);
			}
		}
		
		System.out.println("\nIntroduzca los valores de la segunda matriz\n");
		for (bContador = 0; bContador < aMatriz2.length; bContador++) {
			for (bContador2 = 0; bContador2 < aMatriz2[bContador].length; bContador2++) {
				aMatriz2[bContador][bContador2] = (short)leer("Valor de la posici�n " + "["+bContador+"]"+"["+bContador2+"] - ", -10, 20, -1, -1, (byte)2);
			}
		}
		
		return aMatriz1;
	}
	
	public static int[][] productoMatriz (short[][] aMatriz1, short[][] aMatriz2, int[][]aMatriz3) {

	    if (aMatriz1[0].length == aMatriz2.length) {
	        for (byte bContador1 = 0; bContador1 < aMatriz1.length; bContador1++) {
	            for (byte bContador2 = 0; bContador2 < aMatriz2[0].length; bContador2++) {
	                for (byte bContador3 = 0; bContador3 < aMatriz1[0].length; bContador3++) {
	                	aMatriz3[bContador1][bContador2] += aMatriz1[bContador1][bContador3] * aMatriz2[bContador3][bContador2];
	                }
	            }
	        }
	    }
	    return aMatriz3;
	}
	
	private static int[][] imprimirMatriz (int[][] aMatriz3) {
		
		System.out.println();
		for(byte bContador = 0; bContador < aMatriz3.length; bContador++) {
			for(byte bContador2 = 0; bContador2 < aMatriz3[bContador].length; bContador2++) {
				System.out.print("|"+aMatriz3[bContador][bContador2]+"|");
			}
	            System.out.println();
		}
		return aMatriz3;
	}
	
	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo,
			byte bEstado) {
		Object oNumero;
		switch (bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje, lMinimo, lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje, lMinimo, lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje, lMinimo, lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje, lMinimo, lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje, dMinimo, dMaximo);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}

	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}

	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}

	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}

	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + dMinimo + " - " + dMaximo + "): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}

}
