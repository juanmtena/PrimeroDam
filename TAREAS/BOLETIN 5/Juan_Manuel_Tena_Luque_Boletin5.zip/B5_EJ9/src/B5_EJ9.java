import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B5_EJ9 {

	public static void main(String[] args) {
		
		byte aMatriz[][] = tamanoMatriz();
		crearMatriz(aMatriz);
		System.out.println("\nMatriz ordenada");
		ordenarMatriz(aMatriz); 
		imprimirMatriz(aMatriz); 
		moda(aMatriz);
		
	}	
	
	private static byte[][] tamanoMatriz () {
		
		byte bFila = 0, bColumna = 0;
		
		bFila = (byte)leer("�Introduzca cuantas filas va a tener la matriz ", 1, 5, -1, -1, (byte)1);
		bColumna = (byte)leer("�Introduzca cuantas columnas va a tener la matriz ", 1, 5, -1, -1, (byte)1);	
		byte[][] aMatriz = new byte [bFila][bColumna];
		
		return aMatriz;
	}
	
	private static byte[][] crearMatriz (byte[][] aMatriz) {
		
		byte bContador, bContador2;
		
		for (bContador = 0; bContador < aMatriz.length; bContador++) {
			for (bContador2 = 0; bContador2 < aMatriz[bContador].length; bContador2++) {
				aMatriz[bContador][bContador2] = (byte)leer("Valor de la posicion " + "["+bContador+"]"+"["+bContador2+"] - ", 1, 10, -1, -1, (byte)1);
			}
		}		
		return aMatriz;
	}

	private static byte[][] ordenarMatriz (byte[][] aMatriz) {
		
		byte bTemporal = 0;
		
		for(byte bContador1 = 0; bContador1 < aMatriz.length; bContador1++){//ordena la matriz de abajo hacia arriba
			for(byte bContador2 = 0; bContador2 < aMatriz[bContador1].length; bContador2++){
				for(byte bContador3 = 0; bContador3 < aMatriz.length; bContador3++){
					for(byte bContador4 = 0; bContador4 < aMatriz[bContador1].length; bContador4++){
						if(aMatriz[bContador1][bContador2] < aMatriz[bContador3][bContador4]){
						bTemporal = aMatriz[bContador1][bContador2];
						aMatriz[bContador1][bContador2] = aMatriz[bContador3][bContador4];
						aMatriz[bContador3][bContador4] = bTemporal;
						}
					}
				}
			} 
		}	
		return aMatriz;
	}
	
	private static byte[][] imprimirMatriz (byte[][] aMatriz) {
		
		System.out.println();
		for(byte bContador = 0; bContador < aMatriz.length; bContador++) {
			for(byte bContador2 = 0; bContador2 < aMatriz[bContador].length; bContador2++) {
				System.out.print("|"+aMatriz[bContador][bContador2]+"| ");
			}
	            System.out.println();
		}
		return aMatriz;
	}
		
	private static byte[][] moda (byte[][] aMatriz) {
		byte bContador = 0, bContador2, bRepeticiones = 0;
		byte[] bModa = aMatriz[bContador];
		
		for(bContador = 0; bContador < aMatriz.length; bContador++) {
			for(bContador2 = 1; bContador2 < aMatriz[bContador].length; bContador2++) {
				if(aMatriz[bContador] == aMatriz[bContador2]) {
					bModa = aMatriz[bContador];
					bRepeticiones++;
					if(bContador2 == aMatriz[bContador].length) {
						bContador--;
					}
				}
			}
		}
		System.out.println("\nEl numero "+bModa+" es la moda de la matriz y se ha repetido "+bRepeticiones+" veces");
		return aMatriz;
	}
	
	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo,
			byte bEstado) {
		Object oNumero;
		switch (bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje, lMinimo, lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje, lMinimo, lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje, lMinimo, lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje, lMinimo, lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje, dMinimo, dMaximo);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}

	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}

	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}

	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}

	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + dMinimo + " - " + dMaximo + "): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}
		
}
