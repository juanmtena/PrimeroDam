import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B5_EJ8 {

	public static void main(String[] args) {

		int[][] aMatriz = new int[3][3];
		meterNumeros(aMatriz);
		determinante(aMatriz);

	}

	private static int[][] meterNumeros(int[][] aMatriz) {

		byte bContador, bContador2;

		for (bContador = 0; bContador < aMatriz.length; bContador++) {
			for (bContador2 = 0; bContador2 < aMatriz[bContador].length; bContador2++) {
				aMatriz[bContador][bContador2] = (int) leer(
						"Introduzca el valor de la posicion " + "[" + bContador + "]" + "[" + bContador2 + "] - ", -10,
						10, -1, -1, (byte) 3);
			}
		}
		return aMatriz;
	}

	private static void determinante(int[][] aMatriz) {

		int iDeterminante = 0;

		iDeterminante += ((aMatriz[0][0]) * (aMatriz[1][1]) * (aMatriz[2][2]) + (aMatriz[1][0]) * (aMatriz[2][1]) * (aMatriz[0][2])
				+ (aMatriz[2][0]) * (aMatriz[0][1]) * (aMatriz[1][2]))
				- ((aMatriz[2][0]) * (aMatriz[1][1]) * (aMatriz[0][2]) + (aMatriz[1][0]) * (aMatriz[0][1]) * (aMatriz[2][2])
						+ (aMatriz[0][0]) * (aMatriz[2][1]) * (aMatriz[1][2]));
		System.out.println("\nEl determinante de la matriz es:\n|A|= " + iDeterminante);
	}

	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo,
			byte bEstado) {
		Object oNumero;
		switch (bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje, lMinimo, lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje, lMinimo, lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje, lMinimo, lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje, lMinimo, lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje, dMinimo, dMaximo);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}

	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}

	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}

	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}

	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + dMinimo + " - " + dMaximo + "): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}

}
