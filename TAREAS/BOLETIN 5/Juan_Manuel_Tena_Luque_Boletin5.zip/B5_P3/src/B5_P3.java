import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B5_P3 {

	public static void main(String[] args) {
		
		float[][] aMatriz = tamanoMatriz();
		char[][] aCaracter = new char[aMatriz.length][aMatriz.length];
		crearMatriz(aMatriz);
		mostrarNumerosMatriz(aMatriz);
		valoresPorColores(aMatriz, aCaracter);
		mostrarColoresMatriz(aMatriz, aCaracter);
		mensajeExpresa(aCaracter);
		
	}
	
	private static float[][] tamanoMatriz () {
		
		byte bFila = 0, bColumna = 0;
		
		do {
			bColumna = (byte)leer("�Introduzca cuantos genes va a analizar (columnas): ", 1, 5, -1, -1, (byte)1);
			bFila = (byte)leer("�Introduzca cuantos datos del gen va a analizar (filas): ", 1, 5, -1, -1, (byte)1);	
			if (bFila != bColumna) {
				System.out.println("        *ERROR*        \nLa matriz debe de tener el mismo tama�o de filas y columnas*\n");
			}
		} while (bColumna != bFila); 
		
		float[][] aMatriz = new float [bFila][bColumna];
		
		return aMatriz;
	}
	
	private static float[][] crearMatriz (float[][] aMatriz) {
		
		byte bContador, bContador2;
		
		for (bContador = 0; bContador < aMatriz.length; bContador++) {
			for (bContador2 = 0; bContador2 < aMatriz[bContador].length; bContador2++) {
				aMatriz[bContador][bContador2] = (float)leer("Introduzca el valor de la posicion " + "["+bContador+"]"+"["+bContador2+"] - ", -1, -1, 0.0, 10.0, (byte)5);
			}
		}		
		return aMatriz;
	}
	
	private static char[][] valoresPorColores (float[][] aMatriz, char[][] aCaracter) {
		
		final float fUMBRAL = 1.5f;
		
		for(byte bContador = 0; bContador < aMatriz.length; bContador++) {
			for(byte bContador2 = 0; bContador2 < aMatriz[bContador].length; bContador2++) {
				if (aMatriz[bContador][bContador2] > fUMBRAL) {
					aCaracter[bContador][bContador2] = 'V';
				} else if (aMatriz[bContador][bContador2] == fUMBRAL) {
					aCaracter[bContador][bContador2] = 'A';
				} else {
					aCaracter[bContador][bContador2] = 'R';
				}
			}
		}
		return aCaracter;
	} 
	
	private static float[][] mostrarNumerosMatriz (float[][] aMatriz) {
		
		byte bContador2 = 0;
		
		System.out.println();
		for(byte bContador = 0; bContador < aMatriz.length; bContador++) {
			for(bContador2 = 0; bContador2 < aMatriz[bContador].length; bContador2++) {
				System.out.print("|"+aMatriz[bContador][bContador2]+"|");
			}
	            System.out.println();
		}
		return aMatriz;
	}
	
	private static char[][] mostrarColoresMatriz (float[][] aMatriz, char[][] aCaracter) {
		
		System.out.println();
		for(byte bContador = 0; bContador < aMatriz.length; bContador++) {
			for(byte bContador2 = 0; bContador2 < aMatriz[bContador].length; bContador2++) {
				System.out.print("|"+aCaracter[bContador][bContador2]+"|");
			}
	            System.out.println();
		}
		return aCaracter;
	}
	
	private static char[][] mensajeExpresa (char[][] aCaracter) {

		byte bFila = 0;
		boolean boolMostrar = false;
		System.out.println();
		for (byte bColumna = 0; bColumna < aCaracter.length; bColumna++) {
			boolMostrar = false;
			bFila = 0;
			while (bFila < aCaracter[bColumna].length && boolMostrar == false) {
				if (aCaracter[bFila][bColumna] == 'V') {
					System.out.println("Este gen SI se expresa");
					boolMostrar = false;
				} 
				if (bFila == aCaracter[bColumna].length -1 && boolMostrar == false) {
					System.out.println("Este gen NO se expresa");
				}
				bFila++;
			}
		}	
		return aCaracter;
	 }
	
	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo,
			byte bEstado) {
		Object oNumero;
		switch (bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje, lMinimo, lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje, lMinimo, lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje, lMinimo, lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje, lMinimo, lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje, dMinimo, dMaximo);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}

	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}

	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}

	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}

	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + dMinimo + " - " + dMaximo + "): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}

}
