import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

public class B5_EJ7 {

	public static void main(String[] args) {
		
		byte bPosiciones = 0;
		byte[] aVector = new byte [100];
		final byte bCONSTANTE = 7;
		System.out.println("�Este es el vector que se ha generado de manera aleatoria\n---------------------------------------------------------------------------------------------------------------------------------------\n"+generarNumerosAleatorios(aVector)+"\n-------------------------------------------------------------------------------------------------------------------------------------------");
		desplazaDerecha(aVector, bPosiciones);
		
	}

	public static String generarNumerosAleatorios(byte[] aVector) {
		Random rand=new Random();
	
		String sResultado = "";
		for(int iContador = 0; iContador < aVector.length; iContador++) {
			aVector[iContador] = (byte) (rand.nextInt(100)+1);
			sResultado += aVector[iContador];
			if(iContador < aVector.length - 1) {
				sResultado += " - ";
			}
		}
		
		return sResultado;
	}
	
	private static byte[] desplazaDerecha(byte[] aVector, byte bPosiciones) {
		
        byte bContador, bContador2 = 0, bUltimo = 0;
        String sResultado = "";
        
        bPosiciones = (byte)leer("�Indique cuantas posiciones quieres que se desplace el vector hacia la izquiera:", 1, 10, -1, -1, (byte)1);
       
        for(bContador = 1; bContador <= bPosiciones; bContador++) {
        	 bUltimo = aVector[aVector.length-1];     
        	 for(bContador2 = (byte) (aVector.length-2); bContador2 >= bContador; bContador2--) {
        		 aVector[bContador2+1] = aVector[bContador2];
        		 sResultado += aVector[bContador2];
        		 if(bContador < aVector.length - 1) {
     				sResultado += " - ";
     			}
        		 
        	 }
        }
        System.out.println(sResultado);
        aVector[0] = bUltimo;
        
        
        
         return aVector;
	}
	
	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo,
			byte bEstado) {
		Object oNumero;
		switch (bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje, lMinimo, lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje, lMinimo, lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje, lMinimo, lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje, lMinimo, lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje, dMinimo, dMaximo);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}

	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}

	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}

	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}

	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + dMinimo + " - " + dMaximo + "): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}

}
