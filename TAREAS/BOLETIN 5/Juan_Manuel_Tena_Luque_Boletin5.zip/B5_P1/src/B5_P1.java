import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Random;

public class B5_P1 {

	public static void main(String[] args) {
		
		byte[][] aAsientos = new byte [30][6];
		generarAleatorio(aAsientos);
		elijeAsiento(aAsientos);
	}
	
	private static byte[][] generarAleatorio (byte[][] aAsientos) {
		
		byte bPosicion1, bPosicion2, bContador = 0;
		Random rand=new Random();
		System.out.println("________________AIR TENA_______________\n\n  1    2    3    4    5    6\n  |    |    |    |    |    |");
		for(bPosicion1 = 0; bPosicion1 < aAsientos.length; bPosicion1++) {
			
			for(bPosicion2 = 0; bPosicion2 < aAsientos[bPosicion1].length; bPosicion2++) {
				aAsientos[bPosicion1][bPosicion2] = (byte) (rand.nextInt(2));
				System.out.print(" |"+aAsientos[bPosicion1][bPosicion2]+"| ");
			}
			bContador++;
			System.out.println("  Fila-"+bContador);
		}
		return aAsientos;
	}
	
	private static byte[][] elijeAsiento (byte[][] aAsientos) {
		
		byte bFila = 0, bColumna = 0, bContadorTemporal = 0, bContador = 0, bPasajeros = 5;
		
		while(bContador < bPasajeros) {
			for(byte bPosicion1 = 0; bPosicion1 <= 1; bPosicion1++) {
				for(byte bPosicion2 = 0; bPosicion2 < 1; bPosicion2++) {
					aAsientos[bFila+1][bColumna+1] = (byte)leer("Seleccione la posicion de su asiento - ", 0, 180, -1, -1, (byte)1);
				}
			}
			if(aAsientos[bFila][bColumna] == 0) {
				aAsientos[bFila][bColumna] = 1;
				System.out.println("Reserva realizada con exito");
				bContadorTemporal++;
			}else {
				System.out.println("Asiento ocupado. Elija otro por favor");
				bContador--;
			}
			bContador++;
		}
		return aAsientos;	
	}
	
	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo,
			byte bEstado) {
		Object oNumero;
		switch (bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje, lMinimo, lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje, lMinimo, lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje, lMinimo, lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje, lMinimo, lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje, dMinimo, dMaximo);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}

	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}

	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}

	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}

	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + dMinimo + " - " + dMaximo + "): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}

}
