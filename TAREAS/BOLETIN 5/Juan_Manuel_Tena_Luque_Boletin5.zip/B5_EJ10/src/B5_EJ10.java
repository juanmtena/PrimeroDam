import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B5_EJ10 {

	public static void main(String[] args) {
		
		byte[][] aMatriz = tamanoMatriz();
		meterNumeros(aMatriz);
		cuadradoMagico(aMatriz);

	}
	
	private static byte[][] tamanoMatriz () {
		
		byte bFila = 0, bColumna = 0;
		
		do {
			bFila = (byte)leer("�Introduzca cuantas filas va a tener la matriz ", 1, 5, -1, -1, (byte)1);
			bColumna = (byte)leer("�Introduzca cuantas columnas va a tener la matriz ", 1, 5, -1, -1, (byte)1);
			if (bFila != bColumna) {
				System.out.println("||||||||||||||||||___*** E R R O R ***___|||||||||||||||||||\n*La matriz debe de tener el mismo tama�o de filas y columnas*\n");
			}
		} while (bFila != bColumna);
		byte[][] aMatriz = new byte [bFila][bColumna];
		return aMatriz;
	}
	
	private static byte[][] meterNumeros (byte[][] aMatriz) {
		
		byte bContador, bContador2;
		
		System.out.println("\n                    --VALORES--                 ");
		for (bContador = 0; bContador < aMatriz.length; bContador++) {
			for (bContador2 = 0; bContador2 < aMatriz[bContador].length; bContador2++) {
				aMatriz[bContador][bContador2] = (byte)leer("Introduzca el valor de la posicion " + "["+bContador+"]"+"["+bContador2+"] - ", 0, 10, -1, -1, (byte)1);
			}
		}		
		return aMatriz;
	}
	
	private static void cuadradoMagico (byte[][] aMatriz) {
		
		byte bContador, bContador2 = 0, bSumaFilas = 0, bFilas2 = 0, bSumaColumnas = 0, bDiagonal = 0, bDiagonalInversa = 0;
		
		//Filas
		for (bContador = 0; bContador < aMatriz.length; bContador++) {
			if (bSumaFilas != bFilas2) {
				System.out.println("\nNo es un cuadrado magico por una fila");
				break;
			}
			bSumaFilas = 0;
			for (bContador2 = 0; bContador2 < aMatriz.length; bContador2++) 
				bSumaFilas += aMatriz[bContador][bContador2];
				if (bContador == 0) {
					bFilas2 = bSumaFilas;
				}
		}	
			
		//Columnas
		for (bContador = 0; bContador < aMatriz.length; bContador++) {
			if (bContador > 0) {
				if (bSumaColumnas != bFilas2) {
					System.out.println("\nNo es un cuadrado magico por una columna");
					break;
				}
			}
			bSumaColumnas = 0;
			for (bContador2 = 0; bContador2 < aMatriz.length; bContador2++) 
				bSumaColumnas += aMatriz[bContador2][bContador];
		}
			
		//Diagonal Principal
		for (bContador = 0; bContador < aMatriz.length; bContador++) {
			bDiagonal += aMatriz[bContador][bContador];
		}
			if (bDiagonal != bFilas2) {
				System.out.println("\nNo es un cuadrado magico por la diagonal principal");
			
		}

		//Diagonal inversa
		for (bContador = 0; bContador < aMatriz.length; bContador++) {
			if (bSumaFilas != bFilas2) {
				System.out.println("\nNo es un cuadrado magico por la diaginal inversa");
				break;
			}
			bDiagonalInversa = 0;
			for (bContador2 = 0; bContador2 < aMatriz.length; bContador2++) {
				bDiagonalInversa += aMatriz[bContador2][bContador];
			}
		}
		
		if (bSumaFilas == bFilas2 && bSumaColumnas == bFilas2 && bDiagonal== bFilas2 && bDiagonalInversa == bFilas2) {
			System.out.println("\nEs un cuadrado magico");
		}
			
	}
	
	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo,
			byte bEstado) {
		Object oNumero;
		switch (bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje, lMinimo, lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje, lMinimo, lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje, lMinimo, lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje, lMinimo, lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje, dMinimo, dMaximo);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}

	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}

	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}

	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}

	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + dMinimo + " - " + dMaximo + "): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}
	
}
