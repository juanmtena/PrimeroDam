import java.io.BufferedReader;
import java.io.InputStreamReader;

public class BoletinNavide�o_EJ23 {

	public static void main(String[] args) {
		
		final byte bALUMNOS_TOTALES = 30;
		byte[] bEdad = new byte[bALUMNOS_TOTALES];
		float[] fAltura = new float[bALUMNOS_TOTALES];
		String sMensaje = "";
		System.out.println(datosAlumnos(bEdad, fAltura, sMensaje, bALUMNOS_TOTALES));
		System.out.println(calcularMediaEdad(bEdad, bALUMNOS_TOTALES, sMensaje));
		System.out.println(calcularMediaAltura(fAltura, bALUMNOS_TOTALES, sMensaje));
		System.out.println(mayores18(bEdad, bALUMNOS_TOTALES, sMensaje));
		System.out.println(masDe180(fAltura, bALUMNOS_TOTALES, sMensaje));
		
	}
	
	private static String datosAlumnos(byte[] bEdad, float[] fAltura, String sMensaje, final byte bALUMNOS_TOTALES) {
		
		byte bContador, bContadorAlumnos = 1;
		
		for (bContador = 0; bContador < bALUMNOS_TOTALES; bContador++) {
			System.out.println("*Alumno "+bContadorAlumnos);
			bEdad[bContador] = (byte)leer("Introduzca la edad ", 16, 50, -1, -1, (byte)1);
			fAltura[bContador] = (float)leer("Introduzca la estatura: ", -1, -1, 1.35, 2.50,(byte)5);
			bContadorAlumnos++;
		}
		
		return sMensaje;
	}
	
	private static String calcularMediaEdad(byte[] bEdad, final byte bALUMNOS_TOTALES, String sMensaje) {
		
		float fMediaEdad, fSumaEdades = 0;
		
		for (byte bContador = 0; bContador < bALUMNOS_TOTALES; bContador++) {
			fSumaEdades += bEdad[bContador];
		}
		fMediaEdad = fSumaEdades/bALUMNOS_TOTALES;
		sMensaje = "La media de las edades es: "+fMediaEdad+" a�os";
		
		return sMensaje;
	}
	
	private static String calcularMediaAltura(float[] fAltura, final byte bALUMNOS_TOTALES, String sMensaje) {
		
		float fMediaAltura, fSumaAltura = 0;
		
		for (byte bContador = 0; bContador < bALUMNOS_TOTALES; bContador++) {
			fSumaAltura += fAltura[bContador];
		}
		fMediaAltura = fSumaAltura/bALUMNOS_TOTALES;
		sMensaje = "La media de las alturas es: "+fMediaAltura+"m";
		
		return sMensaje;
	}
	
	private static String mayores18(byte[] bEdad, final byte bALUMNOS_TOTALES, String sMensaje) {
		
		byte bContadorMayor18 = 0;
		
		for(byte bContador = 0; bContador < bALUMNOS_TOTALES; bContador++) {
			if(bEdad[bContador] >= 18) {
				bContadorMayor18++;
			}
		}
		sMensaje = "Hay un total de "+bContadorMayor18+" alumnos mayores de 18 a�os";
		
		return sMensaje;
	}
	
	private static String masDe180(float[] fAltura, final byte bALUMNOS_TOTALES, String sMensaje) {
		
		byte bContadorMasDe180 = 0;
		
		for(byte bContador = 0; bContador < bALUMNOS_TOTALES; bContador++) {
			if(fAltura[bContador] > 1.80) {
				bContadorMasDe180++;
			}
		}
		sMensaje = "Hay un total de "+bContadorMasDe180+" alumnos que miden mas de 1.80m";
		
		return sMensaje;
	}
	
	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo, byte bEstado) {
		Object oNumero;
		switch(bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje,lMinimo,lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje,lMinimo,lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje,lMinimo,lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje,lMinimo,lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje,dMinimo,dMaximo);
			break;
		case 6:
			oNumero = pideNumeroDouble(sMensaje,dMinimo,dMaximo);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}
	
	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;
		
		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}
	
	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}
	
	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}
	
	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+dMinimo+" - " +dMaximo+"): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}
	
	private static double pideNumeroDouble(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		Double dNumero = (double) 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+dMinimo+" - " +dMaximo+"): ");
			try {
				dNumero = Double.parseDouble(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (dNumero < dMinimo || dNumero > dMaximo));

		return dNumero;
	}

}
