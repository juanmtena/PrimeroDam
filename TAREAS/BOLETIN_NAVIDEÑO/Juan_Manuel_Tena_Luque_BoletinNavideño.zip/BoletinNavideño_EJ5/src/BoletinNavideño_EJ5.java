import java.io.BufferedReader;
import java.io.InputStreamReader;

public class BoletinNavide�o_EJ5 {

	public static void main(String[] args) {
	
		boolean boolAnoBisiesto = false;
		byte bDia = (byte)leer("Introduce dia: ",(long)1,(long)31,-1,-1,(byte)1);
		byte bMes = (byte)leer("Introduce mes: ",(long)1,(long)12,-1,-1,(byte)1);
		short shAno = (short)leer("Introuce a�o: ",(long)1,(long)2500,-1,-1,(byte)2);
		System.out.println(fechaValida(bDia, bMes, shAno, boolAnoBisiesto));
		
	}
	
	private static String fechaValida(byte bDia, byte bMes, short shAno, boolean boolAnoBisiesto) {
		
		String sResultado = "";
		
		if ((shAno % 4 == 0) && ((shAno % 100 != 0) || (shAno % 400 == 0))) {
			boolAnoBisiesto = true;
		}
		if (((boolAnoBisiesto && bMes == 2 && bDia <= 29) || (!boolAnoBisiesto && bMes ==2 && bDia <= 28) || ((bMes == 1 || bMes == 3 || bMes == 5 || bMes == 7 || bMes == 8 || bMes == 10 || bMes == 12) && (bDia <= 31)) || ((bMes == 4 || bMes == 6 || bMes == 9 || bMes == 11) && bDia <= 30))) { 
			sResultado = "\nEl "+bDia+ "/" +bMes+ "/" +shAno+ " es correcta"; 
		}else {
			 sResultado = "\nEl "+bDia+ "/" +bMes+ "/" +shAno+ " no es correcta";
		}
		return sResultado;
	}
	
	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo, byte bEstado) {
		Object oNumero;
		switch(bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje,lMinimo,lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje,lMinimo,lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje,lMinimo,lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje,lMinimo,lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje,dMinimo,dMaximo);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}
	
	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;
		
		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}
	
	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}
	
	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}
	
	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+dMinimo+" - " +dMaximo+"): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}
	
}
