import java.io.BufferedReader;
import java.io.InputStreamReader;

public class BoletinNavide�o_EJ8 {

	public static void main(String[] args) {

		byte bNumero;
		bNumero = (byte) leer("Introduzca un numero positivo: ", 0, 99, -1, -1, (byte) 1);
		leerNumero(bNumero);

	}

	private static byte leerNumero(byte bNumero) {

		String sMensaje = "", sDecenas = "", sUnidades = "";
		byte bDecenas, bUnidades = 0;
		bDecenas = (byte) (bNumero / 10);
		bUnidades = (byte) (bNumero % 10);

		switch (bNumero) {
		case 0:
			sMensaje = "Cero";
			break;
		case 1:
			sMensaje = "Uno";
			break;
		case 2:
			sMensaje = "Dos";
			break;
		case 3:
			sMensaje = "Tres";
			break;
		case 4:
			sMensaje = "Cuatro";
			break;
		case 5:
			sMensaje = "Cinco";
			break;
		case 6:
			sMensaje = "Seis";
			break;
		case 7:
			sMensaje = "Siete";
			break;
		case 8:
			sMensaje = "Ocho";
			break;
		case 9:
			sMensaje = "Nueve";
			break;
		case 10:
			sMensaje = "Diez";
			break;
		case 11:
			sMensaje = "Once";
			break;
		case 12:
			sMensaje = "Doce";
			break;
		case 13:
			sMensaje = "Trece";
			break;
		case 14:
			sMensaje = "Catorce";
			break;
		case 15:
			sMensaje = "Quince";
			break;
		case 16:
			sMensaje = "Dieciseis";
			break;
		case 17:
			sMensaje = "Diecisiete";
			break;
		case 18:
			sMensaje = "Dieciocho";
			break;
		case 19:
			sMensaje = "Diecinueve";
			break;
		case 20:
			sMensaje = "Veinte";
			break;
		case 30:
			sMensaje = "Treinta";
			break;
		case 40:
			sMensaje = "Cuarenta";
			break;
		case 50:
			sMensaje = "Cincuenta";
			break;
		case 60:
			sMensaje = "Sesenta";
			break;
		case 70:
			sMensaje = "Setenta";
			break;
		case 80:
			sMensaje = "Ochenta";
			break;
		case 90:
			sMensaje = "Noventa";
			break;
		}
		
		if (bNumero > 15) {
			if (bDecenas == 1) {
				sDecenas = "Dieci";
			} else if (bDecenas == 2) {
				sDecenas = "Veinti";
			} else if (bDecenas == 3) {
				sDecenas = "Treinta";
			} else if (bDecenas == 4) {
				sDecenas = "Cuarenta";
			} else if (bDecenas == 5) {
				sDecenas = "Cincuenta";
			} else if (bDecenas == 6) {
				sDecenas = "Sesenta";
			} else if (bDecenas == 7) {
				sDecenas = "Setenta";
			} else if (bDecenas == 8) {
				sDecenas = "Ochenta";
			} else if (bDecenas == 9) {
				sDecenas = "Noventa";
			}

			if (bUnidades == 1) {
				sUnidades = "uno";
			} else if (bUnidades == 2) {
				sUnidades = "dos";
			} else if (bUnidades == 3) {
				sUnidades = "tres";
			} else if (bUnidades == 4) {
				sUnidades = "cuatro";
			} else if (bUnidades == 5) {
				sUnidades = "cinco";
			} else if (bUnidades == 6) {
				sUnidades = "seis";
			} else if (bUnidades == 7) {
				sUnidades = "siete";
			} else if (bUnidades == 8) {
				sUnidades = "ocho";
			} else if (bUnidades == 9) {
				sUnidades = "nueve";
			}
		}
		if(bNumero < 20 || bNumero == 30 || bNumero == 40 || bNumero == 50 || bNumero == 60 || bNumero == 70 || bNumero == 80 || bNumero == 90) {
			System.out.println(sMensaje);
		}else if(bNumero > 20 && bNumero < 30) {
			System.out.println(sMensaje + sDecenas + sUnidades);
		}else {
			System.out.println(sMensaje + sDecenas+ " y " +sUnidades);
		}
		
		return bNumero;
	}

	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo,
			byte bEstado) {
		Object oNumero;
		switch (bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje, lMinimo, lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje, lMinimo, lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje, lMinimo, lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje, lMinimo, lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje, dMinimo, dMaximo);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}

	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}

	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}

	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}

	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + dMinimo + " - " + dMaximo + "): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}

}
