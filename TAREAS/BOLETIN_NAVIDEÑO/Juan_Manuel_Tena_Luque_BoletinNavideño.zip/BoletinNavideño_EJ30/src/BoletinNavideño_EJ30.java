import java.io.BufferedReader;
import java.io.InputStreamReader;

public class BoletinNavide�o_EJ30 {

	public static void main(String[] args) {
		
		byte bProvincias = pedirGrupo();
		String[] aNombreProvincia = introducirProvincias(bProvincias);
		int[][] aVotos = introducirVotos(bProvincias, aNombreProvincia);

	}
	
	private static byte pedirGrupo() {
		byte bProvincias;
		do {
			byte bRegion = (byte)leer("Indica la region de la que quiere contabilizar los votos: ", 1,4,-1,-1,(byte)1);
			if(bRegion == 1) {
				bProvincias = 10;
			}else if(bRegion == 2) {
				bProvincias = 4;
			}else if(bRegion == 3) {
				bProvincias = 6;
			}else if(bRegion == 4) {
				bProvincias = 1;
			}else {
				bProvincias = -1;
			}
		}while(bProvincias == -1);
		return bProvincias;
	}
	
	private static String[] introducirProvincias(byte bProvincias) {
		String[] aNombreProvincia = new String[bProvincias];		
		for(int iContador = 0; iContador < bProvincias; iContador++) {
			aNombreProvincia[iContador] = (String)leer("Povincia: ",-1,-1,-1,-1,(byte)8);
		}		
		return aNombreProvincia;
	}
	
	private static int[][] introducirVotos(byte bProvincias, String[] aNombreProvincia) {
		int[][] aVotos = new int[bProvincias][3];
		int iTotalVotos = 0, iTotalAbstenciones = 0, iMaxVotosA = 0, iMaxVotosB = 0;
		final int iTOTALHABITANTES = 1000000;
		float fPorcentajeVotos = 0, fPorcentajeAbstenciones = 0;
		String sMensaje = "", sVotosMaxA = "",  sVotosMaxB = "";
		for(int iFilas = 0; iFilas < bProvincias; iFilas++) {
			System.out.println("\nIntroduce los votos de la provincia de "+aNombreProvincia[iFilas]);
			for(int iColumnas = 0; iColumnas < 3; iColumnas++) {
				aVotos[iFilas][iColumnas] = (int)leer("Votos del partido A: ",1, -1, -1, -1,(byte)3);
				if(aVotos[iFilas][iColumnas] > iMaxVotosA) {
					iMaxVotosA = aVotos[iFilas][iColumnas];
					sVotosMaxA = aNombreProvincia[iFilas];
				}
				iTotalVotos += aVotos[iFilas][iColumnas];
				iColumnas++;
				aVotos[iFilas][iColumnas] = (int)leer("Votos del partido B: ",1, -1, -1, -1,(byte)3);
				if(aVotos[iFilas][iColumnas] > iMaxVotosB) {
					iMaxVotosB = aVotos[iFilas][iColumnas];
					sVotosMaxB = aNombreProvincia[iFilas];
				}
				iTotalVotos += aVotos[iFilas][iColumnas];
				iColumnas++;
				aVotos[iFilas][iColumnas] = (int)leer("Abstenciones: ",1, -1, -1, -1,(byte)3);
				if(aVotos[iFilas][iColumnas] > 100000) {
					sMensaje = "Alta abstencion";
				}
				iTotalAbstenciones = aVotos[iFilas][iColumnas];
				iColumnas++;
			}
		}	
		fPorcentajeVotos = (iTotalVotos * 100) / iTOTALHABITANTES;
		System.out.println("\nHan votado el "+fPorcentajeVotos+"% de los habitantes de la region");
		fPorcentajeAbstenciones = (iTotalAbstenciones * 100) / iTOTALHABITANTES;
		System.out.println("Se han abstenido del voto el "+fPorcentajeAbstenciones+"% de los habitantes de la region");
		System.out.println("La provincia donde el partido A ha conseguido mas votos ha sido: "+sVotosMaxA);
		System.out.println("La provincia donde el partido B ha conseguido mas votos ha sido: "+sVotosMaxB);
		System.out.println(sMensaje);
		return aVotos;
	}

	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo, byte bEstado) {
		Object oNumero;
		switch(bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje,lMinimo,lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje,lMinimo,lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje,lMinimo,lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje,dMinimo,dMaximo);
			break;
		case 6:
			oNumero = pideNumeroDouble(sMensaje,dMinimo,dMaximo);
			break;
		case 7:
			oNumero = pideLetra(sMensaje);
			break;
		case 8:
			oNumero = pideNombre(sMensaje);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}
	
	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;
		
		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}
	
	private static int pideNumeroInt(String sMensaje) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje);
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo);

		return iNumero;
	}
	
	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}
	
	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+dMinimo+" - " +dMaximo+"): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}
	
	private static double pideNumeroDouble(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		Double dNumero = (double) 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+dMinimo+" - " +dMaximo+"): ");
			try {
				dNumero = Double.parseDouble(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (dNumero < dMinimo || dNumero > dMaximo));

		return dNumero;
	}
	
	private static char pideLetra(String sMensaje) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		char cLetra = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje);
			try {
				cLetra = teclado.readLine().toLowerCase().charAt(0);
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo);

		return cLetra;
	}
	
	private static String pideNombre(String sMensaje) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		String sNombre = "";
		boolean bFallo;

		do {
			System.out.print(sMensaje);
			try {
				sNombre = teclado.readLine();
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo);

		return sNombre;
	}

}
