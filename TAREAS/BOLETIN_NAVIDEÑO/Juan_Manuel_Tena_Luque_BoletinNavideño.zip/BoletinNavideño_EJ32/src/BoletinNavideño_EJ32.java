import java.io.BufferedReader;
import java.io.InputStreamReader;

public class BoletinNavide�o_EJ32 {

	public static void main(String[] args) {
		
		byte[] aNumeros = new byte[10];
		introducirNumeros(aNumeros);
		mostrarMenu();
		opcionMenu(aNumeros);

	}
	
	private static byte[] introducirNumeros(byte[] aNumeros) {
		
		System.out.println("Cree su tabla numerica. Para finalizar pulse 0");
		
			for(byte bContador = 0; bContador < 10; bContador++) {
				aNumeros[bContador] = (byte)leer((bContador+1)+"� de los 10 numeros: ", 0, 127, -1, -1,(byte)1);
				if(aNumeros[bContador] == 0) {
					break;
				}
			}
		
		return aNumeros;
	}
	
	private static void mostrarMenu() {
		
		System.out.println("\nElige que desea hacer\n"
				+ "1. Visualizar\n"
				+ "2. Insertar elemento al principio\n"
				+ "3. Borrar elemento al principio\n"
				+ "4. Insertar elemento al final\n"
				+ "5. Borrar elemento al final\n"
				+ "6. Insertar un elemento en una posici�n\n"
				+ "7. Borrar un elemento de una posici�n\n"
				+ "8. SALIR\n");
		
	}
	
	private static void opcionMenu(byte[] aNumeros) {
		
		byte bOpcion = (byte)leer("Seleccione opcion: ", 1, 8, -1, -1,(byte)1);
		byte bContador = 0, bUltimo;
		String sResultado = "";
		boolean boolSalir = false;
		char cGuion = '-';
		
		switch (bOpcion) {
		case 1: //Visualizar
			for(bContador = 0; bContador < aNumeros.length; bContador++) {
				sResultado += (aNumeros[bContador]);
				if(bContador < aNumeros.length - 1) {
					sResultado += ", ";
					if(aNumeros[bContador] == 0){ 
						aNumeros[bContador] = (byte) cGuion;
					}
				}
			}
			System.out.println("{"+sResultado+"}");
			break;
		case 2://Insertar elemento al principio
			for(bContador = 0; bContador < aNumeros.length; bContador++) {
				aNumeros[bContador+1] = aNumeros[bContador];
			}
			if(aNumeros[bContador] != 0) {
				System.out.println("\nImposible introducir datos, tabla llena");
				break;
			}else {
				aNumeros[0] = (byte)leer("Inserte un elemento al principio del vector: ", 1, 127, -1, -1,(byte)1);
				for(bContador = 0; bContador < aNumeros.length; bContador++) {
					sResultado += (aNumeros[bContador]);
					if(bContador < aNumeros.length - 1) {
						sResultado += ", ";
					}
				}
			}
			System.out.println("{"+sResultado+"}");
			break;
		case 3: //Borrar elemento del principio
			for(bContador = 0; bContador < aNumeros.length-1; bContador++) {
				aNumeros[bContador] = aNumeros[bContador+1];
			}
			for(bContador = 0; bContador < aNumeros.length-1; bContador++) {
				sResultado += (aNumeros[bContador]);
				if(bContador < aNumeros.length-2) {
					sResultado += ", ";
				}
			}
			System.out.println("Asi queda el vector eliminando el primer elemento: {"+sResultado+"}");
			break;
		case 4: //Insertar elemento al final
			bUltimo = (byte) (aNumeros.length-1);
			for(bContador = (byte) ((byte) aNumeros.length-1); bContador >= 0; bContador--) { 
				aNumeros[bContador+1] = aNumeros[bContador];
				aNumeros[0] = bUltimo;
			}
			if(aNumeros[bContador] != 0) {
				System.out.println("\nImposible introducir datos, tabla llena");
				break;
			}else {
				aNumeros[0] = (byte)leer("Inserte un elemento al final del vector: ", 1, 127, -1, -1,(byte)1);
				for(bContador = 0; bContador < aNumeros.length; bContador++) {
					sResultado += (aNumeros[bContador]);
					if(bContador < aNumeros.length - 1) {
						sResultado += ", ";
					}
				}
			}
			System.out.println("{"+sResultado+"}");
			break;
		case 5:
			
			break;
		case 6:
			
			break;
		case 7:
			
			break;
		case 8:
			
			break;
		default:
			System.out.println("Error");
		}
		
	}
	
	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo, byte bEstado) {
		Object oNumero;
		switch(bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje,lMinimo,lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje,lMinimo,lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje,lMinimo,lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje,lMinimo,lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje,dMinimo,dMaximo);
			break;
		case 6:
			oNumero = pideNumeroDouble(sMensaje,dMinimo,dMaximo);
			break;
		case 7:
			oNumero = pideLetra(sMensaje);
			break;
		case 8:
			oNumero = pideNombre(sMensaje);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}
	
	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;
		
		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}
	
	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}
	
	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}
	
	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+dMinimo+" - " +dMaximo+"): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}
	
	private static double pideNumeroDouble(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		Double dNumero = (double) 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+dMinimo+" - " +dMaximo+"): ");
			try {
				dNumero = Double.parseDouble(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (dNumero < dMinimo || dNumero > dMaximo));

		return dNumero;
	}
	
	private static char pideLetra(String sMensaje) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		char cLetra = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje);
			try {
				cLetra = teclado.readLine().toLowerCase().charAt(0);
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo);

		return cLetra;
	}
	
	private static String pideNombre(String sMensaje) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		String sNombre = "";
		boolean bFallo;

		do {
			System.out.print(sMensaje);
			try {
				sNombre = teclado.readLine();
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo);

		return sNombre;
	}

}
