import java.io.BufferedReader;
import java.io.InputStreamReader;

public class BoletinNavide�o_EJ40 {

	public static void main(String[] args) {
		
		byte[] aNumeros = new byte[100];
		System.out.println("Este es el vector que se ha creado: \n"+crearNumeros(aNumeros));
		ordenacion(aNumeros);
		System.out.println("\nEste es el vector ordenado: \n"+vectorOrdenado(aNumeros));
		System.out.println("\nEstos son los 10 numeros menores: \n"+mostrarNumerosMenores(aNumeros));
		System.out.println("\nEstos son los 10 numeros mayores: \n"+mostrarNumerosMayores(aNumeros));

	}
	
	private static String crearNumeros(byte[] aNumeros) {	
		String sResultado = "";
	
		for(int iContador = 0; iContador < aNumeros.length; iContador++) {
			aNumeros[iContador] = (byte) (Math.random()*100);
			sResultado += aNumeros[iContador];
			if(iContador < aNumeros.length - 1) {
				sResultado += " - ";
			}
		}		
		return sResultado;
	}
	
	public static byte[] ordenacion(byte[] aNumeros) {
		
		byte bContador, bContador2 = 0;
		float fTemporal = 0;
		
		for (bContador = 1; bContador < aNumeros.length; bContador++) {
			for (bContador2 = 0; bContador2 < aNumeros.length-1; bContador2++) {
				if (aNumeros[bContador2] > aNumeros[bContador2+1]) {
					fTemporal = aNumeros [bContador2];
					aNumeros[bContador2] = aNumeros[bContador2+1];
					aNumeros[bContador2+1] = (byte) fTemporal;
				}	
			}	
		}		
		return aNumeros;
	}
	
	private static String vectorOrdenado(byte[] aNumeros) {	
		String sResultado = "";
	
		for(int iContador = 0; iContador < aNumeros.length; iContador++) {
			sResultado += aNumeros[iContador];
			if(iContador < aNumeros.length - 1) {
				sResultado += " - ";
			}
		}		
		return sResultado;
	}
	
	private static String mostrarNumerosMenores(byte[] aNumeros) {	
		String sResultado = "";
	
		for(int iContador = 0; iContador < 10; iContador++) {
			sResultado += aNumeros[iContador];
			if(iContador < 9) {
				sResultado += " - ";
			}
		}		
		return sResultado;
	}
	
	private static String mostrarNumerosMayores(byte[] aNumeros) {	
		String sResultado = "";
		for(int iContador = 90; iContador < aNumeros.length; iContador++) {
			sResultado += aNumeros[iContador];
			if(iContador < aNumeros.length-1) {
				sResultado += " - ";
			}
		}		
		return sResultado;
	}
	
	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo, byte bEstado) {
		Object oNumero;
		switch(bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje,lMinimo,lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje,lMinimo,lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje,lMinimo,lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje,lMinimo,lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje,dMinimo,dMaximo);
			break;
		case 6:
			oNumero = pideNumeroDouble(sMensaje,dMinimo,dMaximo);
			break;
		case 7:
			oNumero = pideLetra(sMensaje);
			break;
		case 8:
			oNumero = pideNombre(sMensaje);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}
	
	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;
		
		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}
	
	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}
	
	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}
	
	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+dMinimo+" - " +dMaximo+"): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}
	
	private static double pideNumeroDouble(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		Double dNumero = (double) 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+dMinimo+" - " +dMaximo+"): ");
			try {
				dNumero = Double.parseDouble(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (dNumero < dMinimo || dNumero > dMaximo));

		return dNumero;
	}
	
	private static char pideLetra(String sMensaje) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		char cLetra = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje);
			try {
				cLetra = teclado.readLine().toLowerCase().charAt(0);
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo);

		return cLetra;
	}
	
	private static String pideNombre(String sMensaje) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		String sNombre = "";
		boolean bFallo;

		do {
			System.out.print(sMensaje);
			try {
				sNombre = teclado.readLine();
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo);

		return sNombre;
	}

}
