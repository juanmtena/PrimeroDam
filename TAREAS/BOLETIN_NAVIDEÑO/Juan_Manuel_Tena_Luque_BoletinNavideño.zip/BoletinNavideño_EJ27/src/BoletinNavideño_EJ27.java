import java.io.BufferedReader;
import java.io.InputStreamReader;

public class BoletinNavide�o_EJ27 {

	public static void main(String[] args) {		
	
		int iNumAlumnos = pedirGrupo();		
		
		String[] aNombresAlumnos = rellenarNombres(iNumAlumnos);
		float[][] aNotasAlumnos = rellenarNotas(iNumAlumnos, aNombresAlumnos);
		
		System.out.println("El alumno con la nota media mas alta es: "+aNombresAlumnos[alumnoNotaMediaAlta(aNotasAlumnos)]);		
		System.out.println("El numero de alumnos con la nota media suspendida es: "+alumnosSuspendidos(aNotasAlumnos));
		
		if(existenSobresalientes(aNotasAlumnos)) {
			System.out.println("Existen sobresalientes.");
		}else {
			System.out.println("No existen sobresalientes.");
		}
	}
	
	private static int pedirGrupo() {
		int iNumAlumnos;
		do {
			char cGrupo = (char)leer("Introduce la letra del grupo del que va a introducir los datos: ",-1,-1,-1,-1,(byte)7);
			if(cGrupo == 'a') {
				iNumAlumnos = 5;
			}else if(cGrupo == 'b') {
				iNumAlumnos = 28;
			}else if(cGrupo == 'c') {
				iNumAlumnos = 31;
			}else if(cGrupo == 'd') {
				iNumAlumnos = 29;
			}else {
				iNumAlumnos = -1;
			}
		}while(iNumAlumnos == -1);
		return iNumAlumnos;
	}
	
	private static String[] rellenarNombres(int iNumAlumnos) {
		String[] aNombresAlumnos = new String[iNumAlumnos];		
		for(int iContador = 0; iContador < iNumAlumnos; iContador++) {
			aNombresAlumnos[iContador] = (String)leer("Nombre: ",-1,-1,-1,-1,(byte)8);
		}		
		return aNombresAlumnos;
	}
	
	private static float[][] rellenarNotas(int iNumAlumnos, String[] aNombresAlumnos) {
		float[][] aNotasAlumnos = new float[iNumAlumnos][3];		
		for(int iFilas = 0; iFilas < iNumAlumnos; iFilas++) {
			System.out.println("Introduce las notas para el alumno "+aNombresAlumnos[iFilas]);
			for(int iColumnas = 0; iColumnas < 3; iColumnas++) {
				aNotasAlumnos[iFilas][iColumnas] = (float)leer("Introduce la nota del trimestre "+(iColumnas+1)+": ",-1, -1, 0.0, 10.0,(byte)5);				
			}
		}		
		return aNotasAlumnos;
	}
	
	private static int alumnoNotaMediaAlta(float[][] aNotasAlumnos) {
		int iPosicion = -1;
		float fMediaAlta = -1;
		
		for(int iFilas = 0; iFilas < aNotasAlumnos.length; iFilas++) {
			float fMedia = 0;
			for(int iColumnas = 0; iColumnas < aNotasAlumnos[0].length; iColumnas++) {
				fMedia += aNotasAlumnos[iFilas][iColumnas];
			}
			fMedia /= 3;
			if(fMediaAlta < fMedia) {
				fMediaAlta = fMedia;
				iPosicion = iFilas;
			}
			
		}
		
		return iPosicion;
	}
		
	private static int alumnosSuspendidos(float[][] aNotasAlumnos) {		
		int iNumSuspensos = 0;		
		for(int iFilas = 0; iFilas < aNotasAlumnos.length; iFilas++) {
			float fMedia = 0;
			for(int iColumnas = 0; iColumnas < aNotasAlumnos[0].length; iColumnas++) {
				fMedia += aNotasAlumnos[iFilas][iColumnas];
			}
			fMedia /= 3;
			if(fMedia < 5) {
				iNumSuspensos++;
			}			
		}		
		return iNumSuspensos;		
	}
	
	private static boolean existenSobresalientes(float[][] aNotasAlumnos) {
		boolean bSobresalientes = false;
		int iFilas = 0, iColumnas = 0;	
		while(iFilas < aNotasAlumnos.length && !bSobresalientes) {
			while(iColumnas < aNotasAlumnos[0].length && !bSobresalientes) {
				if(aNotasAlumnos[iFilas][iColumnas] >= 9) {
					bSobresalientes = true;
				}
				iColumnas++;
			}
			iFilas++;
		}		
		return bSobresalientes;
	}
	
	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo, byte bEstado) {
		Object oNumero;
		switch(bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje,lMinimo,lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje,lMinimo,lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje,lMinimo,lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje,lMinimo,lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje,dMinimo,dMaximo);
			break;
		case 6:
			oNumero = pideNumeroDouble(sMensaje,dMinimo,dMaximo);
			break;
		case 7:
			oNumero = pideLetra(sMensaje);
			break;
		case 8:
			oNumero = pideNombre(sMensaje);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}
	
	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;
		
		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}
	
	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}
	
	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+lMinimo+" - " +lMaximo+"): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}
	
	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+dMinimo+" - " +dMaximo+"): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}
	
	private static double pideNumeroDouble(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		Double dNumero = (double) 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "("+dMinimo+" - " +dMaximo+"): ");
			try {
				dNumero = Double.parseDouble(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (dNumero < dMinimo || dNumero > dMaximo));

		return dNumero;
	}
	
	private static char pideLetra(String sMensaje) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		char cLetra = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje);
			try {
				cLetra = teclado.readLine().toLowerCase().charAt(0);
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo);

		return cLetra;
	}
	
	private static String pideNombre(String sMensaje) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		String sNombre = "";
		boolean bFallo;

		do {
			System.out.print(sMensaje);
			try {
				sNombre = teclado.readLine();
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo);

		return sNombre;
	}

}
