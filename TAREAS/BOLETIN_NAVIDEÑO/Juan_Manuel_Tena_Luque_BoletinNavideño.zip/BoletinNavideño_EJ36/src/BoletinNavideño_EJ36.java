import java.io.BufferedReader;
import java.io.InputStreamReader;

public class BoletinNavide�o_EJ36 {

	public static void main(String[] args) {

		Byte[] aNumeros = new Byte[5];
		Byte[] aNumerosCopia = new Byte[aNumeros.length];
		Byte[] aNumerosCopia2 = new Byte[aNumeros.length+1];
		introducirNumeros(aNumeros);
		byte bN1 = (byte)leer("\nIntroduzca un numero y se eliminaran todos los numeros menores al numero introducido: ", 1, 100, -1, -1,(byte)1);
		desplazarVector(aNumeros);
		eliminarNumeros(aNumeros, bN1);
		byte bN2 = (byte)leer("Introduzca numero y se colocar� justo detr�s del primer elemento menor al numero introducido: ", 1, 100, -1, -1,(byte)1);
		insertarNumero(aNumerosCopia2, bN2);
		
	}

	private static Byte[] introducirNumeros(Byte[] aNumeros) {
		
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		
		byte bTemporal = 0;
		
		System.out.print("Sistema de almacenamiento de numeros.\n\nInstrucciones:\n-Solo ser�n validos los numeros positivos.\n-Si introduce un numero negativo, no se guardar� y el programa le volver� a pedir que introduzca otro numero.\n-Puede finalizar en cualquier momento pulsando el numero 0\n\n");
		for (byte bContador = 0; bContador < aNumeros.length; bContador++) {
			System.out.print((bContador + 1) + ". Introduce numero (1 - 100): ");
			try {
				bTemporal = Byte.parseByte(teclado.readLine());
			} catch (Exception e) {
				bTemporal = -1;
			}
			if (bTemporal > 0 && bTemporal <= 100) {
				aNumeros[bContador] = bTemporal;
			} else if (bTemporal == 0) {
				break;
			} else {
				bContador--;
			}
		}
		return aNumeros;
	}
	
	private static Byte[] desplazarVector(Byte[] aNumerosCopia) {
		
		byte bContador, bPrimerNumero = aNumerosCopia[0];
		
		for(bContador = 0; bContador < aNumerosCopia.length-1; bContador++) {
			aNumerosCopia[bContador] = aNumerosCopia[bContador+1];
		}
		aNumerosCopia[bContador] = bPrimerNumero;
		
		return aNumerosCopia;
	}
	
	private static Byte[] eliminarNumeros(Byte[] aNumerosCopia, byte bN1) {
		
		for(byte bContador = 0; bContador < aNumerosCopia.length; bContador++) {
			if(aNumerosCopia[bContador] < bN1) {
				aNumerosCopia[bContador] = null;
			}
		}
		
		return aNumerosCopia;
	}
	
	private static Byte[] insertarNumero(Byte[] aNumerosCopia2, Byte[] aNumeros, byte bN2) {
		
		byte bTemporal;
		
		for(byte bContador = 0; bContador < aNumeros.length; bContador--) {
			if(bN2 < aNumeros[bContador]) {
				bTemporal = aNumeros[bContador+1];
				aNumeros[bContador+1] = bTemporal;
				aNumeros[bContador+1] = bTemporal;
			}
			aNumerosCopia2[bContador] = aNumeros[bContador];
		}
		
		return aNumerosCopia2;
	}

	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo,
			byte bEstado) {
		Object oNumero;
		switch (bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje, lMinimo, lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje, lMinimo, lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje, lMinimo, lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje, lMinimo, lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje, dMinimo, dMaximo);
			break;
		case 6:
			oNumero = pideNumeroDouble(sMensaje, dMinimo, dMaximo);
			break;
		case 7:
			oNumero = pideLetra(sMensaje);
			break;
		case 8:
			oNumero = pideNombre(sMensaje);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}

	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}

	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}

	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}

	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + dMinimo + " - " + dMaximo + "): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}

	private static double pideNumeroDouble(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		Double dNumero = (double) 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + dMinimo + " - " + dMaximo + "): ");
			try {
				dNumero = Double.parseDouble(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (dNumero < dMinimo || dNumero > dMaximo));

		return dNumero;
	}

	private static char pideLetra(String sMensaje) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		char cLetra = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje);
			try {
				cLetra = teclado.readLine().toLowerCase().charAt(0);
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo);

		return cLetra;
	}

	private static String pideNombre(String sMensaje) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		String sNombre = "";
		boolean bFallo;

		do {
			System.out.print(sMensaje);
			try {
				sNombre = teclado.readLine();
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo);

		return sNombre;
	}

}
