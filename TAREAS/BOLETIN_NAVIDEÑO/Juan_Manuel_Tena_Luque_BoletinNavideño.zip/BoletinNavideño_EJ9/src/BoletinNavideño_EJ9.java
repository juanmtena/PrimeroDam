import java.io.BufferedReader;
import java.io.InputStreamReader;

public class BoletinNavide�o_EJ9 {

	public static void main(String[] args) {

		short shNumero = (short) leer("Introduzca un numero positivo: ", 0, 9999, -1, -1, (byte) 2);
		leerNumero(shNumero);

	}

	private static short leerNumero(short shNumero) {

		String sMensaje = "", sDecenas = "", sUnidades = "", sCentenas = "", sMil = "";
		byte bDecenas, bUnidades = 0;
		short shCentenas, shMil;
		shMil = (short) (shNumero / 1000);
		shCentenas = (short) (shNumero / 100);
		bDecenas = (byte) (shNumero / 10);
		bUnidades = (byte) (shNumero % 10);

		switch (shNumero) {
		
		case 15:
			sMensaje = "Quince";
			break;
		case 20:
			sMensaje = "Veinte";
			break;
		case 30:
			sMensaje = "Treinta";
			break;
		case 40:
			sMensaje = "Cuarenta";
			break;
		case 50:
			sMensaje = "Cincuenta";
			break;
		case 60:
			sMensaje = "Sesenta";
			break;
		case 70:
			sMensaje = "Setenta";
			break;
		case 80:
			sMensaje = "Ochenta";
			break;
		case 90:
			sMensaje = "Noventa";
			break;
		
		}
		
		if(shNumero == 0) {
			sUnidades = "cero";
		} else if(bUnidades == 1) {
			sUnidades = "uno";
		} else if (bUnidades == 2) {
			sUnidades = "dos";
		} else if (bUnidades == 3) {
			sUnidades = "tres";
		} else if (bUnidades == 4) {
			sUnidades = "cuatro";
		} else if (bUnidades == 5) {
			sUnidades = "cinco";
		} else if (bUnidades == 6) {
			sUnidades = "seis";
		} else if (bUnidades == 7) {
			sUnidades = "siete";
		} else if (bUnidades == 8) {
			sUnidades = "ocho";
		} else if (bUnidades == 9) {
			sUnidades = "nueve";
		}

		if (shNumero > 15) {
			if (bDecenas == 1) {
				sDecenas = "dieci";
			} else if (bDecenas == 2) {
				sDecenas = "veinti";
			} else if (bDecenas == 3) {
				sDecenas = "creinta";
			} else if (bDecenas == 4) {
				sDecenas = "cuarenta";
			} else if (bDecenas == 5) {
				sDecenas = "cincuenta";
			} else if (bDecenas == 6) {
				sDecenas = "sesenta";
			} else if (bDecenas == 7) {
				sDecenas = "setenta";
			} else if (bDecenas == 8) {
				sDecenas = "ochenta";
			} else if (bDecenas == 9) {
				sDecenas = "noventa";
			}

			
			if(shNumero/100 == 0) {
				sCentenas = "Cien";
			}else if(shCentenas == 1) {
				sCentenas = "Ciento ";
			}else if(shCentenas == 2) {
				sCentenas = "Doscientos ";
			}else if(shCentenas == 3) {
				sCentenas = "Trescientos ";
			}else if(shCentenas == 4) {
				sCentenas = "Cuatrocientos ";
			}else if(shCentenas == 5) {
				sCentenas = "Quinientos ";
			}else if(shCentenas == 6) {
				sCentenas = "Seiscientos ";
			}else if(shCentenas == 7) {
				sCentenas = "Setecientos ";
			}else if(shCentenas == 8) {
				sCentenas = "Ochocientos ";
			}else if(shCentenas == 9) {
				sCentenas = "Novecientos ";
			}
			
		}
		if (shNumero <= 15 || shNumero == 20 || shNumero == 30 || shNumero == 40 || shNumero == 50 || shNumero == 60
				|| shNumero == 70 || shNumero == 80 || shNumero == 90) {
			System.out.println(sMensaje+sUnidades);
		} else if (shNumero > 15 && shNumero < 30) {
			System.out.println(sMensaje + sDecenas + sUnidades);
		} else if(shNumero < 131 || shCentenas != 0) {
			System.out.println(sMensaje + sCentenas + sDecenas + sUnidades);
		}else{
			System.out.println(sMensaje + sCentenas + sDecenas + " y " + sUnidades);
		}
		

		return shNumero;
	}

	private static Object leer(String sMensaje, long lMinimo, long lMaximo, double dMinimo, double dMaximo,
			byte bEstado) {
		Object oNumero;
		switch (bEstado) {
		case 1:
			oNumero = pideNumeroByte(sMensaje, lMinimo, lMaximo);
			break;
		case 2:
			oNumero = pideNumeroShort(sMensaje, lMinimo, lMaximo);
			break;
		case 3:
			oNumero = pideNumeroInt(sMensaje, lMinimo, lMaximo);
			break;
		case 4:
			oNumero = pideNumeroLong(sMensaje, lMinimo, lMaximo);
			break;
		case 5:
			oNumero = pideNumeroFloat(sMensaje, dMinimo, dMaximo);
			break;
		default:
			oNumero = -1;
		}
		return oNumero;
	}

	private static byte pideNumeroByte(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		byte bNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				bNumero = Byte.parseByte(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (bNumero < lMinimo || bNumero > lMaximo));

		return bNumero;
	}

	private static short pideNumeroShort(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		short sNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				sNumero = Short.parseShort(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (sNumero < lMinimo || sNumero > lMaximo));

		return sNumero;
	}

	private static int pideNumeroInt(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		int iNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (iNumero < lMinimo || iNumero > lMaximo));

		return iNumero;
	}

	private static long pideNumeroLong(String sMensaje, long lMinimo, long lMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		long lNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + lMinimo + " - " + lMaximo + "): ");
			try {
				lNumero = Long.parseLong(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (lNumero < lMinimo || lNumero > lMaximo));

		return lNumero;
	}

	private static float pideNumeroFloat(String sMensaje, double dMinimo, double dMaximo) {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		float fNumero = 0;
		boolean bFallo;

		do {
			System.out.print(sMensaje + "(" + dMinimo + " - " + dMaximo + "): ");
			try {
				fNumero = Float.parseFloat(teclado.readLine());
				bFallo = false;
			} catch (Exception e) {
				bFallo = true;
			}
		} while (bFallo || (fNumero < dMinimo || fNumero > dMaximo));

		return fNumero;
	}

}
