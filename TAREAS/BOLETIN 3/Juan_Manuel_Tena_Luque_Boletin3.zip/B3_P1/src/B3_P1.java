import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B3_P1 {

	public static void main(String[] args) {

		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));

		float fTiempo1, fTiempo2, fTiempo3, fTiempo4, fTiempo5;

		do {
			try {
				System.out.print("1. Introduce numero: ");
				fTiempo1 = Float.parseFloat(teclado.readLine());// Casting e introducir por teclado
	
			} catch (Exception e) {
				fTiempo1 = -1;
				System.out.println("El numero introducio no es valido");
			} 
		}while (fTiempo1 <= 0);
		
		do {
			try {
			System.out.print("2. Introduce numero: ");
			fTiempo2 = Float.parseFloat(teclado.readLine());// Casting e introducir por teclado

			} catch (Exception e) {
				fTiempo2 = 0;
				System.out.println("El numero introducio no es valido");
			}
		}while (fTiempo2 <= fTiempo1);
		
		do {
			try {
			System.out.print("3. Introduce numero: ");
			fTiempo3 = Float.parseFloat(teclado.readLine());// Casting e introducir por teclado

			} catch (Exception e) {
				fTiempo3 = -1;
				System.out.println("El numero introducio no es valido");
			}
		}while (fTiempo3 <= fTiempo2);
		
		do {
			try {
			System.out.print("4. Introduce numero: ");
			fTiempo4 = Float.parseFloat(teclado.readLine());// Casting e introducir por teclado

			} catch (Exception e) {
				fTiempo4 = -1;
				System.out.println("El numero introducio no es valido");
			}
		}while (fTiempo4 <= fTiempo3);
		
		do {
			try {
			System.out.print("5. Introduce numero: ");
			fTiempo5 = Float.parseFloat(teclado.readLine());// Casting e introducir por teclado

			} catch (Exception e) {
				fTiempo5 = -1;
				System.out.println("El numero introducio no es valido");
			}
		}while (fTiempo5 <= fTiempo4);
		
		System.out.println("La diferencia entre tiempos es "+(fTiempo1 - fTiempo1)+", "+(fTiempo2 - fTiempo1)+", "+(fTiempo3 - fTiempo1)+", "+(fTiempo4 - fTiempo1)+", "+(fTiempo5 - fTiempo1)+".");

	}

}