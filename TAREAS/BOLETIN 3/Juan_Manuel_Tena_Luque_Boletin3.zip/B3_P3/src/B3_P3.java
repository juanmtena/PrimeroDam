import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B3_P3 {

	public static void main(String[] args) {

		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));

		int iNumero;
		byte bContador;

		System.out.print("Pulse una tecla num�rica: ");
			try {
				iNumero = Integer.parseInt(teclado.readLine());
			} catch (Exception e) {
				iNumero = -1;
			}
			if (iNumero >= 0 && iNumero <= 9) {
				System.out.println("Has pulsado la tecla num�rica " + iNumero);
			} else {
				for (bContador = 1; bContador <= 3; bContador++) {
					try {
						System.out.print("Vuelve a intentarlo. Introduce una tecla mum�rica: ");
						iNumero = Integer.parseInt(teclado.readLine());
					} catch (Exception e1) {
						iNumero = -1;
					}			
					
				}
						
			}

	}

}
