
public class B3_EJ3 {

	public static void main(String[] args) {
		
		//Declaracion de variables
		short shContador;
		String sMultiplo =" ";
		
		//Contador para sumar de 5 en 5
		for (shContador = 5; shContador <= 1000; shContador += 5) {
			sMultiplo = shContador+" ";
			//Imprimir por pantalla el resultado
			System.out.print(sMultiplo);
		}	

	}

}
