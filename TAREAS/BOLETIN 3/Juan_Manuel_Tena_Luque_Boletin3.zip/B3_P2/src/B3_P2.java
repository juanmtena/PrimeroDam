import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B3_P2 {

	public static void main(String[] args) {
		
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		
		int iNumero;
		
		do {
			try {
				System.out.print("Introduce numero: ");
				iNumero = Integer.parseInt(teclado.readLine());// Casting e introducir por teclado
	
			} catch (Exception e) {
				iNumero = -1;
				System.out.println("Error.");
			} 
		}while (iNumero <= 0);
		
		
		if (iNumero % 2 == 0) {
			System.out.println("El n�mero es multiplo de 2.");
		} else {
			System.out.println("El n�mero no es multiplo de 2.");
		}
		if (iNumero % 3 == 0) {
			System.out.println("El n�mero es multiplo de 3.");
		} else {
			System.out.println("El n�mero no es multiplo de 3.");
		}
		if (iNumero % 5 == 0) {
			System.out.println("El n�mero es multiplo de 5.");
		} else {
			System.out.println("El n�mero no es multiplo de 5.");
		}
		if (iNumero % 7 == 0) {
			System.out.println("El n�mero es multiplo de 7.");
		} else {
			System.out.println("El n�mero no es multiplo de 7.");
		}
		if (iNumero % 10 == 0) {
			System.out.println("El n�mero es multiplo de 10.");
		} else {
			System.out.println("El n�mero no es multiplo de 10.");
		}
		

	}

}
