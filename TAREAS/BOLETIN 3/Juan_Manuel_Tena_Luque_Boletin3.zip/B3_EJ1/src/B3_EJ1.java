import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B3_EJ1 {

	public static void main(String[] args) {

		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));

		// Declaracion de vatiables
		int iNumero1, iNumero2, iNumero3;

		do {
			try {
				System.out.print("1. Introduce numero : ");// Pedir por teclado los numeros
				iNumero1 = Integer.parseInt(teclado.readLine());// Guardar valor del dato y casting

			} catch (Exception e) {
				iNumero1 = -2000000001;// Mensaje para daro no v�lido
				System.out.println("Error 404 not found");

			}
		} while (iNumero1 < -2000000000 || iNumero1 > 2000000000);

		do {
			try {
				System.out.print("2. Introduce numero : ");
				iNumero2 = Integer.parseInt(teclado.readLine());

			} catch (Exception e) {
				iNumero2 = -1;
				System.out.println("El numero introducio no es valido");
			}
		} while (iNumero2 < -2000000000 || iNumero2 > 2000000000);

		do {
			try {
				System.out.print("3. Introduce numero : ");
				iNumero3 = Integer.parseInt(teclado.readLine());

			} catch (Exception e) {
				iNumero3 = -1;
				System.out.println("El numero introducio no es valido");
			}
		} while (iNumero3 < -2000000000 || iNumero3 > 2000000000);

		if ((iNumero3 > iNumero2) && (iNumero2 > iNumero1)) {
			System.out.println("Los numeros est�n en orden creciente.");
		} else {
			System.out.println("El numero no est�n en orden creciente.");
		}
	}

}