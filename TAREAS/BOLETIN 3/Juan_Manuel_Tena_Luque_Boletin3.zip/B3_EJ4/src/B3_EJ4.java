import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B3_EJ4 {
	public static void main(String[] args) {
		
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		//Declaracion de variables y darle valor al boolean
		int iNumero;
		boolean bEsPrimo = true;
		int iContador;
		
		//Pedir que introduzca numero
		try {
			System.out.print("Introduce un numero entero: ");
			//Casting y guardar numero introducido en la variable
			iNumero = Integer.parseInt(teclado.readLine());
		} catch (Exception e) {
			iNumero = -1;
		}
		
		//Logica del programa
		if (iNumero > 0) {
			iContador = 2;
			while (iContador < iNumero && bEsPrimo) {
				//Calculo para conocer si el numero es primo
				if (iNumero % iContador == 0) {
					bEsPrimo = false;
				}
				iContador++;
			}
			
			//Condiciones para imprimir por pantalla el mensaje con el resultado
			if(bEsPrimo) {
				System.out.println("El numero "+iNumero+" es primo.");
			}else {
				System.out.println("El numero "+iNumero+" no es primo.");
			}
		}else {
			System.out.println("Error. Valor no v�lido");
		}
		
		

	}
}