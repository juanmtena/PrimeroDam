import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B3_EJ2 {

	public static void main(String[] args) {

		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));

		float fLado1, fLado2, fLado3;

		do {
			try {
				System.out.print("Lado 1: ");// Pedir por teclado los numeros
				fLado1 = Float.parseFloat(teclado.readLine());// Guardar valor del dato y casting

			} catch (Exception e) {
				fLado1 = -1;// Mensaje para daro no v�lido
				System.out.println("Error 404 not found");
			}
		} while (fLado1 <= 0);
		
		do {
			try {
				System.out.print("Lado 2: ");// Pedir por teclado los numeros
				fLado2 = Float.parseFloat(teclado.readLine());// Guardar valor del dato y casting

			} catch (Exception e) {
				fLado2 = -1;// Mensaje para daro no v�lido
				System.out.println("Error 404 not found");
			}
		} while (fLado2 <= 0);
		
		do {
			try {
				System.out.print("Lado 3: ");// Pedir por teclado los numeros
				fLado3 = Float.parseFloat(teclado.readLine());// Guardar valor del dato y casting

			} catch (Exception e) {
				fLado3 = -1;// Mensaje para daro no v�lido
				System.out.println("Error 404 not found");
			}
		} while (fLado3 <= 0);
		
		if ((fLado1 == fLado2) && (fLado2 == fLado3)) {
			System.out.println("Es un triangulo equilatero");
		} else if ((fLado1 != fLado2) && (fLado2 != fLado3) && (fLado1 != fLado3)) {
			System.out.println("Es un triangulo escaleno");
		} else {
			System.out.println("Es un triangulo isosceles");
		}
	}

}
