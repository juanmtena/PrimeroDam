import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B3_P4 {

	public static void main(String[] args) {
		
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		
		int iNumero;
		
		do {
			try {
				System.out.print("Introduce numero: ");
				iNumero = Integer.parseInt(teclado.readLine());// Casting e introducir por teclado
	
			} catch (Exception e) {
				iNumero = -1;
				System.out.println("Error.");
			} 
			
			if (iNumero%2 != 0 && iNumero%3 != 0) {	
				System.out.println("Upss! Ha ocurrido un error.");
			} else {			
				System.out.println(iNumero+ "/2 = "+iNumero/2);
				System.out.println(iNumero+ "/3 = "+iNumero/3);
			}
									
		} while (iNumero%2 != 0 || iNumero%3 != 0);

	}

}