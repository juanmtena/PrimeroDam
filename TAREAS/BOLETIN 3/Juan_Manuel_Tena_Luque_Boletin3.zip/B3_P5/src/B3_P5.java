import java.io.BufferedReader;
import java.io.InputStreamReader;

public class B3_P5 {

	public static void main(String[] args) {
		
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		
		double dResultado = 1;
		byte bContador, bBase, bExponente;
		
		do {
			try {
				System.out.print("Introduce la base: ");
				bBase = Byte.parseByte(teclado.readLine());
			} catch (Exception e) {
				bBase = -1;
				System.out.println("Error."); 
			} 
		} while (bBase < 0);
		
		do {
			try {
				System.out.print("Introuce el exponente: ");
				bExponente = Byte.parseByte(teclado.readLine());
			} catch (Exception e) {
				bExponente = -1;
				System.out.println("Error."); 
			} 
		} while (bExponente < 0);
		
		for (bContador = 1; bContador <= bExponente; bContador++)
			dResultado = dResultado * bBase;
		
		System.out.println(bBase+ " elevado a " +bExponente+ " es: " +dResultado);

	}

}
