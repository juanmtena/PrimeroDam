package Ejercicio3;

public class MainSemaforo {

	public static void main(String[] args) {
		
		Semaforo sem = new Semaforo(1,true);
		
		System.out.println(sem.imprimir());
		System.out.println(sem.cambia());
		Semaforo sem2 = new Semaforo();
		sem2.setiColor(sem.getiColor()); //Asignar los valores del primer objeto
		System.out.println(sem.cadenaColor());

	}

}
