package Problema3;

public class Climatizador {

	private boolean boolEncendido;
	private float fTemperaturaActual;
	private float fTemperaturaDeseada;
	
	

	public Climatizador(boolean boolEncendido, float fTemperaturaActual, float fTemperaturaDeseada) {
		this.boolEncendido = boolEncendido;
		setTemperaturaActual(fTemperaturaActual);
		setTemperaturaDeseada(fTemperaturaDeseada);
	}

	public void activar() {
		if(isBoolEncendido() == true) {
			enfriar();
			calentar();			
		}
	}
	
	public boolean desactivar() {
		if(fTemperaturaActual == fTemperaturaDeseada) {
			this.boolEncendido = true;
		}
		return boolEncendido;
	}
	
	public boolean isBoolEncendido() {
		return boolEncendido;
	}

	public float getTemperaturaActual() {
		return fTemperaturaActual;
	}

	public void setTemperaturaActual(float fTemperaturaActual) {
		if(isBoolEncendido() == true && fTemperaturaActual >= 18 || fTemperaturaActual <= 30) {
			this.fTemperaturaActual = fTemperaturaActual;
		}
	}

	public float getTemperaturaDeseada() {
		return fTemperaturaDeseada;
	}

	public void setTemperaturaDeseada(float fTemperaturaDeseada) {
		if(isBoolEncendido() == true && fTemperaturaDeseada >= 18 || fTemperaturaDeseada <= 30) {
			this.fTemperaturaDeseada = fTemperaturaDeseada;
		}
	}

	public String enfriar() {
		String sMensaje = "";
		sMensaje = "Esta bajando la temperatura\n";
		while(getTemperaturaActual() > getTemperaturaDeseada()) {
			this.fTemperaturaActual -= 0.5;
			sMensaje += this.fTemperaturaActual+"\n";
		}
		return sMensaje;
	}
	
	public String calentar() {
		String sMensaje = "";
		sMensaje = "Esta subiendo la temperatura\n";
		while(getTemperaturaActual() < getTemperaturaDeseada()) {
			this.fTemperaturaActual += 0.5;
			sMensaje += this.fTemperaturaActual+"\n";
		}
		return sMensaje;
	}
	
	public String mostrar() {
		String sTemperatura = "";
		
		if(fTemperaturaActual > fTemperaturaDeseada) {
			sTemperatura += enfriar()+" grados";
		}
		
		if(fTemperaturaActual < fTemperaturaDeseada) {
			sTemperatura += calentar()+" grados";
		}
		
		if(fTemperaturaActual == fTemperaturaDeseada && boolEncendido == true) {
			sTemperatura += "\nHa llegado a la temperatura deseada OFF";
		}else {
			sTemperatura += "\nEl climatizador esta apagado OFF";
		}
		
		return sTemperatura;
	}
	
}

