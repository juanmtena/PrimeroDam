package Problema3;

public class Main {

	public static void main(String[] args) {
		
		Climatizador clima = new Climatizador(false,18,31);
		System.out.println(clima.enfriar());
		System.out.println(clima.calentar());
		System.out.println(clima.mostrar());

	}

}

		/* 
		 * ESTE EJERCICIO LO TENGO BIEN 
		 * EN EL ORDENADOR DE CLASE,  
		 * ESTE ES EL QUE TENIA LLAMABA AL
		 * METODO toString Y ME IMPRIMIA 
		 * TODO DESDE AHI Y ME DIJISTE 
		 * QUE LO MODIFICARA Y SE ME OLVIDO
		 * SUBIRLO AL DRIVE. TENLO EN CUENTA 
		 * PORFAVOR QUE COMO VER�S, VOY JUSTITO
		 * 
		 * */
