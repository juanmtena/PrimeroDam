package Problema3;

public class MainClimatizador {

	public static void main(String[] args) {
		
			
		Climatizador clima = new Climatizador(true,18,31);
		clima.toString();

	}

}
