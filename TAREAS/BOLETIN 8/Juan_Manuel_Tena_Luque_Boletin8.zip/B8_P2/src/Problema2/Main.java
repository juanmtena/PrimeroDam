package Problema2;

public class Main {

	public static void main(String[] args) {
		
		Punto p1 = new Punto();
		Punto p2 = new Punto(3,2);
		System.out.println(p1.toString());
		System.out.println(p2.toString());
		System.out.println("Distancia del punto 1 al punto 2: "+p1.distancia(p2));
		
		
		
		/* ESTO SON COMPROBACIONES DEL RESTO 
		 * DE APARTADOS QUE PIDE EL EJERCICIO
		 * 
		 * System.out.println(p1.toString());
		 * p1.mover(); //Introduce valor de X e Y
		 * p2.mover(8, 7); //Asigna estos valores a X e Y
		 * System.out.println(p2.toString());
		 * p1.ponerACero(); //Pone a 0 los valores de X e Y
		 * System.out.println(p1.toString());
		 *
		 */

	}

}
