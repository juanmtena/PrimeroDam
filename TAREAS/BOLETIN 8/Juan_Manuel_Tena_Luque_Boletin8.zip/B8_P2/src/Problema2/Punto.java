package Problema2;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Punto {

	private double x;
	private double y;
	
	public Punto() { //Constructor sin parametros, da por valor X = 0 e Y = 0
		
	}

	public Punto(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}

	public void ponerACero() { //Para borrar y poner a 0 el valor de X e Y
		x = 0;
		y = 0;
	}
	
	public void mover() {
		BufferedReader teclado = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Valor de x: ");
		try {
			this.x = Double.parseDouble(teclado.readLine());
		} catch (Exception e) {
			
		}
		System.out.print("Valor de y: ");
		try {
			this.y = Double.parseDouble(teclado.readLine());
		} catch (Exception e) {
			
		}
	}
	
	public void mover(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	public double distancia(Punto p){
        double diferenciaX = x - p.getX();
        double diferenciaY = y - p.getY();

        return Math.sqrt(Math.pow(diferenciaX, 2) + Math.pow(diferenciaY, 2));
    }
	
	public String toString() {
		String sResultado = "";
		
		sResultado += "("+this.getX()+","+this.getY()+")";
		
		return sResultado;
	}
	
}
