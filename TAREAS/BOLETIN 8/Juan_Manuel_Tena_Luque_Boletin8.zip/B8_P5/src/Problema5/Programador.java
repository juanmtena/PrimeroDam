package Problema5;

public class Programador {

	Bombilla bombilla1 = new Bombilla();
	Bombilla bombilla2 = new Bombilla();
	Bombilla bombilla3 = new Bombilla();
	Bombilla bombilla4 = new Bombilla();
	Bombilla bombilla5 = new Bombilla();
	Bombilla bombilla6 = new Bombilla();
	
	public String programa1() {
		String sMensaje = "";
		
		bombilla1.encender();
		bombilla2.apagar();
		bombilla3.encender();
		bombilla4.apagar();
		bombilla5.encender();
		bombilla6.apagar();		
		
		sMensaje += bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar()+"\n";
		
		bombilla1.cambiar();
		bombilla2.cambiar();
		bombilla3.cambiar();
		bombilla4.cambiar();
		bombilla5.cambiar();
		bombilla6.cambiar();
		
		sMensaje += bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar();
				
		return sMensaje;
	}	
	
	public String programa2() {
		String sMensaje = "";
		
		bombilla1.encender();
		bombilla2.apagar();
		bombilla3.apagar();
		bombilla4.apagar();
		bombilla5.apagar();
		bombilla6.apagar();
		
		sMensaje += bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar()+"\n";
		
		bombilla2.cambiar();

		sMensaje += bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar()+"\n";

		bombilla3.cambiar();

		sMensaje += bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar()+"\n";

		bombilla4.cambiar();

		sMensaje += bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar()+"\n";

		bombilla5.cambiar();
		
		sMensaje += bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar()+"\n";
		bombilla6.cambiar();
		
		sMensaje += bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar();

		return sMensaje;
	}
	
	public String programa3() {
		String sMensaje = "";
		
		bombilla1.encender();
		bombilla2.apagar();
		bombilla3.apagar();
		bombilla4.apagar();
		bombilla5.apagar();
		bombilla6.apagar();

		sMensaje += (bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar())+"\n";

		bombilla2.cambiar();

		sMensaje += bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar()+"\n";

		bombilla3.cambiar();

		sMensaje += bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar()+"\n";

		bombilla4.cambiar();

		sMensaje += bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar()+"\n";

		bombilla5.cambiar();

		sMensaje += bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar()+"\n";

		bombilla6.cambiar();

		sMensaje += bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar()+"\n";

		bombilla6.cambiar();

		sMensaje += bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar()+"\n";

		bombilla5.cambiar();

		sMensaje += bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar()+"\n";

		bombilla4.cambiar();

		sMensaje += bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar()+"\n";

		bombilla3.cambiar();

		sMensaje += bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar()+"\n";

		bombilla2.cambiar();
		bombilla1.encender();

		sMensaje += bombilla1.mostrar()+bombilla2.mostrar()+bombilla3.mostrar()+bombilla4.mostrar()
				+bombilla5.mostrar()+bombilla6.mostrar();
		
		return sMensaje;
	}
	
}
