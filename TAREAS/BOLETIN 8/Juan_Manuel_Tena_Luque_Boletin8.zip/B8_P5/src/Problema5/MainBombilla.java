package Problema5;

public class MainBombilla {

	public static void main(String[] args) {
		
		Programador programa = new Programador();
		
		System.out.println("----------");
		System.out.println(programa.programa1());
		System.out.println("----------\n");
		System.out.println("----------");
		System.out.println(programa.programa2());
		System.out.println("----------\n");
		System.out.println("----------");
		System.out.println(programa.programa3());
		System.out.println("----------");
		
	}

}
