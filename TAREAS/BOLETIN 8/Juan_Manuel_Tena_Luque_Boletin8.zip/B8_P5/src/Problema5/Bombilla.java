package Problema5;

public class Bombilla {

	public boolean boolEncendida;
	private String sBombilla;
	
	public boolean isBoolEncendida() {
		return boolEncendida;
	}

	public void setBoolEncendida(boolean boolEncendida) {
		this.boolEncendida = boolEncendida;
	}

	public boolean encender() {
		this.boolEncendida = true;
		return boolEncendida;
	}

	
	public boolean apagar() {
		this.boolEncendida = false;
		return boolEncendida;
	}

	
	public boolean cambiar() {
		if(boolEncendida == false) {
			this.boolEncendida = true;
		}else if(boolEncendida == true) {
			this.boolEncendida = false;
		}
		return boolEncendida;
	}
	
	public String mostrar() {
		String sDibujo = "";
		if(boolEncendida == true) {
			sDibujo = "*";
		} else if(boolEncendida == false) {
			sDibujo = "�";
		}
		return sDibujo;
	}
	
}
