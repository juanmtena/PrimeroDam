package Problema4;

public class Expendedora {

	private int iNumeroSerie;//PK
	private float fCreditoAcumulado;//NN
	private float fCreditoConsumido;//NN
	private float fDineroAcumuladoMaquina;//NN
	
	public Expendedora(int iNumeroSerie, float fCreditoAcumulado, float fCreditoConsumido, float fDineroAcumuladoMaquina) {
		
		this.iNumeroSerie = iNumeroSerie;
		this.fCreditoAcumulado = fCreditoAcumulado;
		this.fCreditoConsumido = fCreditoConsumido;
		this.fDineroAcumuladoMaquina = fDineroAcumuladoMaquina;
	}

	public String insertarMoneda(final float fMONEDA) {
		String sMoneda = "";	
		
		if(fMONEDA > 0 && fMONEDA <= 2) {
			this.fCreditoAcumulado = fMONEDA;
		}
		
		if(fCreditoAcumulado > 0 && fCreditoAcumulado < 1) {
			sMoneda = "Ha insertado una moneda de "+fMONEDA+" centimos";
		}else if (fCreditoAcumulado > 1 && fCreditoAcumulado <= 2) {
			sMoneda = "Ha insertado una moneda de "+fMONEDA+" euros";
		}else if(fCreditoAcumulado == 1) {
			sMoneda = "Ha insertado una moneda de "+fMONEDA+" euro";
		}		
		return sMoneda;
	}
	
	public String creditoDisponible() {
		String sCreditoDispo = "";
		
		if(fCreditoAcumulado > 0 && fCreditoAcumulado < 1) {
			sCreditoDispo = "Tiene "+fCreditoAcumulado+" centimos disponible";
		} else if(fCreditoAcumulado > 1 && fCreditoAcumulado <= 2) {
			sCreditoDispo = "Tiene "+fCreditoAcumulado+" euros disponible";
		}else if (fCreditoAcumulado == 1) {
			sCreditoDispo = "Tiene "+fCreditoAcumulado+" euro disponible";
		}
		return sCreditoDispo;
	}
	
	public String pedirProducto(final float fPRECIOPRODUCTO) {
		String sProducto = "";
		
		this.fCreditoConsumido = fPRECIOPRODUCTO;
		sProducto = "El producto seleccionado vale "+this.fCreditoConsumido+" euros";
		return sProducto;
	}
	
	public String solicitarCreditoRestante() {
		String sRestante = "";
				
		float fRestante = this.fCreditoAcumulado - this.fCreditoConsumido;
		
		if(fRestante > 0 && fRestante < 1) {
			sRestante = "Devolucion de "+fRestante+" centimos";
		}else if(fRestante > 1) {
			sRestante = "Devolucion de "+fRestante+" euros";
		}
		
		return sRestante;
	}	
	
	public String numeroSerie(final int iNUMEROSERIE) {
		String sNumeroSerie = "";
		
		if(iNumeroSerie > 0 && iNumeroSerie < 6500) {
			this.iNumeroSerie = iNUMEROSERIE;
		}
		sNumeroSerie = "Esta maquina corresponde al numero de serie "+iNUMEROSERIE;
		
		return sNumeroSerie;
	}
		
}
