package Problema4;

public class Main {

	public static void main(String[] args) {
		
		final float fMONEDA = 2f;
		final int iNUMEROSERIE = 1650;
		final float fPRECIOPRODUCTO = 1.50f;
		
		Expendedora exp = new Expendedora(0, 0, 0, 0);
		System.out.println(exp.insertarMoneda(fMONEDA));
		System.out.println(exp.creditoDisponible());
		System.out.println(exp.pedirProducto(fPRECIOPRODUCTO));
		System.out.println(exp.solicitarCreditoRestante());
		System.out.println(exp.numeroSerie(iNUMEROSERIE));
		
	}

}
