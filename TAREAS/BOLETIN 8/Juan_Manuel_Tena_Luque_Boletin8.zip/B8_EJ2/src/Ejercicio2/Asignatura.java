package Ejercicio2;

public class Asignatura {
	private String sNombre; //FK
	private String sCodigo; //PK
	private int iCurso; //NN
	
	public Asignatura(String sNombre, String sCodigo, int iCurso) {
		setsNombre(sNombre);
		setsCodigo(sCodigo);
		setiCurso(iCurso);
	}

	public String getsNombre() {
		return sNombre;
	}

	public void setsNombre(String sNombre) {
		if(sNombre != null) {
			this.sNombre = sNombre;
		}
	}

	public String getsCodigo() {
		return sCodigo;
	}

	public void setsCodigo(String sCodigo) {
		this.sCodigo = sCodigo;
	}

	public int getiCurso() {
		return iCurso;
	}

	public void setiCurso(int iCurso) {
		if(iCurso > 0 && iCurso < 5) {
			this.iCurso = iCurso;
		}
	}
	
	
	
}
