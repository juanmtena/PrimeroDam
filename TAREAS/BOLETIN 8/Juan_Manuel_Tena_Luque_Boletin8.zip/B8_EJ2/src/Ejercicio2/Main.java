package Ejercicio2;

public class Main {

	public static void main(String[] args) {
		Asignatura asig = new Asignatura("Programacion", "PRO1", 1);
		System.out.println("La asignatura de "+asig.getsNombre()+" tiene asignado el codigo "
		+asig.getsCodigo()+" referente al curso de "+asig.getiCurso()+"�");
	}

}
