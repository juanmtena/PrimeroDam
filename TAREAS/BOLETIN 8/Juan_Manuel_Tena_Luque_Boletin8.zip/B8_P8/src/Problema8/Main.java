package Problema8;

public class Main {

	public static void main(String[] args) {
		
		Coche coche1 = new Coche("Seat Ibiza", "gris");
		Coche cMiCoche = new Coche("Ford Fiesta", "negro");
		cMiCoche.imprimeCoche(cMiCoche.getsModelo(),cMiCoche.getsColor());
		
	}

}
