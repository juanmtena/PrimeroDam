package Problema6;

public class Main {

	public static void main(String[] args) {
		
		Coche cMiCoche = new Coche("Ford Fiesta", "negro");
		cMiCoche.imprimeCoche(cMiCoche.getsModelo(),cMiCoche.getsColor());
		
	}

}
