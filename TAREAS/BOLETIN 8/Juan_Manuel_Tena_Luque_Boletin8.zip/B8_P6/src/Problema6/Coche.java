package Problema6;

public class Coche {

	private String sModelo; //FK
	private String sColor; //NN
	private String sMetalizada; //NN
	private String sMatricula; //PK
	private String sTipoCoche; //NN
	private short shAnioFabricacion; //NN
	private String sSeguro; //NN
	
	public Coche(short shMatricula) {
		setsMatricula(sMatricula);
	}

	public Coche(String sModelo, String sColor, String sMetalizada, String shMatricula, String sTipoCoche,
			short shAnioFabricacion, String sSeguro) {
		
		setsModelo(sModelo); 
		setsColor(sColor);
		setsMetalizada(sMetalizada);
		setsMatricula(sMatricula);
		setsTipoCoche(sTipoCoche);
		setShAnioFabricacion(shAnioFabricacion);
		setsSeguro(sSeguro);
	}
	
	public Coche(String sModelo, String sColor) {
		setsModelo(sModelo); 
		setsColor(sColor);
	} 

	public String getsModelo() {
		return sModelo;
	}

	public void setsModelo(String sModelo) {
		if(sModelo != null) {
			this.sModelo = sModelo;
		}
	}

	public String getsColor() {
		return sColor;
	}

	public void setsColor(String sColor) {
		if(sColor != null) {
			this.sColor = sColor;
		}
	}

	public String getsMetalizada() {
		return sMetalizada;
	}

	public void setsMetalizada(String sMetalizada) {
		if(sMetalizada == "metalizada" || sMetalizada == "no metalizada") {
			this.sMetalizada = sMetalizada;
		}
	}

	public String getsMatricula() {
		return sMatricula;
	}

	public void setsMatricula(String sMatricula) {
		if(sMatricula != null) {
			this.sMatricula = sMatricula;
		}
	}

	public String getsTipoCoche() {
		return sTipoCoche;
	}

	public void setsTipoCoche(String sTipoCoche) {
		if(sTipoCoche == "mini" || sTipoCoche == "utilitario" || sTipoCoche == "familiar" || sTipoCoche == "deportivo") {
			this.sTipoCoche = sTipoCoche;
		}
	}

	public short getShAnioFabricacion() {
		return shAnioFabricacion;
	}

	public void setShAnioFabricacion(short shAnioFabricacion) {
		if(shAnioFabricacion > 2000) {
			this.shAnioFabricacion = shAnioFabricacion;
		}
	}

	public String sSeguro() {
		return sSeguro;
	}

	public void setsSeguro(String sSeguro) {
		if(sSeguro == "terceros" || sSeguro == "todo riesgo") {
			this.sSeguro = sSeguro;
		}
	}
		
}
