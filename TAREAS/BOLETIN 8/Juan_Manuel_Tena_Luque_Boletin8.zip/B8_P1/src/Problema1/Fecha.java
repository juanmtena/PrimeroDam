package Problema1;

public class Fecha {

	private int iDia;
	private int iMes;
	private int iAnio;

	public Fecha(int iDia, int iMes, int iAnio) {
		this.iDia = iDia;
		this.iMes = iMes;
		this.iAnio = iAnio;
	}

	public int getiDia() {
		return iDia;
	}

	public void setiDia(int iDia) {
		if (iDia > 0 || iDia < 32) {
			this.iDia = iDia;
        }
	}

	public int getiMes() {
		return iMes;
	}

	public void setiMes(int iMes) {
		if(iMes > 0 && iMes < 13) {
			this.iMes = iMes;
		}
	}

	public int getiAnio() {
		return iAnio;
	}

	public void setiAnio(int iAnio) {
		if(iAnio > 0 && iAnio < 3001) {
			this.iAnio = iAnio;
		}
	}
	
	public boolean validarFecha(){
        boolean boolValido=false;

        if (getiMes() == 1 || getiMes() == 3 || getiMes() == 5 || getiMes() == 7 || getiMes() == 8 || getiMes() == 10 || getiMes() == 12
				&& getiDia() <= 31) {
        	boolValido = true;
        }

        if (getiMes() == 4 || getiMes() == 6 || getiMes() == 9 || getiMes() == 11 && getiDia() <= 30) {
        	boolValido = true;
        }

        if (getiMes() == 2 && getiDia() <= 29 && getiDia() > 0 && getiAnio() % 400 == 0 || getiAnio() % 4 == 0 && getiAnio() % 100 != 0 ) {
        	boolValido = true;
        }
        
        return boolValido;
	}

}
