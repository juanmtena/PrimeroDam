package Problema1;

public class Main {

	public static void main(String[] args) {
		
		Fecha f = new Fecha(1,1,2000);
		
		if(f.validarFecha() == true) {
			System.out.println("La fecha es: "+f.getiDia()+"/"+f.getiMes()+"/"+f.getiAnio());
		}else {
			System.out.println("La fecha no es correcta");
		}
		
	}

}
