package Problema7;

public class Main {

	public static void main(String[] args) {
		
		Coche coche1 = new Coche("Seat Ibiza", "gris");
		coche1.imprimeCoche(coche1.getsModelo(),coche1.getsColor());
		
	}

}
